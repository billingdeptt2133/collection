<?php

namespace Tests\Feature;

use App\Models\Category;
use App\Models\Coupon;
use App\Models\Order;
use App\Models\PaymentReconciliation;
use App\Models\Product;
use App\Models\User;
use App\Models\Variant;
use App\Notifications\PaymentReconciliationAlert;
use App\Services\RazorpayPaymentLifecycle;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Notification;
use Tests\TestCase;

class PaymentLifecycleTest extends TestCase
{
    use RefreshDatabase;

    private function pendingOrder(array $overrides = []): array
    {
        $user = User::factory()->create();
        $category = Category::create(['name' => 'Jeans', 'slug' => 'jeans-lifecycle']);
        $product = Product::create(['category_id' => $category->id, 'title' => 'Test Jeans', 'slug' => 'test-jeans-lifecycle', 'price_paise' => 159900, 'is_active' => true]);
        $variant = $product->variants()->create(['size' => '32', 'color' => 'Blue', 'stock' => 0]);
        $coupon = Coupon::create(['code' => 'HOLD30', 'discount_paise' => 10000, 'minimum_paise' => 0, 'used_count' => 1, 'is_active' => true]);
        $order = Order::create(array_merge([
            'user_id' => $user->id, 'checkout_token' => (string) \Illuminate\Support\Str::uuid(),
            'name' => 'Buyer', 'phone' => '9876543210', 'address' => 'Test Road', 'city' => 'Jaipur', 'state' => 'Rajasthan', 'pincode' => '302001',
            'subtotal_paise' => 159900, 'discount_paise' => 10000, 'total_paise' => 149900, 'coupon_id' => $coupon->id,
            'payment_method' => 'razorpay', 'payment_status' => 'pending', 'status' => 'pending',
            'gateway_receipt' => 'dk-lifecycle', 'gateway_order_state' => 'created',
            'gateway_order_id' => 'order_lifecycle', 'payment_expires_at' => now()->subMinutes(40),
        ], $overrides));
        $order->items()->create(['variant_id' => $variant->id, 'title' => $product->title, 'size' => '32', 'color' => 'Blue', 'price_paise' => 159900, 'quantity' => 1]);
        return [$order, $variant, $coupon];
    }

    public function test_gateway_creation_timeout_keeps_stock_and_coupon_held_and_alerts_admin(): void
    {
        Notification::fake();
        $admin = User::factory()->create();
        $admin->forceFill(['is_admin' => true])->save();
        [$order, $variant, $coupon] = $this->pendingOrder(['gateway_order_id' => null, 'gateway_order_state' => 'creating']);
        Http::fake(['api.razorpay.com/v1/orders' => Http::response(['error' => 'timeout'], 504)]);

        $this->assertFalse(app(RazorpayPaymentLifecycle::class)->createGatewayOrder($order->id));
        $this->assertSame(0, $variant->fresh()->stock);
        $this->assertSame(1, $coupon->fresh()->used_count);
        $this->assertSame('pending', $order->fresh()->status);
        $this->assertSame('unknown', $order->fresh()->gateway_order_state);
        $this->assertDatabaseHas('payment_reconciliations', ['order_id' => $order->id, 'kind' => 'gateway_order_creation_ambiguous']);
        Notification::assertSentTo($admin, PaymentReconciliationAlert::class);
    }

    public function test_expired_failed_payment_releases_stock_and_coupon_once(): void
    {
        [$order, $variant, $coupon] = $this->pendingOrder();
        Http::fake(function ($request) use ($order) {
            if (str_ends_with($request->url(), '/payments')) {
                return Http::response(['items' => [['id' => 'pay_failed', 'status' => 'failed']]]);
            }
            return Http::response(['id' => 'order_lifecycle', 'amount' => $order->total_paise, 'amount_paid' => 0,
                'currency' => 'INR', 'receipt' => $order->gateway_receipt, 'status' => 'attempted']);
        });

        Artisan::call('payments:expire-pending-razorpay');
        $this->assertSame(1, $variant->fresh()->stock);
        $this->assertSame(0, $coupon->fresh()->used_count);
        $this->assertSame('failed', $order->fresh()->payment_status);
        $this->assertNotNull($order->fresh()->stock_released_at);
        Artisan::call('payments:expire-pending-razorpay');
        $this->assertSame(1, $variant->fresh()->stock);
        $this->assertSame(0, $coupon->fresh()->used_count);
    }

    public function test_expired_dismissed_payment_with_no_gateway_attempt_releases_reservation(): void
    {
        [$order, $variant, $coupon] = $this->pendingOrder();
        Http::fake(function ($request) use ($order) {
            if (str_ends_with($request->url(), '/payments')) return Http::response(['items' => []]);
            return Http::response(['id' => 'order_lifecycle', 'amount' => $order->total_paise, 'amount_paid' => 0,
                'currency' => 'INR', 'receipt' => $order->gateway_receipt, 'status' => 'created']);
        });
        Artisan::call('payments:expire-pending-razorpay');
        $this->assertSame(1, $variant->fresh()->stock);
        $this->assertSame(0, $coupon->fresh()->used_count);
        $this->assertSame('failed', $order->fresh()->payment_status);
    }

    public function test_unknown_gateway_order_needs_two_successful_absence_checks_before_release(): void
    {
        [$order, $variant, $coupon] = $this->pendingOrder(['gateway_order_id' => null, 'gateway_order_state' => 'unknown']);
        Http::fake(['api.razorpay.com/v1/orders*' => Http::response(['items' => []])]);

        Artisan::call('payments:expire-pending-razorpay');
        $this->assertNull($order->fresh()->stock_released_at);
        $this->assertSame(1, $order->fresh()->gateway_absence_checks);
        $order->update(['gateway_reconcile_after' => now()->subMinute()]);
        Artisan::call('payments:expire-pending-razorpay');
        $this->assertNotNull($order->fresh()->stock_released_at);
        $this->assertSame(1, $variant->fresh()->stock);
        $this->assertSame(0, $coupon->fresh()->used_count);
    }

    public function test_late_and_duplicate_captures_create_durable_idempotent_issues(): void
    {
        Notification::fake();
        $admin = User::factory()->create();
        $admin->forceFill(['is_admin' => true])->save();
        [$order] = $this->pendingOrder(['status' => 'cancelled', 'payment_status' => 'failed', 'stock_released_at' => now()]);
        $payment = ['id' => 'pay_late', 'order_id' => 'order_lifecycle', 'amount' => 149900, 'currency' => 'INR', 'status' => 'captured'];
        $lifecycle = app(RazorpayPaymentLifecycle::class);

        $this->assertSame('captured_after_release_or_ineligible', $lifecycle->settleCaptured($order, $payment));
        $this->assertSame('captured_after_release_or_ineligible', $lifecycle->settleCaptured($order, $payment));
        $this->assertSame(1, PaymentReconciliation::where('payment_id', 'pay_late')->count());
        Notification::assertSentTo($admin, PaymentReconciliationAlert::class);

        $order->update(['status' => 'processing', 'payment_status' => 'paid', 'gateway_payment_id' => 'pay_first', 'stock_released_at' => null]);
        $this->assertSame('duplicate_capture', $lifecycle->settleCaptured($order->fresh(), [...$payment, 'id' => 'pay_second']));
        $this->assertDatabaseHas('payment_reconciliations', ['order_id' => $order->id, 'payment_id' => 'pay_second', 'kind' => 'duplicate_capture']);
    }

    public function test_non_captured_webhook_events_leave_order_and_reservation_pending(): void
    {
        [$order, $variant, $coupon] = $this->pendingOrder();
        config()->set('services.razorpay.webhook_secret', 'test-webhook-secret');

        foreach ([
            'payment.created' => 'created',
            'payment.authorized' => 'authorized',
            'payment.failed' => 'failed',
        ] as $event => $status) {
            $body = json_encode(['event' => $event, 'payload' => ['payment' => ['entity' => [
                'id' => 'pay_'.str_replace('.', '', $event), 'order_id' => $order->gateway_order_id, 'status' => $status,
            ]]]], JSON_THROW_ON_ERROR);
            $signature = hash_hmac('sha256', $body, 'test-webhook-secret');
            $response = $this->call('POST', '/webhooks/razorpay', [], [], [], [
                'CONTENT_TYPE' => 'application/json', 'HTTP_X_RAZORPAY_SIGNATURE' => $signature,
            ], $body);
            $response->assertOk();
        }

        $this->assertSame('pending', $order->fresh()->payment_status);
        $this->assertNull($order->fresh()->gateway_payment_id);
        $this->assertNull($order->fresh()->stock_released_at);
        $this->assertSame(0, $variant->fresh()->stock);
        $this->assertSame(1, $coupon->fresh()->used_count);
    }

    public function test_captured_webhook_requires_valid_signature_and_settles_order(): void
    {
        [$order] = $this->pendingOrder();
        config()->set('services.razorpay.webhook_secret', 'test-webhook-secret');
        $body = json_encode(['event' => 'payment.captured', 'payload' => ['payment' => ['entity' => [
            'id' => 'pay_webhook', 'order_id' => $order->gateway_order_id, 'amount' => $order->total_paise,
            'currency' => 'INR', 'status' => 'captured',
        ]]]], JSON_THROW_ON_ERROR);

        $invalid = $this->call('POST', '/webhooks/razorpay', [], [], [], [
            'CONTENT_TYPE' => 'application/json', 'HTTP_X_RAZORPAY_SIGNATURE' => 'invalid',
        ], $body);
        $invalid->assertUnauthorized();
        $this->assertSame('pending', $order->fresh()->payment_status);

        $signature = hash_hmac('sha256', $body, 'test-webhook-secret');
        $valid = $this->call('POST', '/webhooks/razorpay', [], [], [], [
            'CONTENT_TYPE' => 'application/json', 'HTTP_X_RAZORPAY_SIGNATURE' => $signature,
        ], $body);
        $valid->assertOk();
        $this->assertSame('paid', $order->fresh()->payment_status);
        $this->assertSame('pay_webhook', $order->fresh()->gateway_payment_id);
    }

}
