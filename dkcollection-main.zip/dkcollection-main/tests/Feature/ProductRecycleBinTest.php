<?php
namespace Tests\Feature;

use App\Models\{Product,User,Order};
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\{Storage,DB};
use Illuminate\Support\Str;
use Tests\TestCase;

class ProductRecycleBinTest extends TestCase
{
    use RefreshDatabase;
    private function admin(string $role='catalog'): User {
        $u=User::factory()->create();$u->forceFill(['is_admin'=>true,'admin_role'=>$role])->save();return $u;
    }
    private function product(): Product {
        Storage::fake('public');Storage::disk('public')->put('products/black.jpg','photo');
        $p=Product::create(['title'=>'Recycle Jeans','slug'=>'recycle-jeans','price_paise'=>10000,'article_code'=>'1336','is_active'=>true,'image_path'=>'products/black.jpg']);
        $p->variants()->create(['size'=>'28','color'=>'Black','stock'=>10]);$p->images()->create(['color'=>'Black','path'=>'products/black.jpg']);return $p;
    }
    public function test_trash_hides_catalog_detail_availability_cart_and_editor_but_keeps_stock_photos(): void {
        $p=$this->product();$id=$p->variants()->first()->id;$this->actingAs($this->admin());
        $this->delete(route('admin.products.delete',$p))->assertRedirect(route('admin.products.recycle-bin'));
        $this->assertSoftDeleted('products',['id'=>$p->id]);$this->assertNull(Product::find($p->id));
        $this->assertDatabaseHas('variants',['id'=>$id,'stock'=>10]);$this->assertDatabaseCount('product_images',1);Storage::disk('public')->assertExists('products/black.jpg');
        $this->get(route('home'))->assertOk()->assertDontSee('Recycle Jeans');
        $this->get(route('products.show',$p->slug))->assertNotFound();$this->get(route('products.availability',$p->slug))->assertNotFound();
        $this->get(route('admin.products'))->assertOk()->assertDontSee('Recycle Jeans');$this->get(route('admin.products.edit',$p))->assertNotFound();
        $this->post(route('cart.add'),['variant_id'=>$id,'quantity'=>1])->assertNotFound();
        $this->post(route('buy-now'),['variant_id'=>$id,'quantity'=>1])->assertNotFound();
        $this->withSession(['cart'=>[$id=>1]])->get(route('cart'))->assertOk()->assertViewHas('lines',fn($lines)=>$lines->isEmpty());
        $this->get(route('admin.products.recycle-bin'))->assertOk()->assertSee('Recycle Jeans')->assertSee('Restore as draft')->assertHeader('Cache-Control','no-store, private');
    }
    public function test_restore_keeps_same_ids_and_photos_and_requires_explicit_publish(): void {
        $p=$this->product();$v=$p->variants()->first();$this->actingAs($this->admin())->delete(route('admin.products.delete',$p));
        $this->patch(route('admin.products.restore',$p))->assertRedirect(route('admin.products.edit',$p));
        $restored=Product::findOrFail($p->id);$this->assertFalse($restored->is_active);$this->assertFalse($restored->trashed());
        $this->assertSame($v->id,$restored->variants()->first()->id);$this->assertSame(10,(int)$v->fresh()->stock);Storage::disk('public')->assertExists('products/black.jpg');
        $this->get(route('home'))->assertDontSee('Recycle Jeans');$this->patch(route('admin.products.restore',$p))->assertNotFound();
        $restored->update(['is_active'=>true]);$this->get(route('home'))->assertSee('Black Recycle Jeans');
    }
    public function test_customers_support_and_orders_staff_cannot_access_or_mutate_bin(): void {
        $p=$this->product();
        foreach([User::factory()->create(),$this->admin('support'),$this->admin('orders')] as $u){
            $this->actingAs($u)->get(route('admin.products.recycle-bin'))->assertForbidden();
            $this->delete(route('admin.products.delete',$p))->assertForbidden();
        }
        $this->actingAs($this->admin())->delete(route('admin.products.delete',$p));
        foreach([User::factory()->create(),$this->admin('support'),$this->admin('orders')] as $u){
            $this->actingAs($u)->patch(route('admin.products.restore',$p))->assertForbidden();
            $this->delete(route('admin.products.force-delete',$p),['confirmation'=>'DELETE'])->assertForbidden();
        }
    }
    public function test_force_delete_requires_trash_confirmation_and_password_and_cleans_unused_files(): void {
        $p=$this->product();$admin=$this->admin();$this->actingAs($admin)->withSession(['admin_confirmed_user'=>$admin->id,'admin_confirmed'=>time()]);
        $this->delete(route('admin.products.force-delete',$p),['confirmation'=>'DELETE'])->assertSessionHasErrors('product');$this->assertDatabaseHas('products',['id'=>$p->id,'deleted_at'=>null]);
        $this->delete(route('admin.products.delete',$p));
        $this->delete(route('admin.products.force-delete',$p),['confirmation'=>'WRONG'])->assertSessionHasErrors('confirmation');
        $this->delete(route('admin.products.force-delete',$p),['confirmation'=>'DELETE'])->assertRedirect(route('admin.products.recycle-bin'));
        $this->assertDatabaseMissing('products',['id'=>$p->id]);$this->assertDatabaseCount('variants',0);$this->assertDatabaseCount('product_images',0);Storage::disk('public')->assertMissing('products/black.jpg');
    }
    public function test_trash_keeps_order_snapshots_and_inventory_available_for_refunds(): void {
        $p=$this->product();$variant=$p->variants()->first();$user=User::factory()->create();
        $order=Order::create(['user_id'=>$user->id,'checkout_token'=>(string)Str::uuid(),'name'=>'Buyer','phone'=>'9876543210','address'=>'Test','city'=>'Jaipur','state'=>'Rajasthan','pincode'=>'302001','payment_method'=>'cod','subtotal_paise'=>10000,'total_paise'=>10000]);
        $order->items()->create(['variant_id'=>$variant->id,'title'=>$p->title,'size'=>'28','color'=>'Black','price_paise'=>10000,'quantity'=>1]);
        $admin=$this->admin();$this->actingAs($admin)->delete(route('admin.products.delete',$p));
        $this->get(route('admin.products.recycle-bin'))->assertSee('Order-linked')->assertDontSee('data-bin-delete',false);
        $this->withSession(['admin_confirmed_user'=>$admin->id,'admin_confirmed'=>time()])->delete(route('admin.products.force-delete',$p),['confirmation'=>'DELETE'])->assertSessionHasErrors('product');
        $this->actingAs($user)->get(route('orders.show',$order))->assertOk()->assertSee('Recycle Jeans')->assertSee('100.00');
        $this->assertDatabaseHas('order_items',['variant_id'=>$variant->id]);$this->assertSame(10,(int)$variant->fresh()->stock);
    }
    public function test_bin_mutation_requires_csrf_and_is_audited_without_customer_or_password_data(): void {
        $p=$this->product();$this->actingAs($this->admin())->withSession(['_token'=>str_repeat('a',40)]);
        app('router')->getRoutes()->getByName('admin.products.delete')->middleware(EnforcedBinCsrf::class);
        $this->delete(route('admin.products.delete',$p))->assertStatus(419);$this->assertDatabaseHas('products',['id'=>$p->id,'deleted_at'=>null]);
        $this->delete(route('admin.products.delete',$p),['_token'=>str_repeat('a',40)])->assertRedirect();
        $this->assertDatabaseHas('admin_audits',['action'=>'admin.products.delete']);
        $context=DB::table('admin_audits')->where('action','admin.products.delete')->value('context');$this->assertStringNotContainsString('_token',$context);
    }
}
class EnforcedBinCsrf extends \Illuminate\Foundation\Http\Middleware\ValidateCsrfToken {
    protected function runningUnitTests(){return false;}
}
