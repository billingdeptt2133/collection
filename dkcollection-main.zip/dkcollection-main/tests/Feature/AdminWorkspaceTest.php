<?php
namespace Tests\Feature;
use App\Models\{User,Product,Order,Coupon};
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\{DB,Http,Mail};
use Illuminate\Support\Str;
use Tests\TestCase;
class AdminWorkspaceTest extends TestCase {
 use RefreshDatabase;
 private function admin(?string $role=null):User {$u=User::factory()->create();$u->forceFill(['is_admin'=>true,'admin_role'=>$role])->save();return $u;}
 private function order(string $method='cod',string $status='pending'):array {$p=Product::create(['title'=>'Test Jeans','slug'=>Str::random(8),'price_paise'=>10000,'is_active'=>true]);$v=$p->variants()->create(['size'=>'M','color'=>'Black','stock'=>4]);$u=User::factory()->create();$o=Order::create(['user_id'=>$u->id,'checkout_token'=>(string)Str::uuid(),'name'=>'Buyer','phone'=>'9876543210','address'=>'Private shipping address','city'=>'Jaipur','state'=>'Rajasthan','pincode'=>'302001','payment_method'=>$method,'status'=>$status,'subtotal_paise'=>10000,'total_paise'=>10000]);$o->items()->create(['variant_id'=>$v->id,'title'=>$p->title,'size'=>'M','color'=>'Black','price_paise'=>10000,'quantity'=>1]);return [$o,$v];}
 public function test_all_admin_pages_render_for_owner_and_deny_customers():void {
  $owner=$this->admin();
  foreach(['dashboard','products','products.create','stock','categories','orders','returns','customers','coupons','reviews','homepage','settings','delivery','payments','reports','access','activity','security'] as $name){$this->actingAs($owner)->get(route('admin.'.$name))->assertOk();}
  [$o,$v]=$this->order();$this->get(route('admin.products.edit',$v->product_id))->assertOk();$this->get(route('admin.orders.show',$o))->assertOk();
  $this->actingAs(User::factory()->create());
  foreach(['dashboard','products','stock','orders','returns','customers','settings','payments','reports','access','activity','security'] as $name)$this->get(route('admin.'.$name))->assertForbidden();
 }
 public function test_roles_protect_direct_urls_and_existing_mutation_routes():void {
  $catalog=$this->admin('catalog');[$o,$v]=$this->order();
  $this->actingAs($catalog)->get(route('admin.products'))->assertOk();
  $this->get(route('admin.orders'))->assertForbidden();
  $this->patch(route('admin.orders.update',$o),['status'=>'cancelled'])->assertForbidden();
  $this->post(route('admin.settings.update'),[])->assertForbidden();
  $this->get(route('admin.dashboard'))->assertOk()->assertDontSee('Buyer');
  $this->actingAs($this->admin('support'))->get(route('admin.orders.show',$o))->assertOk();
  $this->post(route('admin.shipping.update',$o),['action'=>'pack'])->assertForbidden();
  $this->patch(route('admin.orders.update',$o),['status'=>'cancelled'])->assertForbidden();
  $this->actingAs($this->admin('orders'))->get(route('admin.payments'))->assertForbidden();
 }
 public function test_stock_adjustment_rejects_stale_inventory_and_records_reason():void {
  [$o,$v]=$this->order();$this->actingAs($this->admin('catalog'));
  $this->post(route('admin.stock.update',$v),['stock'=>8,'expected_stock'=>4,'reason'=>'Supplier delivery'])->assertRedirect();
  $this->assertSame(8,(int)$v->fresh()->stock);
  $this->post(route('admin.stock.update',$v),['stock'=>9,'expected_stock'=>4,'reason'=>'Stale editor'])->assertStatus(409);
  $this->assertDatabaseCount('stock_movements',1);$this->assertDatabaseHas('stock_movements',['change'=>4,'reason'=>'Supplier delivery']);
 }
 public function test_product_editor_rejects_stale_stock_snapshot():void {
  [$o,$v]=$this->order();$this->actingAs($this->admin());
  $snapshot=hash('sha256',$v->id.':4');$v->update(['stock'=>3]);
  $this->post(route('admin.products.update',$v->product_id),['title'=>'Test Jeans','price_paise'=>10000,'variants'=>'M,Black,4','stock_snapshot'=>$snapshot])->assertStatus(409);
  $this->assertSame(3,(int)$v->fresh()->stock);
 }
 public function test_fulfilment_requires_verified_payment_and_packing_before_shipping():void {
  [$o]=$this->order('razorpay');$this->actingAs($this->admin('orders'));
  $this->post(route('admin.shipping.update',$o),['action'=>'pack'])->assertStatus(409);
  $o->update(['payment_status'=>'paid','status'=>'processing']);
  $this->post(route('admin.shipping.update',$o),['action'=>'ship','courier'=>'Courier','tracking_number'=>'ABC'])->assertStatus(409);
  $this->post(route('admin.shipping.update',$o),['action'=>'pack'])->assertRedirect();
  $this->post(route('admin.shipping.update',$o),['action'=>'ship','courier'=>'Courier','tracking_number'=>'ABC','tracking_url'=>'javascript:alert(1)'])->assertSessionHasErrors('tracking_url');
  $this->post(route('admin.shipping.update',$o),['action'=>'ship','courier'=>'Courier','tracking_number'=>'ABC','tracking_url'=>'https://example.com/ABC'])->assertRedirect();
  $this->post(route('admin.shipping.update',$o),['action'=>'deliver'])->assertRedirect();
  $this->assertSame('delivered',$o->fresh()->status);
  $this->post(route('admin.shipping.update',$o),['action'=>'deliver'])->assertStatus(409);
 }
 public function test_returns_restore_inventory_only_once_and_refunds_require_gateway_verification():void {
  [$o,$v]=$this->order('razorpay','delivered');$o->update(['payment_status'=>'paid','gateway_payment_id'=>'pay_TEST']);$u=$this->admin();$this->actingAs($u)->withSession(['admin_confirmed_user'=>$u->id,'admin_confirmed'=>time()]);
  $this->post(route('admin.returns.store'),['order_id'=>$o->id,'reason'=>'Wrong fit'])->assertRedirect();
  $id=DB::table('order_returns')->value('id');
  $this->post(route('admin.returns.update',$id),['action'=>'receive','restock'=>1])->assertStatus(409);
  $this->post(route('admin.returns.update',$id),['action'=>'approve'])->assertRedirect();
  $this->post(route('admin.returns.update',$id),['action'=>'receive','restock'=>1])->assertRedirect();
  $this->post(route('admin.returns.update',$id),['action'=>'receive','restock'=>1])->assertStatus(409);
  $this->assertSame(5,(int)$v->fresh()->stock);
  config(['services.razorpay.key'=>'test','services.razorpay.secret'=>'secret']);
  Http::fake(['*'=>Http::sequence()->push(['id'=>'rfnd_TEST','payment_id'=>'pay_OTHER','amount'=>10000,'status'=>'processed'])->push(['id'=>'rfnd_TEST','payment_id'=>'pay_TEST','amount'=>10000,'status'=>'processed'])]);
  $this->post(route('admin.returns.refund',$id),['refund_id'=>'rfnd_TEST'])->assertStatus(409);
  $this->post(route('admin.returns.refund',$id),['refund_id'=>'rfnd_TEST'])->assertRedirect();
  $this->post(route('admin.returns.refund',$id),['refund_id'=>'rfnd_TEST'])->assertStatus(409);
  $this->assertDatabaseHas('order_returns',['refund_paise'=>10000,'refund_status'=>'processed']);
 }
 public function test_cod_collection_requires_confirmed_password_and_delivered_order():void {
  [$o]=$this->order('cod','delivered');$u=$this->admin();$this->actingAs($u);
  $this->post(route('admin.orders.cod',$o))->assertStatus(423);
  $this->withSession(['admin_confirmed_user'=>$u->id,'admin_confirmed'=>time()])->post(route('admin.orders.cod',$o))->assertRedirect();
  $this->assertSame('paid',$o->fresh()->payment_status);
  $this->post(route('admin.orders.cod',$o))->assertStatus(409);
 }
 public function test_access_changes_require_password_and_block_self_promotion():void {
  $owner=$this->admin();$customer=User::factory()->create();$this->actingAs($owner);
  $this->post(route('admin.access.update'),['email'=>$customer->email,'role'=>'catalog'])->assertStatus(423);
  $this->withSession(['admin_confirmed_user'=>$owner->id,'admin_confirmed'=>time()])->post(route('admin.access.update'),['email'=>$customer->email,'role'=>'catalog'])->assertRedirect();
  $this->assertSame('catalog',$customer->fresh()->admin_role);
  $this->post(route('admin.access.update'),['email'=>$owner->email,'role'=>'none'])->assertStatus(409);
  $this->assertDatabaseHas('admin_audits',['action'=>'admin.access.update']);
  $this->actingAs($customer->fresh())->post(route('admin.access.update'),['email'=>$customer->email,'role'=>'owner'])->assertForbidden();
 }
 public function test_two_step_verification_blocks_admin_until_email_code_is_verified():void {
  $code=null;Mail::shouldReceive('raw')->once()->andReturnUsing(function($body,$callback)use(&$code){preg_match('/code is ([0-9]{6})/',$body,$m);$code=$m[1];});$u=$this->admin();$u->forceFill(['admin_mfa_enabled'=>true])->save();
  $this->actingAs($u)->get(route('admin.products'))->assertRedirect(route('admin.security'));
  $this->post(route('admin.security.confirm'),['password'=>'password'])->assertRedirect();
  $this->post(route('admin.security.send'))->assertRedirect();
  $this->post(route('admin.security.verify'),['code'=>'000000'])->assertSessionHasErrors('code');
  $this->get(route('admin.products'))->assertRedirect(route('admin.security'));
  $this->post(route('admin.security.verify'),['code'=>$code])->assertRedirect(route('admin.dashboard'));
  $this->get(route('admin.products'))->assertOk();
  $this->post(route('admin.security.verify'),['code'=>$code])->assertSessionHasErrors('code');
 }
 public function test_percentage_discount_is_integer_capped_and_compatible_with_fixed_coupons():void {
  $c=Coupon::create(['code'=>'PERCENT','discount_type'=>'percent','percentage'=>15,'maximum_paise'=>1000,'discount_paise'=>0,'is_active'=>true]);
  $this->assertSame(1000,$c->discount(10000));$this->assertSame(150,$c->discount(1001));
  $f=Coupon::create(['code'=>'FIXED','discount_paise'=>200,'is_active'=>true]);$this->assertSame(200,$f->discount(1000));
 }
 public function test_admin_pages_escape_untrusted_content_and_are_not_cacheable():void {
  $u=$this->admin();$p=Product::create(['title'=>'<script>alert(1)</script>','slug'=>'escaped','price_paise'=>10000]);
  $this->actingAs($u)->get(route('admin.products'))->assertOk()->assertDontSee('<script>alert(1)</script>',false)->assertSee('&lt;script&gt;',false)->assertHeader('Cache-Control','no-store, private');
 }
 public function test_online_cancellation_blocks_fulfilment_until_full_refund_then_restores_once():void {
  [$o,$v]=$this->order('razorpay','processing');$o->update(['payment_status'=>'paid','gateway_payment_id'=>'pay_CANCEL']);
  $u=$this->admin();$this->actingAs($u)->withSession(['admin_confirmed_user'=>$u->id,'admin_confirmed'=>time()]);
  $this->post(route('admin.orders.cancel-online',$o),['reason'=>'Customer requested cancellation'])->assertRedirect(route('admin.returns'));
  $this->post(route('admin.shipping.update',$o),['action'=>'pack'])->assertStatus(409);
  $this->patch(route('admin.orders.update',$o),['status'=>'shipped'])->assertStatus(409);
  $this->assertSame(4,(int)$v->fresh()->stock);
  config(['services.razorpay.key'=>'test','services.razorpay.secret'=>'secret']);
  Http::fake(['*'=>Http::response(['id'=>'rfnd_CANCEL','payment_id'=>'pay_CANCEL','amount'=>10000,'status'=>'processed'])]);
  $id=DB::table('order_returns')->value('id');
  $this->post(route('admin.returns.refund',$id),['refund_id'=>'rfnd_CANCEL'])->assertRedirect();
  $this->assertSame('cancelled',$o->fresh()->status);$this->assertSame(5,(int)$v->fresh()->stock);
  $this->post(route('admin.returns.refund',$id),['refund_id'=>'rfnd_CANCEL'])->assertStatus(409);
 }
 public function test_manual_cod_refund_requires_actual_collection_confirmation_and_is_single_use():void {
  [$o]=$this->order('cod','delivered');$o->update(['payment_status'=>'paid']);$u=$this->admin();
  $this->actingAs($u)->withSession(['admin_confirmed_user'=>$u->id,'admin_confirmed'=>time()]);
  $this->post(route('admin.returns.store'),['order_id'=>$o->id,'reason'=>'Wrong fit']);$id=DB::table('order_returns')->value('id');
  $this->post(route('admin.returns.update',$id),['action'=>'approve']);$this->post(route('admin.returns.update',$id),['action'=>'receive']);
  $this->post(route('admin.returns.cod-refund',$id),['reference'=>'BANK-123'])->assertSessionHasErrors('confirmed');
  $this->post(route('admin.returns.cod-refund',$id),['reference'=>'BANK-123','confirmed'=>1])->assertRedirect();
  $this->post(route('admin.returns.cod-refund',$id),['reference'=>'BANK-123','confirmed'=>1])->assertStatus(409);
  $this->assertDatabaseHas('order_returns',['refund_status'=>'manual','refund_paise'=>10000]);
  $this->get(route('admin.reports'))->assertOk()->assertSee('0.00');
 }
 public function test_sensitive_mutations_require_csrf_and_public_registration_cannot_grant_admin():void {
  $owner=$this->admin();$this->actingAs($owner);$this->app['env']='production';
  try{$this->post(route('admin.access.update'),['email'=>$owner->email,'role'=>'owner'])->assertStatus(419);}
  finally{$this->app['env']='testing';}
  $this->post(route('logout'));$email='customer@example.com';
  $this->post(route('register'),['name'=>'Customer','email'=>$email,'password'=>'StrongPassword123','password_confirmation'=>'StrongPassword123','is_admin'=>1,'admin_role'=>'owner'])->assertRedirect();
  $user=User::where('email',$email)->firstOrFail();$this->assertFalse($user->is_admin);$this->assertNull($user->admin_role);
 }
 public function test_policy_content_is_escaped_and_unconfigured_policies_are_hidden():void {
  $this->get(route('policy','privacy'))->assertNotFound();
  \App\Models\StoreSetting::create(['privacy_policy'=>'<script>alert(1)</script>']);
  $this->get(route('policy','privacy'))->assertOk()->assertSee('&lt;script&gt;',false)->assertDontSee('<script>alert(1)</script>',false);
 }

 public function test_populated_coupon_pages_render_and_update_preserves_used_count():void {
  $u=$this->admin();$c=Coupon::create(['code'=>'EXISTING','discount_paise'=>500,'minimum_paise'=>0,'is_active'=>true,'used_count'=>2,'starts_at'=>now()->subDay(),'expires_at'=>now()->addDay()]);
  $this->actingAs($u)->get(route('admin.coupons'))->assertOk()->assertSee('EXISTING');
  $this->post(route('admin.coupons.update',$c),['code'=>'UPDATED','discount_type'=>'percent','discount_paise'=>0,'percentage'=>10,'minimum_paise'=>0])->assertRedirect();
  $this->assertSame(2,$c->fresh()->used_count);$this->assertSame('percent',$c->fresh()->discount_type);
  $this->post(route('admin.coupons.update',$c),['code'=>'UPDATED','discount_type'=>'fixed','discount_paise'=>100,'minimum_paise'=>0,'usage_limit'=>1])->assertSessionHasErrors('usage_limit');
 }
 public function test_revoked_admin_session_cannot_silently_reinitialize_access():void {
  $u=$this->admin();$this->actingAs($u)->get(route('admin.dashboard'))->assertOk();
  $u->forceFill(['admin_session_version'=>1])->save();
  $this->get(route('admin.products'))->assertRedirect(route('admin.security'));
  $this->get(route('admin.products'))->assertRedirect(route('admin.security'));
  $this->post(route('admin.security.confirm'),['password'=>'password'])->assertRedirect();
  $this->get(route('admin.products'))->assertOk();
 }

 public function test_paginated_catalog_keeps_filters_and_uses_admin_controls():void {
  $u=$this->admin();for($i=1;$i<=25;$i++)Product::create(['title'=>'Jeans '.$i,'slug'=>'pagination-'.$i,'price_paise'=>10000,'is_active'=>true]);
  $this->actingAs($u)->get(route('admin.products',['q'=>'Jeans','status'=>'live']))->assertOk()->assertSee('Page 1 of 2')->assertSee('Next');
  $this->get(route('admin.products',['q'=>'Jeans','status'=>'live','page'=>2]))->assertOk()->assertSee('Page 2 of 2')->assertSee('Previous');
 }

}
