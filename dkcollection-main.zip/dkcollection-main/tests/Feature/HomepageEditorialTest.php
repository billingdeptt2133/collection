<?php

namespace Tests\Feature;

use App\Models\{Category, Product, StoreSetting, User};
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use Tests\TestCase;

class HomepageEditorialTest extends TestCase
{
    use RefreshDatabase;

    private function product(): Product
    {
        $category = Category::create(['name' => 'Straight Fit', 'slug' => 'straight', 'is_active' => true]);
        $product = Product::create(['category_id' => $category->id, 'title' => 'Real Denim', 'slug' => 'real-denim', 'article_code' => '1234', 'price_paise' => 149900, 'mrp_paise' => 199900, 'is_active' => true]);
        $product->variants()->create(['size' => '30', 'color' => 'Blue', 'stock' => 4]);
        $product->variants()->create(['size' => '32', 'color' => 'Blue', 'stock' => 0]);
        return $product;
    }

    public function test_reference_ui_uses_real_product_links_counts_and_existing_wishlist_route(): void
    {
        $product = $this->product();
        $user = User::factory()->create();
        DB::table('wishlists')->insert(['user_id' => $user->id, 'product_id' => $product->id]);
        StoreSetting::create(['id' => 1, 'name' => 'Jansen Jeans', 'homepage' => ['featured_ids' => [$product->id]]]);
        $variant = $product->variants()->where('stock', '>', 0)->first();
        $response = $this->actingAs($user)->withSession(['cart' => [$variant->id => 2]])->get(route('home'))->assertOk();
        $response->assertSee('home-editorial.css')->assertSee('home-editorial.js')->assertSee('BEST SELLER')->assertSee('Blue Real Denim')
            ->assertSee(route('products.show', ['slug' => 'real-denim', 'color' => 'Blue']))->assertSee(route('wishlist.toggle', $product))
            ->assertSee('Shopping bag, 2 items')->assertSee('aria-pressed="true"', false)->assertDontSee('handleSubscribe')->assertDontSee('onclick=', false)->assertDontSee('data:image', false);
        $this->assertSame([4, 0], $product->variants()->orderBy('id')->pluck('stock')->all());
        $this->post(route('wishlist.toggle', $product))->assertRedirect();
        $this->assertDatabaseMissing('wishlists', ['user_id' => $user->id, 'product_id' => $product->id]);
    }

    public function test_search_categories_prices_and_sold_out_keep_existing_server_behavior(): void
    {
        $product = $this->product();
        $this->get(route('home', ['q' => 'Real']))->assertOk()->assertSee('Blue Real Denim')->assertSee('25% OFF');
        $this->get(route('home', ['category' => 'straight']))->assertOk()->assertSee('Blue Real Denim');
        $this->get(route('home', ['q' => 'not-present']))->assertOk()->assertDontSee('Blue Real Denim')->assertSee('No products found');
        $product->variants()->update(['stock' => 0]);
        $this->get(route('home'))->assertOk()->assertSee('Sold out')->assertDontSee('>+ ADD</a>', false);
        $product->update(['is_active' => false]);
        $this->get(route('home'))->assertOk()->assertDontSee('Blue Real Denim');
    }

}
