<?php
namespace Tests\Feature;

use App\Models\{Product,User,Order};
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Tests\TestCase;

class ProductEditorTest extends TestCase
{
    use RefreshDatabase;
    private function admin(string $role='catalog'): User {
        $user=User::factory()->create();$user->forceFill(['is_admin'=>true,'admin_role'=>$role])->save();return $user;
    }
    private function payload(): array {
        return ['title'=>'Grid Jeans','price_paise'=>120000,'is_active'=>1,'colours'=>[
            ['name'=>'Black','sizes'=>[['size'=>'28','stock'=>0],['size'=>'30','stock'=>10]],'photos'=>[UploadedFile::fake()->image('black.jpg')]],
            ['name'=>'Blue','sizes'=>[['size'=>'28','stock'=>3],['size'=>'30','stock'=>0]],'photos'=>[UploadedFile::fake()->image('blue.jpg')]],
        ]];
    }
    public function test_product_write_rejects_missing_csrf_token(): void {
        $this->actingAs($this->admin())->withSession(['_token'=>str_repeat('a',40)]);
        app('router')->getRoutes()->getByName('admin.products.store')->middleware(EnforcedProductCsrf::class);
        $this->post(route('admin.products.store'),['title'=>'CSRF attempt','price_paise'=>100,'variants'=>'28,Black,0'])->assertStatus(419);
        $this->assertDatabaseCount('products',0);
    }
    public function test_friendly_editor_draft_publish_and_validation_retain_data(): void {
        Storage::fake('public');$this->actingAs($this->admin());
        $this->get(route('admin.products.create'))->assertOk()->assertSee('Product readiness')->assertSee('Save draft')->assertSee('Publish product')->assertSee('Optional SEO');
        $data=$this->payload();$data['is_active']=0;
        $this->post(route('admin.products.store'),$data)->assertSessionHasNoErrors();$product=Product::firstOrFail();$this->assertFalse($product->is_active);
        $this->get(route('admin.products.edit',$product))->assertOk()->assertSee('Danger zone')->assertSee('data-upload-previews',false);
        $data=$this->payload();$data['stock_snapshot']=hash('sha256',$product->variants()->orderBy('id')->get()->map(fn($v)=>$v->id.':'.$v->stock)->implode('|'));
        $this->post(route('admin.products.update',$product),$data)->assertRedirect(route('admin.products.edit',$product))->assertSessionHasNoErrors();$this->assertTrue($product->fresh()->is_active);
    }
    public function test_grid_saves_separate_colour_stock_and_matching_photos(): void {
        Storage::fake('public');$this->actingAs($this->admin());
        $this->post(route('admin.products.store'),$this->payload())->assertRedirect()->assertSessionHasNoErrors();
        $product=Product::firstOrFail();$this->assertCount(4,$product->variants);$this->assertCount(2,$product->images);
        $this->assertDatabaseHas('variants',['product_id'=>$product->id,'color'=>'Black','size'=>'30','stock'=>10]);
        foreach($product->images as $image) Storage::disk('public')->assertExists($image->path);
        $this->get(route('products.show',$product->slug))->assertOk()->assertSee('Black')->assertSee('Blue');
        $this->get(route('admin.products.edit',$product))->assertOk()->assertSee('Size 40')->assertSee('data-colour-editor',false);
    }
    public function test_grid_rejects_negative_stock_duplicate_colours_and_executable_uploads(): void {
        Storage::fake('public');$this->actingAs($this->admin());
        $data=$this->payload();$data['colours'][0]['sizes'][0]['stock']=-1;
        $this->post(route('admin.products.store'),$data)->assertSessionHasErrors('colours.0.sizes.0.stock');
        $data=$this->payload();$data['colours'][1]['name']='black';
        $this->post(route('admin.products.store'),$data)->assertSessionHasErrors('colours');
        $data=$this->payload();$data['colours'][0]['photos']=[UploadedFile::fake()->create('shell.php',1,'application/x-php')];
        $this->post(route('admin.products.store'),$data)->assertSessionHasErrors('colours.0.photos.0');
        $this->assertDatabaseCount('products',0);
    }
    public function test_updates_preserve_variant_ids_and_reject_stale_grid_stock(): void {
        Storage::fake('public');$this->actingAs($this->admin());
        $this->post(route('admin.products.store'),$this->payload())->assertSessionHasNoErrors();$product=Product::firstOrFail();
        $before=$product->variants()->orderBy('id')->get();$snapshot=hash('sha256',$before->map(fn($v)=>$v->id.':'.$v->stock)->implode('|'));
        $data=$this->payload();unset($data['colours'][0]['photos'],$data['colours'][1]['photos']);$data['stock_snapshot']=$snapshot;
        $data['colours'][0]['sizes'][1]['stock']=8;
        $this->post(route('admin.products.update',$product),$data)->assertSessionHasNoErrors();
        $this->assertSame($before->pluck('id')->all(),$product->variants()->orderBy('id')->pluck('id')->all());
        $this->post(route('admin.products.update',$product),$data)->assertStatus(409);
        $this->assertDatabaseHas('variants',['product_id'=>$product->id,'color'=>'Black','size'=>'30','stock'=>8]);
    }
    public function test_order_linked_product_can_be_trashed_but_never_permanently_deleted(): void {
        $admin=$this->admin();$this->actingAs($admin);
        $product=Product::create(['title'=>'Order jeans','slug'=>'order-jeans','price_paise'=>100]);
        $variant=$product->variants()->create(['size'=>'28','color'=>'Black','stock'=>1]);
        $order=Order::create(['user_id'=>User::factory()->create()->id,'checkout_token'=>(string)Str::uuid(),'name'=>'Buyer','phone'=>'9876543210','address'=>'Test address','city'=>'Jaipur','state'=>'Rajasthan','pincode'=>'302001','subtotal_paise'=>100,'total_paise'=>100,'payment_method'=>'cod']);
        $order->items()->create(['variant_id'=>$variant->id,'title'=>'Order jeans','size'=>'28','color'=>'Black','price_paise'=>100,'quantity'=>1]);
        $this->delete(route('admin.products.delete',$product))->assertRedirect(route('admin.products.recycle-bin'));
        $this->assertSoftDeleted('products',['id'=>$product->id]);
        $this->withSession(['admin_confirmed_user'=>$admin->id,'admin_confirmed'=>time()])->from(route('admin.products.recycle-bin'))->delete(route('admin.products.force-delete',$product),['confirmation'=>'DELETE'])->assertRedirect(route('admin.products.recycle-bin'))->assertSessionHasErrors('product');
        $this->assertDatabaseHas('order_items',['variant_id'=>$variant->id]);
        $this->assertSame(1,(int)$variant->fresh()->stock);
    }
    public function test_unused_trashed_product_can_be_deleted_but_customer_and_support_cannot_delete(): void {
        Storage::fake('public');$product=Product::create(['title'=>'Unused','slug'=>'unused','price_paise'=>100,'image_path'=>'products/test.jpg']);Storage::disk('public')->put('products/test.jpg','image');
        $product->variants()->create(['size'=>'28','color'=>'Black','stock'=>0]);
        $this->actingAs(User::factory()->create())->delete(route('admin.products.delete',$product))->assertForbidden();
        $this->actingAs($this->admin('support'))->delete(route('admin.products.delete',$product))->assertForbidden();
        $admin=$this->admin();$this->actingAs($admin)->delete(route('admin.products.delete',$product))->assertRedirect();
        $this->delete(route('admin.products.force-delete',$product),['confirmation'=>'DELETE'])->assertRedirect(route('admin.security'));
        $this->withSession(['admin_confirmed_user'=>$admin->id,'admin_confirmed'=>time()])->delete(route('admin.products.force-delete',$product),['confirmation'=>'DELETE'])->assertRedirect(route('admin.products.recycle-bin'));
        $this->assertDatabaseMissing('products',['id'=>$product->id]);Storage::disk('public')->assertMissing('products/test.jpg');
    }
}

class EnforcedProductCsrf extends \Illuminate\Foundation\Http\Middleware\ValidateCsrfToken
{
    protected function runningUnitTests() { return false; }
}
