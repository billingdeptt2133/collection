<?php

namespace Tests\Feature;

use App\Models\Category;
use App\Models\Coupon;
use App\Models\Order;
use App\Models\Product;
use App\Models\StoreSetting;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Notification;
use Illuminate\Support\Facades\Password;
use Illuminate\Auth\Notifications\ResetPassword;
use Illuminate\Http\Middleware\TrustHosts;
use Tests\TestCase;

class CommerceTest extends TestCase
{
    use RefreshDatabase;

    private function catalog(): array
    {
        StoreSetting::create(['id' => 1, 'delivery_mode' => 'all', 'checkout_enabled' => true, 'cod_enabled' => true, 'online_enabled' => true]);
        $category = Category::create(['name' => 'Jeans', 'slug' => 'jeans', 'is_active' => true]);
        $product = Product::create(['category_id' => $category->id, 'title' => 'Classic Jeans', 'slug' => 'classic-jeans', 'price_paise' => 159900, 'is_active' => true]);
        $variant = $product->variants()->create(['size' => '32', 'color' => 'Blue', 'stock' => 2]);

        return [$product, $variant];
    }

    public function test_home_shows_published_sold_out_products_but_hides_archived_products(): void
    {
        [$product, $variant] = $this->catalog();
        $this->get('/')->assertOk()->assertSee('Classic Jeans');
        $variant->update(['stock' => 0]);
        $this->get('/')->assertOk()->assertSee('Classic Jeans')->assertSee('Sold out');
        $product->update(['is_active'=>false]);
        $this->get('/')->assertOk()->assertDontSee('Classic Jeans');
    }

    public function test_checkout_recalculates_price_and_decrements_stock(): void
    {
        [$product, $variant] = $this->catalog();
        $user = User::factory()->create();
        $this->actingAs($user)->post(route('cart.add'), ['variant_id' => $variant->id, 'quantity' => 2])->assertRedirect(route('cart'));
        $this->get(route('checkout'))->assertOk();
        $token = session('checkout_token');
        $data = ['checkout_token' => $token, 'name' => 'Test Customer', 'phone' => '9876543210', 'address' => '123 Main Road',
            'city' => 'Jaipur', 'state' => 'Rajasthan', 'pincode' => '302001', 'payment_method' => 'cod'];
        $this->post(route('checkout.place'), $data + ['total_paise' => 1])->assertRedirect();
        $order = Order::firstOrFail();
        $this->assertSame(319800, $order->total_paise);
        $this->assertSame(0, $variant->fresh()->stock);
        $this->assertCount(1, $order->items);
        $this->post(route('checkout.place'), $data)->assertSessionHasErrors('cart');
        $this->withSession(['checkout_token' => $token])->post(route('checkout.place'), $data)->assertRedirect(route('orders.show', $order));
        $this->assertDatabaseCount('orders', 1);
        $this->assertSame(0, $variant->fresh()->stock);
        $other = User::factory()->create();
        $this->actingAs($other)->get(route('orders.show', $order))->assertNotFound();
    }
    public function test_buyer_can_register_and_complete_cod_purchase(): void
    {
        [$product, $variant] = $this->catalog();
        $this->get(route('home'))->assertOk()->assertSee('Classic Jeans');
        $this->get(route('products.show', $product->slug))->assertOk()->assertSee('Classic Jeans');
        $this->post(route('cart.add'), ['variant_id' => $variant->id, 'quantity' => 1])->assertRedirect(route('cart'));
        $this->get(route('cart'))->assertOk()->assertSee('Classic Jeans');
        $this->post(route('register'), [
            'name' => 'Buyer', 'email' => 'buyer@example.test',
            'password' => 'StrongPassword123!', 'password_confirmation' => 'StrongPassword123!',
        ])->assertRedirect(route('home'));
        $this->assertAuthenticated();
        $this->get(route('checkout'))->assertOk();
        $this->post(route('checkout.place'), [
            'checkout_token' => session('checkout_token'), 'name' => 'Buyer', 'phone' => '9876543210',
            'address' => '123 Main Road', 'city' => 'Jaipur', 'state' => 'Rajasthan',
            'pincode' => '302001', 'payment_method' => 'cod',
        ])->assertSessionHasNoErrors();
        $order = Order::firstOrFail();
        $this->get(route('orders.show', $order))->assertOk()->assertSee('Classic Jeans');
        $this->assertSame(1, $variant->fresh()->stock);
    }

    public function test_customer_cannot_access_admin(): void
    {
        $this->actingAs(User::factory()->create())->get(route('admin.dashboard'))->assertForbidden();
    }
    public function test_customer_can_reset_password_with_one_time_token(): void
    {
        $user = User::factory()->create(['email' => 'buyer@example.test']);
        Notification::fake();
        $this->get(route('password.request'))->assertOk();
        $this->post(route('password.email'), ['email' => $user->email])->assertRedirect();
        Notification::assertSentTo($user, ResetPassword::class);
        $token = Password::createToken($user);
        $this->get(route('password.reset', ['token' => $token, 'email' => $user->email]))->assertOk();
        $this->post(route('password.update'), [
            'token' => $token, 'email' => $user->email,
            'password' => 'AnotherStrongPassword123!', 'password_confirmation' => 'AnotherStrongPassword123!',
        ])->assertRedirect(route('login'));
        $this->assertTrue(Hash::check('AnotherStrongPassword123!', $user->fresh()->password));
        $this->post(route('password.update'), [
            'token' => $token, 'email' => $user->email,
            'password' => 'ThirdStrongPassword123!', 'password_confirmation' => 'ThirdStrongPassword123!',
        ])->assertSessionHasErrors('email');
    }
    public function test_untrusted_host_cannot_generate_store_urls(): void
    {
        $patterns = app(TrustHosts::class)->hosts();
        $this->assertNotEmpty($patterns);
        $this->assertSame(1, preg_match('/'.implode('|', $patterns).'/', (string) parse_url(config('app.url'), PHP_URL_HOST)));
        $this->assertSame(0, preg_match('/'.implode('|', $patterns).'/', 'other.example.test'));
    }
    public function test_product_cart_and_admin_pages_render(): void
    {
        [$product, $variant] = $this->catalog();
        $this->get(route('products.show', $product->slug))->assertOk()->assertSee('Classic Jeans');
        $this->post(route('cart.add'), ['variant_id' => $variant->id, 'quantity' => 1])->assertRedirect(route('cart'));
        $this->get(route('cart'))->assertOk()->assertSee('Classic Jeans');
        $admin = User::factory()->create();
        $admin->forceFill(['is_admin' => true])->save();
        $this->actingAs($admin)->get(route('admin.dashboard'))->assertOk()->assertSee('Classic Jeans');
    }

    public function test_out_of_stock_items_cannot_be_ordered(): void
    {
        [$product, $variant] = $this->catalog();
        $this->actingAs(User::factory()->create())->post(route('cart.add'), ['variant_id' => $variant->id, 'quantity' => 2]);
        $this->get(route('checkout'))->assertOk();
        $variant->update(['stock' => 1]);
        $this->post(route('checkout.place'), ['checkout_token' => session('checkout_token'), 'name' => 'Customer',
            'phone' => '9876543210', 'address' => '123 Main Road', 'city' => 'Jaipur', 'state' => 'Rajasthan',
            'pincode' => '302001', 'payment_method' => 'cod'])->assertSessionHasErrors('cart');
        $this->assertDatabaseCount('orders', 0);
    }
    public function test_disabled_checkout_does_not_create_orders(): void
    {
        [$product, $variant] = $this->catalog();
        $this->actingAs(User::factory()->create())->post(route('cart.add'), ['variant_id' => $variant->id, 'quantity' => 1]);
        $this->get(route('checkout'))->assertOk();
        StoreSetting::firstOrFail()->update(['checkout_enabled' => false]);
        $this->post(route('checkout.place'), [
            'checkout_token' => session('checkout_token'), 'name' => 'Buyer', 'phone' => '9876543210',
            'address' => '123 Main Road', 'city' => 'Jaipur', 'state' => 'Rajasthan',
            'pincode' => '302001', 'payment_method' => 'cod',
        ])->assertSessionHasErrors('pincode');
        $this->assertDatabaseCount('orders', 0);
        $this->assertSame(2, $variant->fresh()->stock);
    }
    public function test_razorpay_payment_requires_valid_signature_and_captured_status(): void
    {
        config(['services.razorpay.key' => 'test_key', 'services.razorpay.secret' => 'test_secret']);
        Http::fake([
            'api.razorpay.com/v1/orders' => Http::response(['id' => 'order_ABC123'], 200),
            'api.razorpay.com/v1/payments/pay_ABC123' => Http::response([
                'id' => 'pay_ABC123', 'order_id' => 'order_ABC123', 'amount' => 159900, 'currency' => 'INR', 'status' => 'captured',
            ], 200),
        ]);
        [$product, $variant] = $this->catalog();
        $this->actingAs(User::factory()->create())->post(route('cart.add'), ['variant_id' => $variant->id, 'quantity' => 1]);
        $this->get(route('checkout'))->assertOk();
        $this->post(route('checkout.place'), ['checkout_token' => session('checkout_token'), 'name' => 'Customer',
            'phone' => '9876543210', 'address' => '123 Main Road', 'city' => 'Jaipur', 'state' => 'Rajasthan',
            'pincode' => '302001', 'payment_method' => 'razorpay'])->assertRedirect();
        $order = Order::firstOrFail();
        $this->assertSame('pending', $order->payment_status);
        $this->post(route('payments.verify', $order), ['razorpay_order_id' => 'order_ABC123',
            'razorpay_payment_id' => 'pay_ABC123', 'razorpay_signature' => str_repeat('a', 64)])->assertSessionHasErrors('payment');
        $this->assertSame('pending', $order->fresh()->payment_status);
        $signature = hash_hmac('sha256', 'order_ABC123|pay_ABC123', 'test_secret');
        $this->post(route('payments.verify', $order), ['razorpay_order_id' => 'order_ABC123',
            'razorpay_payment_id' => 'pay_ABC123', 'razorpay_signature' => $signature])->assertRedirect();
        $this->assertSame('paid', $order->fresh()->payment_status);
    }
    public function test_admin_can_publish_product_with_variants(): void
    {
        $admin = User::factory()->create();
        $admin->forceFill(['is_admin' => true])->save();
        $this->actingAs($admin)->post(route('admin.products.store'), [
            'title' => 'New Shirt', 'price_paise' => 99900, 'variants' => "M,Black,3\nL,Black,4", 'is_active' => 1,
        ])->assertSessionHasNoErrors();
        $product = Product::where('title', 'New Shirt')->firstOrFail();
        $this->assertSame(2, $product->variants()->count());
        $this->get(route('products.show', $product->slug))->assertOk();
    }
    public function test_offline_label_fields_and_stock_are_managed_in_admin(): void
    {
        $admin = User::factory()->create();
        $admin->forceFill(['is_admin' => true])->save();
        $this->actingAs($admin)->get(route('admin.dashboard', ['tab' => 'products']))
            ->assertOk()->assertSee('data-admin-link="products"', false)->assertSee('js/admin.js');
        $this->post(route('admin.products.store'), [
            'title' => 'Sample Slim Jeans', 'product_code' => 'RT-141', 'article_code' => '1340',
            'pattern' => 'Slim', 'price_rupees' => '1299.00', 'mrp_rupees' => '1749',
            'variants' => '32,Indigo,8,IBST,6732', 'is_active' => 1,
        ])->assertSessionHasNoErrors();
        $product = Product::where('product_code', 'RT-141')->firstOrFail();
        $this->assertSame(129900, $product->price_paise);
        $this->assertSame(174900, $product->mrp_paise);
        $this->assertSame('1340', $product->article_code);
        $this->assertSame('IBST', $product->variants()->firstOrFail()->shade_code);
        $this->assertSame('6732', $product->variants()->firstOrFail()->barcode);
        $this->get(route('products.show', $product->slug))->assertOk()->assertSee('RT-141')->assertSee('Slim');
        $this->post(route('admin.products.update', $product), [
            'title' => 'Sample Slim Jeans', 'product_code' => 'RT-141', 'article_code' => '1340',
            'pattern' => 'Slim', 'price_paise' => 129900, 'variants' => '32,Indigo,3,IBST,6732',
            'is_active' => 1,
        ])->assertSessionHasNoErrors();
        $this->assertSame(3, $product->variants()->firstOrFail()->stock);
        $this->post(route('admin.products.store'), [
            'title' => 'Another Jeans', 'price_paise' => 100000, 'variants' => '34,Blue,2,BLUE,6732',
        ])->assertSessionHasErrors('variants');
    }
    public function test_admin_cannot_fulfil_an_unpaid_online_order(): void
    {
        [$product, $variant] = $this->catalog();
        $admin = User::factory()->create();
        $admin->forceFill(['is_admin' => true])->save();
        $order = Order::create(['user_id' => $admin->id, 'checkout_token' => (string) \Illuminate\Support\Str::uuid(),
            'name' => 'Customer', 'phone' => '9876543210', 'address' => '123 Main Road', 'city' => 'Jaipur',
            'state' => 'Rajasthan', 'pincode' => '302001', 'payment_method' => 'razorpay',
            'subtotal_paise' => 159900, 'total_paise' => 159900]);
        $this->actingAs($admin)->patch(route('admin.orders.update', $order), ['status' => 'shipped'])->assertStatus(409);
        $this->assertSame('pending', $order->fresh()->status);
        $order->update(['payment_status' => 'paid', 'status' => 'processing']);
        $this->patch(route('admin.orders.update', $order), ['status' => 'shipped'])->assertRedirect();
        $this->patch(route('admin.orders.update', $order), ['status' => 'pending'])->assertStatus(409);
    }
    public function test_coupon_and_cancellation_restore_stock(): void
    {
        [$product, $variant] = $this->catalog();
        Coupon::create(['code' => 'SAVE100', 'discount_paise' => 10000, 'minimum_paise' => 100000, 'is_active' => true]);
        $user = User::factory()->create();
        $this->actingAs($user)->post(route('cart.add'), ['variant_id' => $variant->id, 'quantity' => 1]);
        $this->get(route('checkout'));
        $this->post(route('checkout.place'), ['checkout_token' => session('checkout_token'), 'name' => 'Customer',
            'phone' => '9876543210', 'address' => '123 Main Road', 'city' => 'Jaipur', 'state' => 'Rajasthan',
            'pincode' => '302001', 'payment_method' => 'cod', 'coupon' => 'SAVE100'])->assertRedirect();
        $order = Order::firstOrFail();
        $this->assertSame(149900, $order->total_paise);
        $this->assertSame(1, $variant->fresh()->stock);
        $admin = User::factory()->create();
        $admin->forceFill(['is_admin' => true])->save();
        $this->actingAs($admin)->patch(route('admin.orders.update', $order), ['status' => 'cancelled'])->assertRedirect();
        $this->assertSame(2, $variant->fresh()->stock);
        $this->assertSame(0, Coupon::firstOrFail()->used_count);
    }
    public function test_public_seo_pages_exclude_drafts_and_private_pages(): void
    {
        [$product, $variant] = $this->catalog();
        $product->update(['seo_title' => 'Classic Blue Jeans', 'seo_description' => 'Comfortable everyday denim.']);
        Product::create(['title' => 'Hidden Product', 'slug' => 'hidden-product', 'price_paise' => 50000, 'is_active' => false]);
        $this->get(route('products.show', $product->slug))->assertOk()->assertSee('Comfortable everyday denim.')->assertSee('application/ld+json');
        $sitemap = $this->get(route('sitemap'))->assertOk()->streamedContent();
        $this->assertStringContainsString('/products/classic-jeans', $sitemap);
        $this->assertStringNotContainsString('hidden-product', $sitemap);
        $this->get(route('robots'))->assertOk()->assertSee('Sitemap:');
        $this->get(route('cart'))->assertOk()->assertSee('noindex,follow');
    }

    public function test_delivery_settings_gate_checkout_and_pincode(): void
    {
        [$product, $variant] = $this->catalog();
        $settings = StoreSetting::firstOrFail();
        $settings->update(['checkout_enabled' => false]);
        $this->get(route('delivery.check', ['pincode' => '302001']))->assertJsonPath('available', false);
        $settings->update(['delivery_mode' => 'allowlist', 'checkout_enabled' => true]);
        $this->get(route('delivery.check', ['pincode' => '302001']))->assertJsonPath('available', false);
        \App\Models\ShippingPincode::create(['pincode' => '302001', 'is_active' => true, 'cod_available' => true]);
        $this->get(route('delivery.check', ['pincode' => '302001']))->assertJsonPath('cod', true);
    }
    public function test_admin_controls_shipping_and_checkout_total(): void
    {
        [$product, $variant] = $this->catalog();
        $admin = User::factory()->create();
        $admin->forceFill(['is_admin' => true])->save();
        $this->actingAs($admin)->post(route('admin.settings.update'), [
            'name' => 'DK Fashion Hub', 'delivery_mode' => 'allowlist', 'flat_shipping_paise' => 5000,
            'cod_fee_paise' => 2500, 'checkout_enabled' => 1, 'cod_enabled' => 1,
        ])->assertSessionHasErrors('delivery_mode');
        $this->post(route('admin.pincodes.store'), ['pincode' => '302001', 'cod_available' => 1])->assertSessionHasNoErrors();
        $this->post(route('admin.settings.update'), [
            'name' => 'DK Fashion Hub', 'delivery_mode' => 'allowlist', 'flat_shipping_paise' => 5000,
            'cod_fee_paise' => 2500, 'checkout_enabled' => 1, 'cod_enabled' => 1,
        ])->assertSessionHasNoErrors();
        $buyer = User::factory()->create();
        $this->actingAs($buyer)->post(route('cart.add'), ['variant_id' => $variant->id, 'quantity' => 1]);
        $this->get(route('checkout'))->assertOk();
        $this->post(route('checkout.place'), ['checkout_token' => session('checkout_token'), 'name' => 'Customer',
            'phone' => '9876543210', 'address' => '123 Main Road', 'city' => 'Jaipur', 'state' => 'Rajasthan',
            'pincode' => '302001', 'payment_method' => 'cod'])->assertRedirect();
        $order = Order::firstOrFail();
        $this->assertSame(167400, $order->total_paise);
        $this->actingAs($admin)->get(route('admin.orders.show', $order))->assertOk()->assertSee('123 Main Road');
    }
    public function test_demo_catalog_is_idempotent_and_shows_up_to_twenty_products(): void
    {
        $this->seed(\Database\Seeders\DemoCatalogSeeder::class);
        $this->seed(\Database\Seeders\DemoCatalogSeeder::class);
        $this->assertDatabaseCount('categories', 4);
        $this->assertDatabaseCount('products', 16);
        $this->assertDatabaseCount('variants', 96);
        $first = $this->get(route('home'))->assertOk()->assertDontSee('Show more products')->assertSee('Ankle Fit');
        $this->assertSame(16, substr_count($first->getContent(), '<article class="product-card" '));
        $this->assertStringNotContainsString('demo-', $this->get(route('sitemap'))->streamedContent());
        $admin = User::factory()->create();
        $admin->forceFill(['is_admin' => true])->save();
        $this->actingAs($admin)->post(route('admin.products.archive-demos'))->assertRedirect();
        $this->assertSame(0, Product::where('is_demo', true)->where('is_active', true)->count());
    }
    public function test_seo_fields_are_escaped_in_html(): void
    {
        [$product, $variant] = $this->catalog();
        $product->update(['seo_title' => '<script>alert(1)</script>', 'seo_description' => '" onmouseover="alert(1)']);
        $html = $this->get(route('products.show', $product->slug))->assertOk()->getContent();
        $this->assertStringNotContainsString('<script>alert(1)</script>', $html);
        $this->assertStringNotContainsString('content="" onmouseover=', $html);
        $this->assertStringContainsString('&lt;script&gt;', $html);
    }
}
