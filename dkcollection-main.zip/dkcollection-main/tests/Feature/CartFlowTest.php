<?php

namespace Tests\Feature;

use App\Models\Order;
use App\Models\Product;
use App\Models\StoreSetting;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class CartFlowTest extends TestCase
{
    use RefreshDatabase;

    private function catalog(): array
    {
        StoreSetting::create(['id' => 1, 'delivery_mode' => 'all', 'checkout_enabled' => true, 'cod_enabled' => true]);
        $product = Product::create(['title' => 'Blue Jeans', 'slug' => 'blue-jeans', 'price_paise' => 149900, 'is_active' => true]);
        $blue = $product->variants()->create(['size' => '28', 'color' => 'Blue', 'stock' => 5]);
        $black = $product->variants()->create(['size' => '30', 'color' => 'Black', 'stock' => 3]);
        return [$product, $blue, $black];
    }

    private function orderData(): array
    {
        return ['checkout_token' => session('checkout_token'), 'name' => 'Buyer', 'phone' => '9876543210',
            'address' => '123 Main Road', 'city' => 'Jaipur', 'state' => 'Rajasthan',
            'pincode' => '302001', 'payment_method' => 'cod'];
    }

    public function test_guest_bag_survives_registration_and_returns_to_checkout(): void
    {
        [$product, $blue] = $this->catalog();
        $this->post(route('cart.add'), ['variant_id' => $blue->id, 'quantity' => 2])->assertRedirect(route('cart'));
        $this->assertGuest();
        $this->get(route('cart'))->assertOk()->assertSee('Your Shopping Bag')->assertSee('Blue Jeans');
        $this->get(route('checkout'))->assertOk();
        $this->post(route('checkout.login'), ['checkout_token' => session('checkout_token')])->assertRedirect(route('login'));
        $this->get(route('login'))->assertOk()->assertSee('Your shopping bag will stay with you.');
        $this->post(route('register'), ['name' => 'Buyer', 'email' => 'buyer@example.test',
            'password' => 'StrongPassword123!', 'password_confirmation' => 'StrongPassword123!'])
            ->assertRedirect(route('checkout'))->assertSessionHas('cart', [$blue->id => 2]);
        $this->get(route('checkout'))->assertOk()->assertSee('2 items');
        $this->post(route('checkout.place'), $this->orderData())->assertSessionHasNoErrors();
        $this->assertSame(2, Order::firstOrFail()->items()->firstOrFail()->quantity);
    }

    public function test_existing_customer_login_preserves_guest_bag(): void
    {
        [, $blue] = $this->catalog();
        $user = User::factory()->create(['password' => 'StrongPassword123!']);
        $this->post(route('cart.add'), ['variant_id' => $blue->id, 'quantity' => 1]);
        $this->get(route('checkout'))->assertOk();
        $this->post(route('checkout.login'), ['checkout_token' => session('checkout_token')])->assertRedirect(route('login'));
        $this->post(route('login.submit'), ['email' => $user->email, 'password' => 'StrongPassword123!'])
            ->assertRedirect(route('checkout'))->assertSessionHas('cart', [$blue->id => 1]);
    }

    public function test_buy_now_orders_only_selected_variant_and_keeps_bag(): void
    {
        [, $blue, $black] = $this->catalog();
        $this->post(route('cart.add'), ['variant_id' => $blue->id, 'quantity' => 2]);
        $this->post(route('buy-now'), ['variant_id' => $black->id, 'quantity' => 1])
            ->assertRedirect(route('checkout', ['mode' => 'buy-now']));
        $this->get(route('checkout', ['mode' => 'buy-now']))->assertOk();
        $this->post(route('checkout.login'), ['checkout_token' => session('checkout_token')])->assertRedirect(route('login'));
        $user = User::factory()->create(['password' => 'StrongPassword123!']);
        $this->post(route('login.submit'), ['email' => $user->email, 'password' => 'StrongPassword123!'])
            ->assertRedirect(route('checkout', ['mode' => 'buy-now']));
        $this->get(route('checkout', ['mode' => 'buy-now']))->assertOk()->assertSee('1 item');
        $this->post(route('checkout.place'), $this->orderData())->assertSessionHasNoErrors()
            ->assertSessionHas('cart', [$blue->id => 2])->assertSessionMissing('buy_now');
        $order = Order::firstOrFail();
        $this->assertCount(1, $order->items);
        $this->assertSame($black->id, $order->items->first()->variant_id);
        $this->assertSame(5, $blue->fresh()->stock);
        $this->assertSame(2, $black->fresh()->stock);
    }

    public function test_switching_checkout_mode_invalidates_previous_form(): void
    {
        [, $blue, $black] = $this->catalog();
        $this->actingAs(User::factory()->create());
        $this->post(route('cart.add'), ['variant_id' => $blue->id, 'quantity' => 1]);
        $this->post(route('buy-now'), ['variant_id' => $black->id, 'quantity' => 1]);
        $this->get(route('checkout', ['mode' => 'buy-now']));
        $data = $this->orderData();
        $this->get(route('checkout'));
        $this->post(route('checkout.place'), $data)->assertSessionHasErrors('cart');
        $this->assertDatabaseCount('orders', 0);
    }

    public function test_cart_can_edit_variant_but_cannot_switch_to_another_product(): void
    {
        [, $blue, $black] = $this->catalog();
        $this->post(route('cart.add'), ['variant_id' => $blue->id, 'quantity' => 2]);
        $this->patch(route('cart.update', $blue), ['variant_id' => $black->id, 'quantity' => 2])
            ->assertSessionHas('cart', [$black->id => 2]);
        $other = Product::create(['title' => 'Other', 'slug' => 'other', 'price_paise' => 100, 'is_active' => true]);
        $otherVariant = $other->variants()->create(['size' => '28', 'color' => 'Blue', 'stock' => 5]);
        $this->patch(route('cart.update', $black), ['variant_id' => $otherVariant->id, 'quantity' => 1])
            ->assertNotFound()->assertSessionHas('cart', [$black->id => 2]);
        $this->patch(route('cart.update', $black), ['quantity' => 0])->assertSessionHas('cart', []);
        $this->get(route('cart'))->assertOk()->assertSee('Your bag is waiting');
    }

    public function test_buy_now_rejects_unavailable_stock_and_inactive_products(): void
    {
        [$product, $blue] = $this->catalog();
        $this->post(route('buy-now'), ['variant_id' => $blue->id, 'quantity' => 6])->assertSessionHasErrors('quantity')->assertSessionMissing('buy_now');
        $product->update(['is_active' => false]);
        $this->post(route('buy-now'), ['variant_id' => $blue->id, 'quantity' => 1])->assertNotFound();
    }

    public function test_cart_photo_matches_selected_colour_and_recommendations_are_real(): void
    {
        [$product, $blue, $black] = $this->catalog();
        $product->images()->create(['path' => 'products/blue.jpg', 'color' => 'Blue']);
        $product->images()->create(['path' => 'products/black.jpg', 'color' => 'Black']);
        $demo = Product::create(['title' => 'Demo recommendation', 'slug' => 'demo-recommendation', 'price_paise' => 100, 'is_active' => true, 'is_demo' => true]);
        $demo->variants()->create(['size' => '32', 'color' => 'Blue', 'stock' => 2]);
        $this->post(route('cart.add'), ['variant_id' => $black->id, 'quantity' => 1]);
        $this->get(route('cart'))->assertOk()->assertSee('products/black.jpg')->assertDontSee('products/blue.jpg')
            ->assertDontSee('Demo recommendation');
    }
}
