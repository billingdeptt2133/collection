<?php

namespace Tests\Feature;

use App\Models\{Order, Product, Shipment, StoreSetting, User};
use App\Support\OrderPresentation;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;
use Tests\TestCase;

class OrderPageTest extends TestCase
{
    use RefreshDatabase;

    private function order(array $changes = []): Order
    {
        StoreSetting::firstOrCreate(['id' => 1], ['name' => 'jenson Jeans', 'support_email' => 'help@example.com']);
        $user = User::factory()->create();
        $order = Order::create(array_replace([
            'user_id' => $user->id, 'checkout_token' => (string) Str::uuid(),
            'name' => 'Buyer Name', 'phone' => '9876543210', 'address' => '24 Example Road',
            'city' => 'Jaipur', 'state' => 'Rajasthan', 'pincode' => '302001',
            'subtotal_paise' => 449700, 'discount_paise' => 0, 'shipping_paise' => 0,
            'cod_fee_paise' => 0, 'total_paise' => 449700, 'payment_method' => 'cod',
            'status' => 'processing', 'shipping_provider' => 'manual',
        ], $changes));
        $product = Product::create(['title' => 'Catalog title', 'slug' => Str::random(8), 'price_paise' => 99900, 'image_path' => 'products/black.jpg']);
        $variant = $product->variants()->create(['size' => '28', 'color' => 'Black', 'stock' => 2]);
        $order->items()->create(['variant_id' => $variant->id, 'title' => 'Purchased Jeans', 'size' => '28', 'color' => 'Black', 'price_paise' => 149900, 'quantity' => 3]);
        $this->actingAs($user);
        return $order;
    }

    public function test_manual_order_uses_purchase_prices_and_private_responsive_view_without_api_calls(): void
    {
        Http::preventStrayRequests();
        $order = $this->order();
        $this->get(route('orders.show', $order))->assertOk()
            ->assertSee('Your order is being prepared')->assertSee('Purchased Jeans')
            ->assertSee('1,499.00')->assertSee('4,497.00')->assertDontSee('999.00')
            ->assertSee('Updates provided by our store.')->assertSee('Preparing your shipment')
            ->assertSee('css/order.css')->assertSee('js/order.js')->assertSee('noindex,nofollow', false)
            ->assertHeader('Cache-Control', 'no-store, private');
        Http::assertNothingSent();
    }

    public function test_customers_and_admins_cannot_view_another_customers_order(): void
    {
        $order = $this->order();
        $other = User::factory()->create();
        $this->actingAs($other)->get(route('orders.show', $order))->assertNotFound()->assertDontSee('24 Example Road');
        $other->forceFill(['is_admin' => true])->save();
        $this->actingAs($other)->get(route('orders.show', $order))->assertNotFound();
        $this->post(route('logout'));
        $this->get(route('orders.show', $order))->assertRedirect(route('login'));
    }

    public function test_manual_courier_data_is_escaped_and_unsafe_tracking_urls_are_hidden(): void
    {
        $order = $this->order(['status' => 'shipped', 'courier' => '<script>bad</script>', 'tracking_number' => 'TRACK123', 'tracking_url' => 'javascript:alert(1)', 'shipped_at' => now()]);
        $this->get(route('orders.show', $order))->assertOk()->assertSee('&lt;script&gt;', false)
            ->assertDontSee('<script>bad</script>', false)->assertDontSee('javascript:alert(1)', false)
            ->assertSee('TRACK123')->assertSee('Your order is on its way');
        $order->update(['tracking_url' => 'https://courier.example.com/track/TRACK123']);
        $this->get(route('orders.show', $order))->assertOk()->assertSee('Track with courier')->assertSee('noopener noreferrer', false);
        foreach (['http://courier.example.com/track', 'https://user:pass@courier.example.com/track', 'https://127.0.0.1/track', 'https://localhost/track'] as $url) {
            $this->assertNull(OrderPresentation::trackingUrl($url));
        }
    }

    public function test_correct_colour_photo_is_used_and_deleted_catalog_records_have_a_placeholder(): void
    {
        $order = $this->order();
        $item = $order->items()->first();
        $product = $item->variant->product;
        $product->variants()->create(['size' => '28', 'color' => 'Blue', 'stock' => 2]);
        $product->images()->create(['path' => 'products/blue.jpg', 'color' => 'Blue']);
        $this->get(route('orders.show', $order))->assertOk()->assertDontSee('storage/products/blue.jpg')->assertDontSee('storage/products/black.jpg');
        $product->images()->create(['path' => 'products/purchased-black.webp', 'color' => 'Black']);
        $this->get(route('orders.show', $order))->assertOk()->assertSee('storage/products/purchased-black.webp');
        $item->update(['variant_id' => null]);
        $this->get(route('orders.show', $order))->assertOk()->assertSee('Product image unavailable')->assertSee('Purchased Jeans');
    }

    public function test_unpaid_online_cancelled_and_delivered_cod_states_are_truthful(): void
    {
        $order = $this->order(['status' => 'pending', 'payment_method' => 'razorpay']);
        $this->get(route('orders.show', $order))->assertOk()->assertSee('Complete payment')->assertSee('Awaiting verified payment.');
        $order->update(['status' => 'cancelled']);
        $this->get(route('orders.show', $order))->assertOk()->assertSee('This order was cancelled')->assertDontSee('Complete payment')->assertDontSee('Your parcel has been delivered.');
        $order->update(['status' => 'delivered', 'payment_method' => 'cod']);
        $this->get(route('orders.show', $order))->assertOk()->assertSee('COD collection is awaiting confirmation')->assertDontSee('when your order arrives');
        $order->update(['payment_status' => 'paid']);
        $this->get(route('orders.show', $order))->assertOk()->assertSee('Payment received')->assertSee('Any refund is confirmed separately.');
    }

    public function test_shiprocket_updates_use_stored_tracking_and_never_expose_internal_booking_data(): void
    {
        Http::preventStrayRequests();
        $order = $this->order(['shipping_provider' => 'shiprocket', 'status' => 'shipped']);
        Shipment::create(['order_id' => $order->id, 'reference' => 'PRIVATE_REFERENCE', 'provider_order_id' => 1234567, 'parcel' => [], 'state' => 'in_transit', 'courier' => 'Test Courier', 'awb' => 'AWB123', 'label_url' => 'https://secret.example.com/label.pdf', 'tracking_status' => 'In Transit', 'synced_at' => now(), 'tracking_events' => [['date' => 'Today', 'activity' => '<script>bad</script>', 'location' => 'Jaipur']]]);
        $this->get(route('orders.show', $order))->assertOk()->assertSee('AWB123')->assertSee('Last verified')
            ->assertSee('&lt;script&gt;', false)->assertDontSee('<script>bad</script>', false)
            ->assertDontSee('PRIVATE_REFERENCE')->assertDontSee('1234567')->assertDontSee('secret.example.com');
        Http::assertNothingSent();
        $order->shipment->update(['state' => 'rto', 'tracking_status' => 'RTO Initiated']);
        $this->get(route('orders.show', $order))->assertOk()->assertSee('Your parcel is returning to us')->assertDontSee('when your order arrives');
    }
    public function test_manual_dispatch_without_legacy_tracking_fields_never_says_preparing(): void
    {
        $order = $this->order(['status' => 'shipped']);
        $this->get(route('orders.show', $order))->assertOk()->assertSee('Your parcel has been dispatched')
            ->assertDontSee('Preparing your shipment');
        $order->update(['status' => 'delivered']);
        $this->get(route('orders.show', $order))->assertOk()->assertSee('Your parcel has been delivered')
            ->assertDontSee('Courier and tracking number will be added after dispatch.');
    }
}
