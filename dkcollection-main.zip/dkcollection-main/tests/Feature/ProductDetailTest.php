<?php

namespace Tests\Feature;

use App\Models\Product;
use App\Models\User;
use App\Support\ProductPresentation;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class ProductDetailTest extends TestCase
{
    use RefreshDatabase;

    private function product(): Product
    {
        $product = Product::create(['title' => 'Baggy Jeans', 'slug' => 'baggy-jeans', 'price_paise' => 149900, 'is_active' => true]);
        $product->variants()->create(['size' => '30', 'color' => 'Indigo', 'stock' => 10]);
        $product->variants()->create(['size' => '32', 'color' => 'Black', 'stock' => 0]);
        $product->images()->create(['path' => 'products/indigo.jpg', 'color' => 'Indigo']);
        $product->images()->create(['path' => 'products/black.jpg', 'color' => 'Black']);
        return $product;
    }

    public function test_product_page_renders_gallery_controls_and_exact_variants(): void
    {
        $product = $this->product();
        $this->get(route('products.show', $product->slug))->assertOk()
            ->assertSee('product-detail.css')->assertSee('data-gallery-track', false)
            ->assertSee('data-size="30"', false)->assertSee('data-color="Black"', false)
            ->assertSee('Sold out')->assertSee('Sign in to save this product');
        $data = ProductPresentation::data($product->load('variants', 'images'));
        $this->assertSame('Indigo', $data['photos'][0]['color']);
        $this->assertArrayNotHasKey('barcode', $data['variants'][0]);
    }

    public function test_availability_returns_updated_stock_and_hides_archived_products(): void
    {
        $product = $this->product();
        $product->variants()->where('color', 'Indigo')->update(['stock' => 0]);
        $this->getJson(route('products.availability', $product->slug))->assertOk()
            ->assertJsonPath('variants.0.stock', 0)->assertHeader('Cache-Control', 'no-store, private');
        $product->update(['is_active' => false]);
        $this->getJson(route('products.availability', $product->slug))->assertNotFound();
    }

    public function test_only_admin_can_assign_a_photo_to_a_product_colour(): void
    {
        $product = $this->product();
        $image = $product->images()->first();
        $buyer = User::factory()->create();
        $this->actingAs($buyer)->patch(route('admin.images.color', $image), ['color' => 'Black'])->assertForbidden();
        $admin = User::factory()->create();
        $admin->forceFill(['is_admin' => true])->save();
        $this->actingAs($admin)->patch(route('admin.images.color', $image), ['color' => 'Red'])->assertSessionHasErrors('color');
        $this->assertSame('Indigo', $image->fresh()->color);
        $this->patch(route('admin.images.color', $image), ['color' => 'Black'])->assertRedirect();
        $this->assertSame('Black', $image->fresh()->color);
    }

    public function test_wishlist_heart_reflects_saved_state(): void
    {
        $product = $this->product();
        $user = User::factory()->create();
        $this->actingAs($user)->post(route('wishlist.toggle', $product))->assertRedirect();
        $this->get(route('products.show', $product->slug))->assertOk()->assertSee('Remove from wishlist');
    }
}
