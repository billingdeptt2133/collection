<?php

namespace Tests\Feature;

use App\Models\{Banner, StoreSetting, User};
use App\Support\HomepageBanners;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Tests\TestCase;

class HomepageManagementTest extends TestCase
{
    use RefreshDatabase;

    private function admin(string $role = 'owner'): User
    {
        return User::factory()->create(['is_admin' => true, 'admin_role' => $role]);
    }

    private function payload(string $slot, string $destination = '/products/real-denim?color=Blue'): array
    {
        return [$slot => ['destination_url' => $destination, 'desktop_image' => UploadedFile::fake()->image('desktop.jpg'), 'mobile_image' => UploadedFile::fake()->image('mobile.png')]];
    }

    public function test_admin_page_contains_only_the_two_image_and_url_forms(): void
    {
        $page = $this->actingAs($this->admin())->get(route('admin.homepage'))->assertOk()->assertHeader('Cache-Control', 'no-store, private');
        $page->assertSee('Main Banner')->assertSee('Promotional Banner');
        $this->assertSame(2, substr_count($page->getContent(), 'class="hp-card hp-form"'));
        foreach (['main', 'promotional'] as $slot) {
            foreach (['desktop_image', 'mobile_image', 'destination_url'] as $field) $page->assertSee('name="'.$slot.'['.$field.']"', false);
        }
        foreach (['Homepage UI content', 'Partner logos & footer', 'Category images', 'Showcase & homepage products', 'Hero slides', 'Customer & creator videos', 'name="title"', 'name="subtitle"', 'name="interval"', 'name="category_ids[]"'] as $removed) $page->assertDontSee($removed, false);
    }

    public function test_uploads_store_generated_paths_and_full_store_urls_become_portable_paths(): void
    {
        Storage::fake('public');
        $this->actingAs($this->admin('catalog'));
        foreach (HomepageBanners::SLOTS as $slot) {
            $url = rtrim(config('app.url'), '/').'/products/real-denim?color=Light%20Blue#sizes';
            $this->post(route('admin.homepage.banners.save', $slot), $this->payload($slot, $url))->assertSessionHasNoErrors()->assertRedirect(route('admin.homepage'));
            $saved = StoreSetting::first()->homepage['image_banners'][$slot];
            $this->assertSame('/products/real-denim?color=Light%20Blue#sizes', $saved['destination_url']);
            Storage::disk('public')->assertExists([$saved['desktop_image'], $saved['mobile_image']]);
            $this->assertStringStartsWith('homepage/image-banners/'.$slot.'/', $saved['desktop_image']);
            $this->assertNotSame('desktop.jpg', basename($saved['desktop_image']));
        }
        $this->assertDatabaseCount('banners', 0);
    }

    public function test_url_only_saves_and_single_image_replacement_preserve_every_other_setting(): void
    {
        Storage::fake('public');
        StoreSetting::create(['id' => 1, 'checkout_enabled' => false, 'homepage' => ['featured_ids' => [44], 'video_reviews' => [['name' => 'Saved creator']], 'footer' => ['about' => 'Saved story'], 'design' => ['catalog_heading' => 'Existing heading']]]);
        $this->actingAs($this->admin());
        foreach (HomepageBanners::SLOTS as $slot) $this->post(route('admin.homepage.banners.save', $slot), $this->payload($slot))->assertSessionHasNoErrors();
        $before = StoreSetting::first()->homepage;
        $this->post(route('admin.homepage.banners.save', 'main'), ['main' => ['destination_url' => '/cart']])->assertSessionHasNoErrors();
        $this->post(route('admin.homepage.banners.save', 'main'), ['main' => ['destination_url' => '/cart', 'mobile_image' => UploadedFile::fake()->image('replacement.webp')]])->assertSessionHasNoErrors();
        $store = StoreSetting::first();
        $after = $store->homepage;
        $this->assertSame($before['image_banners']['main']['desktop_image'], $after['image_banners']['main']['desktop_image']);
        $this->assertNotSame($before['image_banners']['main']['mobile_image'], $after['image_banners']['main']['mobile_image']);
        $this->assertSame($before['image_banners']['promotional'], $after['image_banners']['promotional']);
        foreach (['featured_ids', 'video_reviews', 'footer', 'design'] as $key) $this->assertSame($before[$key], $after[$key]);
        $this->assertFalse($store->checkout_enabled);
        Storage::disk('public')->assertExists($before['image_banners']['main']['mobile_image']);
    }

    public function test_first_upload_requires_desktop_and_mobile_can_fall_back_to_it(): void
    {
        Storage::fake('public');
        $this->actingAs($this->admin());
        $url = route('admin.homepage.banners.save', 'main');
        $this->post($url, ['main' => ['destination_url' => '/cart']])->assertSessionHasErrors('main.desktop_image');
        $payload = $this->payload('main');
        unset($payload['main']['mobile_image']);
        $this->post($url, $payload)->assertSessionHasNoErrors();
        $this->assertNull(StoreSetting::first()->homepage['image_banners']['main']['mobile_image']);
        $this->get(route('home'))->assertOk()->assertSee('Main collection banner')->assertDontSee('srcset=', false);
    }

    public function test_invalid_destinations_cannot_create_uploads_or_change_saved_data(): void
    {
        Storage::fake('public');
        $this->actingAs($this->admin());
        foreach (['https://evil.example/x', '//evil.example', '/%2fexample.com', '/\\evil.example', '/%5cevil.example', 'javascript:alert(1)', 'data:text/html,evil', '/products/x%0aLocation:evil', 'https://user:password@'.parse_url(config('app.url'), PHP_URL_HOST).'/x'] as $destination) {
            $this->post(route('admin.homepage.banners.save', 'main'), $this->payload('main', $destination))->assertSessionHasErrors('main.destination_url');
        }
        $this->assertDatabaseCount('store_settings', 0);
        $this->assertSame([], Storage::disk('public')->allFiles());
    }

    public function test_svg_executables_oversized_images_and_hidden_fields_are_rejected(): void
    {
        Storage::fake('public');
        $this->actingAs($this->admin());
        foreach ([UploadedFile::fake()->create('evil.php', 1, 'application/x-httpd-php'), UploadedFile::fake()->createWithContent('evil.svg', '<svg><script>alert(1)</script></svg>'), UploadedFile::fake()->image('wide.jpg', 4097, 1), UploadedFile::fake()->create('large.jpg', 4097, 'image/jpeg')] as $file) {
            $payload = $this->payload('main');
            $payload['main']['desktop_image'] = $file;
            $this->post(route('admin.homepage.banners.save', 'main'), $payload)->assertSessionHasErrors('main.desktop_image');
        }
        $payload = $this->payload('main');
        $payload['main']['title'] = 'Cannot re-enable overlay';
        $this->post(route('admin.homepage.banners.save', 'main'), $payload)->assertSessionHasErrors('main');
        $this->assertDatabaseCount('store_settings', 0);
        $this->assertSame([], Storage::disk('public')->allFiles());
    }

    public function test_guest_customer_and_unrelated_staff_roles_cannot_save_banners(): void
    {
        $url = route('admin.homepage.banners.save', 'main');
        $this->get(route('admin.homepage'))->assertRedirect(route('login'));
        $this->post($url)->assertRedirect(route('login'));
        foreach ([['is_admin' => false], ['is_admin' => true, 'admin_role' => 'orders'], ['is_admin' => true, 'admin_role' => 'support']] as $role) {
            $this->actingAs(User::factory()->create($role))->get(route('admin.homepage'))->assertForbidden();
            $this->post($url)->assertForbidden();
        }
        $this->assertDatabaseCount('store_settings', 0);
    }

    public function test_banner_post_requires_csrf(): void
    {
        $this->actingAs($this->admin());
        $this->app['env'] = 'production';
        try { $this->post(route('admin.homepage.banners.save', 'main'), $this->payload('main'))->assertStatus(419); }
        finally { $this->app['env'] = 'testing'; }
        $this->assertDatabaseCount('store_settings', 0);
    }

    public function test_removed_homepage_operations_and_unknown_slots_are_not_routable(): void
    {
        $this->actingAs($this->admin());
        foreach (['/admin/homepage', '/admin/homepage/design', '/admin/homepage/partners', '/admin/homepage/banners', '/admin/homepage/banners/123', '/admin/homepage/banners/third', '/admin/homepage/categories/1'] as $url) $this->post($url)->assertStatus($url === '/admin/homepage' ? 405 : 404);
        $this->post('/admin/banners', ['title' => 'Legacy'])->assertNotFound();
        $this->patch('/admin/banners/1', ['title' => 'Legacy'])->assertNotFound();
        $this->get(route('admin.categories'))->assertOk()->assertDontSee('Manage category photos');
        $this->assertDatabaseCount('store_settings', 0);
    }

    public function test_legacy_images_are_kept_but_only_first_main_image_renders_without_any_overlay(): void
    {
        Banner::create(['title' => 'OLD MAIN TITLE', 'subtitle' => 'OLD MAIN SUBTITLE', 'image_path' => 'banners/legacy-main.jpg', 'mobile_image_path' => 'banners/legacy-mobile.jpg', 'link_url' => '/products/old', 'is_active' => true, 'sort_order' => 1]);
        Banner::create(['title' => 'SECOND LEGACY TITLE', 'image_path' => 'banners/second.jpg', 'is_active' => true, 'sort_order' => 2]);
        StoreSetting::create(['id' => 1, 'homepage' => ['hero_title' => 'OLD EYEBROW', 'design' => ['promo_image' => 'homepage/editorial/promo.jpg', 'promo_heading' => 'OLD PROMO TITLE', 'hero_button' => 'OLD BUTTON']]]);
        $page = $this->get(route('home'))->assertOk();
        foreach (['banners/legacy-main.jpg', 'banners/legacy-mobile.jpg', 'homepage/editorial/promo.jpg', 'href="/products/old"'] as $present) $page->assertSee($present, false);
        foreach (['OLD MAIN TITLE', 'OLD MAIN SUBTITLE', 'SECOND LEGACY TITLE', 'OLD EYEBROW', 'OLD PROMO TITLE', 'OLD BUTTON', 'second.jpg', 'hero-overlay', 'editorial-hero-copy', 'collection-copy', 'data-hero-next', 'data-home-slider'] as $removed) $page->assertDontSee($removed, false);
        $this->assertSame(2, substr_count($page->getContent(), 'image-only-banner'));
        $this->assertDatabaseCount('banners', 2);
    }

    public function test_failed_database_save_cleans_new_uploads_and_retains_previous_settings(): void
    {
        Storage::fake('public');
        StoreSetting::create(['id' => 1, 'homepage' => ['footer' => ['about' => 'Keep this']]]);
        StoreSetting::saving(fn () => throw new \RuntimeException('Simulated database failure'));
        $this->actingAs($this->admin())->withoutExceptionHandling();
        try {
            $this->post(route('admin.homepage.banners.save', 'main'), $this->payload('main'));
            $this->fail('Expected the simulated failure.');
        } catch (\RuntimeException $error) {
            $this->assertSame('Simulated database failure', $error->getMessage());
        }
        $this->assertSame([], Storage::disk('public')->allFiles());
        $this->assertSame(['footer' => ['about' => 'Keep this']], StoreSetting::first()->homepage);
    }

    public function test_unconfigured_banners_do_not_show_demo_fallback_images_or_text(): void
    {
        $this->get(route('home'))->assertOk()->assertDontSee('image-only-banner', false)->assertDontSee('images/home-reference', false)->assertDontSee('Made for your everyday.')->assertDontSee('THE EVERYDAY DENIM EDIT');
    }
}
