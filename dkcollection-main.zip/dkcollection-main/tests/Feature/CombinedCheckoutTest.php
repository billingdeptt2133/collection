<?php

namespace Tests\Feature;

use App\Models\Coupon;
use App\Models\Order;
use App\Models\Product;
use App\Models\StoreSetting;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Http;
use Tests\TestCase;

class CombinedCheckoutTest extends TestCase
{
    use RefreshDatabase;

    private function catalog(): array
    {
        StoreSetting::create(['id' => 1, 'checkout_enabled' => true, 'delivery_mode' => 'all', 'cod_enabled' => true,
            'online_enabled' => false, 'flat_shipping_paise' => 5000, 'cod_fee_paise' => 2500]);
        $product = Product::create(['title' => 'Ankle Jeans', 'slug' => 'ankle-jeans', 'price_paise' => 149900, 'is_active' => true]);
        $variant = $product->variants()->create(['size' => '28', 'color' => 'Blue', 'stock' => 5]);
        $this->post(route('cart.add'), ['variant_id' => $variant->id, 'quantity' => 1]);
        $this->get(route('checkout'))->assertOk();
        return [$product, $variant];
    }

    private function details(): array
    {
        return ['checkout_token' => session('checkout_token'), 'name' => 'Buyer', 'email' => 'buyer@example.test',
            'password' => 'StrongPassword123!', 'phone' => '9876543210', 'address' => '123 Main Road',
            'address2' => 'Near the park', 'city' => 'Jaipur', 'state' => 'Rajasthan', 'pincode' => '302001'];
    }

    private function orderData(int $total = 157400): array
    {
        return array_diff_key($this->details(), array_flip(['email', 'password', 'address2']))
            + ['payment_method' => 'cod', 'expected_total_paise' => $total];
    }

    public function test_guest_creates_account_and_saves_shipping_without_creating_order_or_reserving_stock(): void
    {
        [, $variant] = $this->catalog();
        $this->get(route('checkout'))->assertOk()->assertSee('Contact &amp; account', false)->assertSee('name="password"', false);
        $this->post(route('checkout.details'), $this->details() + ['is_admin' => 1])->assertRedirect(route('checkout.payment'));
        $this->assertAuthenticated();
        $user = User::firstOrFail();
        $this->assertTrue(Hash::check('StrongPassword123!', $user->password));
        $this->assertFalse($user->is_admin);
        $draft = session('checkout_details');
        $this->assertSame('Near the park', $draft['address2']);
        $this->assertArrayNotHasKey('password', $draft);
        $this->assertArrayNotHasKey('email', $draft);
        $this->assertDatabaseCount('orders', 0);
        $this->assertSame(5, $variant->fresh()->stock);
        $this->get(route('checkout.payment'))->assertOk()->assertSee('₹1,574.00')->assertSee('Near the park');
    }

    public function test_logged_in_checkout_has_no_password_or_registration_fields(): void
    {
        $this->catalog();
        $user = User::factory()->create(['name' => 'Existing Buyer']);
        $this->actingAs($user)->get(route('checkout'))->assertOk()->assertSee('Signed in as Existing Buyer')
            ->assertDontSee('name="password"', false)->assertDontSee('name="email"', false);
        $data = array_diff_key($this->details(), array_flip(['email', 'password']));
        $this->post(route('checkout.details'), $data)->assertRedirect(route('checkout.payment'));
        $this->assertDatabaseCount('users', 1);
        $this->get(route('checkout.payment'))->assertOk()->assertSee('₹1,574.00');
    }

    public function test_invalid_registration_never_flashes_password_or_creates_an_account(): void
    {
        $this->catalog();
        $data = $this->details(); $data['city'] = '';
        $this->post(route('checkout.details'), $data)->assertSessionHasErrors('city')->assertSessionMissing('checkout_details');
        $this->assertArrayNotHasKey('password', session('_old_input', []));
        $this->assertDatabaseCount('users', 0);
        $this->assertDatabaseCount('orders', 0);
    }

    public function test_existing_email_requires_login_and_keeps_shipping_draft_without_password(): void
    {
        $this->catalog();
        $user = User::factory()->create(['email' => 'buyer@example.test', 'password' => 'StrongPassword123!']);
        $this->post(route('checkout.details'), $this->details())->assertSessionHasErrors('email');
        $this->assertGuest();
        $this->post(route('checkout.login'), $this->details())->assertRedirect(route('login'));
        $this->assertArrayNotHasKey('password', session('checkout_login_draft'));
        $this->post(route('login.submit'), ['email' => $user->email, 'password' => 'StrongPassword123!'])->assertRedirect(route('checkout'));
        $this->get(route('checkout'))->assertOk()->assertSee('Near the park')->assertSee('9876543210');
    }

    public function test_delivery_and_stock_failures_do_not_create_accounts(): void
    {
        [, $variant] = $this->catalog();
        StoreSetting::firstOrFail()->update(['checkout_enabled' => false]);
        $this->post(route('checkout.details'), $this->details())->assertSessionHasErrors('pincode');
        $this->assertDatabaseCount('users', 0);
        StoreSetting::firstOrFail()->update(['checkout_enabled' => true]);
        $variant->update(['stock' => 0]);
        $this->post(route('checkout.details'), $this->details())->assertSessionHasErrors('cart');
        $this->assertDatabaseCount('users', 0);
    }

    public function test_quote_uses_real_coupon_and_payment_fees_without_changing_stock(): void
    {
        [, $variant] = $this->catalog();
        Coupon::create(['code' => 'SAVE100', 'discount_paise' => 10000, 'minimum_paise' => 100000, 'is_active' => true]);
        $this->getJson(route('checkout.quote', ['checkout_token' => session('checkout_token'), 'pincode' => '302001',
            'coupon' => 'SAVE100', 'payment_method' => 'cod', 'total_paise' => 1]))->assertOk()
            ->assertJsonPath('subtotal_paise', 149900)->assertJsonPath('discount_paise', 10000)
            ->assertJsonPath('shipping_paise', 5000)->assertJsonPath('cod_fee_paise', 2500)->assertJsonPath('total_paise', 147400);
        $this->assertSame(5, $variant->fresh()->stock);
        $this->assertSame(0, Coupon::firstOrFail()->used_count);
        $this->getJson(route('checkout.quote', ['checkout_token' => session('checkout_token'), 'pincode' => '302001',
            'coupon' => 'BAD']))->assertUnprocessable()->assertJsonValidationErrors('coupon');
    }

    public function test_review_precedes_cod_order_and_price_changes_require_review(): void
    {
        [$product, $variant] = $this->catalog();
        $this->post(route('checkout.details'), $this->details())->assertRedirect(route('checkout.payment'));
        $this->get(route('checkout.payment'))->assertOk()->assertSee('Place COD Order');
        $product->update(['price_paise' => 159900]);
        $this->post(route('checkout.place'), $this->orderData())->assertSessionHasErrors('cart');
        $this->assertDatabaseCount('orders', 0);
        $this->assertSame(5, $variant->fresh()->stock);
        $this->get(route('checkout.payment'))->assertOk()->assertSee('₹1,674.00');
        $data = $this->orderData(167400); $data['address'] .= "\nNear the park";
        $this->post(route('checkout.place'), $data)->assertSessionHasNoErrors()->assertSessionMissing('checkout_details');
        $order = Order::firstOrFail();
        $this->assertSame(167400, $order->total_paise);
        $this->assertSame("123 Main Road\nNear the park", $order->address);
        $this->assertSame(4, $variant->fresh()->stock);
    }

    public function test_online_order_opens_gateway_page_and_never_sends_password_to_gateway(): void
    {
        $this->catalog();
        StoreSetting::firstOrFail()->update(['online_enabled' => true]);
        config(['services.razorpay.key' => 'test_key', 'services.razorpay.secret' => 'test_secret']);
        Http::fake(['api.razorpay.com/v1/orders' => Http::response(['id' => 'order_ABC123'], 200)]);
        $this->post(route('checkout.details'), $this->details())->assertRedirect(route('checkout.payment'));
        $this->get(route('checkout.payment'))->assertOk()->assertSee('Pay online');
        $data = $this->orderData(154900); $data['payment_method'] = 'razorpay';
        $this->post(route('checkout.place'), $data)->assertRedirect(route('payments.show', Order::firstOrFail()));
        Http::assertSent(fn ($request) => $request->data() === ['amount' => 154900, 'currency' => 'INR', 'receipt' => 'dk-1']);
        $this->assertSame('pending', Order::firstOrFail()->payment_status);
    }

    public function test_expired_draft_and_changed_bag_cannot_skip_details(): void
    {
        [, $variant] = $this->catalog();
        $this->post(route('checkout.details'), $this->details());
        $draft = session('checkout_details'); $draft['prepared_at'] = time() - 1801;
        $this->withSession(['checkout_details' => $draft])->get(route('checkout.payment'))->assertRedirect(route('checkout'));
        $this->post(route('checkout.place'), $this->orderData())->assertSessionHasErrors('cart');
        $this->get(route('checkout'));
        $this->post(route('checkout.details'), $this->details());
        $this->patch(route('cart.update', $variant), ['quantity' => 2])->assertSessionMissing('checkout_details');
        $this->get(route('checkout.payment'))->assertRedirect(route('checkout'));
        $this->assertDatabaseCount('orders', 0);
    }
    public function test_inline_registration_returns_identity_and_rotates_tokens_without_saving_password_or_order(): void
    {
        [, $variant] = $this->catalog();
        $token = session('checkout_token');
        $cart = session('cart');
        $this->postJson(route('checkout.account'), $this->details() + ['mode' => 'register', 'is_admin' => true])
            ->assertOk()->assertJsonPath('user.email', 'buyer@example.test')->assertJsonStructure(['csrf_token', 'checkout_token'])
            ->assertHeader('Cache-Control', 'no-store, private');
        $this->assertAuthenticated();
        $this->assertFalse(User::firstOrFail()->is_admin);
        $this->assertTrue(Hash::check('StrongPassword123!', User::firstOrFail()->password));
        $this->assertNotSame($token, session('checkout_token'));
        $this->assertSame($cart, session('cart'));
        $this->assertArrayNotHasKey('password', session()->all());
        $this->assertDatabaseCount('orders', 0);
        $this->assertSame(5, $variant->fresh()->stock);
        $this->postJson(route('checkout.details'), $this->details())->assertOk()->assertJsonPath('redirect_url', route('checkout.payment'));
        $this->get(route('checkout.payment'))->assertOk();
    }

    public function test_inline_login_rejects_wrong_password_then_preserves_buy_now_and_cart(): void
    {
        [, $variant] = $this->catalog();
        $user = User::factory()->create(['email' => 'buyer@example.test', 'password' => 'StrongPassword123!']);
        $cart = session('cart');
        $this->withSession(['checkout_context' => 'buy_now', 'buy_now' => [$variant->id => 1]]);
        $data = ['checkout_token' => session('checkout_token'), 'mode' => 'login', 'email' => $user->email, 'password' => 'wrong'];
        $this->postJson(route('checkout.account'), $data)->assertUnprocessable()->assertJsonValidationErrors('email');
        $this->assertGuest();
        $data['password'] = 'StrongPassword123!';
        $this->postJson(route('checkout.account'), $data)->assertOk()->assertJsonPath('user.name', $user->name)->assertJsonMissingPath('user.password');
        $this->assertAuthenticatedAs($user);
        $this->assertSame($cart, session('cart'));
        $this->assertSame([$variant->id => 1], session('buy_now'));
        $this->assertSame('buy_now', session('checkout_context'));
        $this->assertDatabaseCount('users', 1);
        $this->assertDatabaseCount('orders', 0);
    }

    public function test_inline_account_validation_does_not_create_users_and_requires_checkout_token(): void
    {
        $this->catalog();
        $data = $this->details() + ['mode' => 'register'];
        $data['password'] = 'short';
        $this->postJson(route('checkout.account'), $data)->assertUnprocessable()->assertJsonValidationErrors('password');
        $data['password'] = 'StrongPassword123!';
        $data['checkout_token'] = (string) \Illuminate\Support\Str::uuid();
        $this->postJson(route('checkout.account'), $data)->assertUnprocessable()->assertJsonValidationErrors('cart');
        $this->assertDatabaseCount('users', 0);
        $data['checkout_token'] = session('checkout_token');
        StoreSetting::firstOrFail()->update(['checkout_enabled' => false]);
        $this->postJson(route('checkout.account'), $data)->assertUnprocessable()->assertJsonValidationErrors('cart');
        $this->assertDatabaseCount('users', 0);
    }

    public function test_guest_json_continue_validates_shipping_before_registration(): void
    {
        $this->catalog();
        $data = $this->details(); $data['city'] = '';
        $this->postJson(route('checkout.details'), $data)->assertUnprocessable()->assertJsonValidationErrors('city');
        $this->assertGuest();
        $this->assertDatabaseCount('users', 0);
        $data['city'] = 'Jaipur';
        $this->postJson(route('checkout.details'), $data)->assertOk()->assertJsonPath('redirect_url', route('checkout.payment'));
        $this->assertAuthenticated();
        $this->assertDatabaseCount('orders', 0);
    }

}
