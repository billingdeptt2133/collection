<?php
namespace Tests\Feature;

use App\Models\{Product,Category,StoreSetting};
use App\Support\ProductPresentation;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class ColourCatalogTest extends TestCase
{
    use RefreshDatabase;
    private function product(array $changes=[]): Product {
        StoreSetting::firstOrCreate(['id'=>1],['name'=>'DK Fashion Hub']);
        $product=Product::create(array_replace(['title'=>'Baloon Baggy Fit','slug'=>'baloon-baggy','article_code'=>'1336','price_paise'=>149900,'is_active'=>true,'image_path'=>'products/generic.jpg'],$changes));
        foreach(['Black'=>4,'Blue'=>6,'Grey'=>0] as $color=>$stock){
            $product->variants()->create(['size'=>'30','color'=>$color,'stock'=>$stock]);
            $product->images()->create(['color'=>$color,'path'=>'products/'.strtolower($color).'.jpg']);
        }
        return $product;
    }
    public function test_one_parent_product_renders_three_colour_cards_with_shared_article_and_price(): void {
        $p=$this->product();
        $response=$this->get(route('home'))->assertOk();
        foreach(['Black','Blue','Grey'] as $color){
            $response->assertSee($color.' Baloon Baggy Fit')->assertSee(route('products.show',['slug'=>$p->slug,'color'=>$color]));
        }
        $response->assertSee('Article 1336')->assertSee('1,499.00')->assertSee('Sold out');
        $this->assertDatabaseCount('products',1);
        $cards=ProductPresentation::cards($p->load('variants','images'));
        $this->assertCount(3,$cards);$this->assertFalse($cards[0]['soldOut']);$this->assertTrue($cards[2]['soldOut']);
        $this->assertStringEndsWith('/storage/products/blue.jpg',$cards[1]['image']);
    }
    public function test_card_colour_is_selected_on_detail_with_matching_initial_gallery_even_when_sold_out(): void {
        $p=$this->product();
        foreach(['Blue','Grey'] as $color){
            $response=$this->get(route('products.show',['slug'=>$p->slug,'color'=>$color]))->assertOk()->assertViewHas('initialColor',$color)->assertSee($color.' Baloon Baggy Fit');
            $gallery=$response->viewData('presentation');$this->assertSame($color,$gallery['initialColor']);
        }
        $this->get(route('products.show',['slug'=>$p->slug,'color'=>'Unknown']))->assertOk()->assertViewHas('initialColor','Black')->assertDontSee('Unknown Baloon Baggy Fit');
        $this->get(route('products.show',['slug'=>$p->slug,'color'=>['Blue']]))->assertRedirect()->assertSessionHasErrors('color');
    }
    public function test_unmapped_multi_colour_cards_never_show_another_colours_photo(): void {
        $p=$this->product();$p->images()->where('color','Blue')->delete();
        $cards=ProductPresentation::cards($p->load('variants','images'));$this->assertNull($cards[1]['image']);
        $response=$this->get(route('products.show',['slug'=>$p->slug,'color'=>'Blue']))->assertOk();
        $this->assertSame('Blue',$response->viewData('initialColor'));
    }
    public function test_archived_products_are_hidden_but_fully_sold_out_published_products_remain_visible(): void {
        $p=$this->product();$p->variants()->update(['stock'=>0]);
        $this->get(route('home'))->assertOk()->assertSee('Grey Baloon Baggy Fit')->assertSee('Sold out');
        $p->update(['is_active'=>false]);$this->get(route('home'))->assertDontSee('Black Baloon Baggy Fit');
        $this->get(route('products.show',['slug'=>$p->slug,'color'=>'Black']))->assertNotFound();
    }
    public function test_category_featured_and_show_more_keep_colour_cards(): void {
        $p=$this->product();$category=Category::create(['name'=>'Baggy','slug'=>'baggy','is_active'=>true]);$p->update(['category_id'=>$category->id]);
        StoreSetting::first()->update(['homepage'=>['featured_ids'=>[$p->id]]]);
        $this->get(route('home'))->assertOk()->assertSee('Blue Baloon Baggy Fit');
        $this->get(route('home',['category'=>'baggy']))->assertOk()->assertSee('Grey Baloon Baggy Fit');
        $this->get(route('home',['category'=>'other']))->assertOk()->assertDontSee('Grey Baloon Baggy Fit');
        foreach(range(1,20) as $index){$other=Product::create(['title'=>'More jeans '.$index,'slug'=>'more-'.$index,'price_paise'=>100,'is_active'=>true]);$other->variants()->create(['size'=>'28','color'=>'Indigo','stock'=>1]);}
        $response=$this->get(route('home',['page'=>2]))->assertOk();$this->assertSame(2,$response->viewData('products')->currentPage());$response->assertSee('Indigo More jeans');
    }

    public function test_card_uses_admin_fit_and_mrp_without_changing_colour_links_or_stock(): void {
        $p=$this->product(['pattern'=>'Loose fit', 'mrp_paise'=>199900]);
        $response=$this->get(route('home'))->assertOk();
        $response->assertSee('Loose fit')->assertSee('1,999.00')->assertSee('25% OFF');
        foreach(['Black','Blue','Grey'] as $color){
            $response->assertSee(route('products.show',['slug'=>$p->slug,'color'=>$color]));
        }
        $response->assertSee('Sold out')->assertSee('Article 1336');
        $this->assertSame([4,6,0], $p->variants()->orderBy('id')->pluck('stock')->all());
        $p->update(['pattern'=>'<script>bad()</script>']);
        $this->get(route('home'))->assertOk()->assertSee('&lt;script&gt;bad()&lt;/script&gt;',false)
            ->assertDontSee('<script>bad()</script>',false);
    }

    public function test_card_only_advertises_a_discount_when_mrp_exceeds_the_selling_price(): void {
        $p=$this->product();
        foreach([null,0,99900,149900] as $mrp){
            $p->update(['mrp_paise'=>$mrp]);
            $this->get(route('home'))->assertOk()->assertSee('1,499.00')
                ->assertDontSee('class="product-card-mrp"',false)->assertDontSee('% OFF');
        }
        $p->update(['mrp_paise'=>150000]);
        $this->get(route('home'))->assertOk()->assertSee('1,500.00')->assertDontSee('0% OFF');
    }
}
