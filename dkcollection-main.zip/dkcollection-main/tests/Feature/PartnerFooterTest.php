<?php

namespace Tests\Feature;

use App\Models\StoreSetting;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class PartnerFooterTest extends TestCase
{
    use RefreshDatabase;

    public function test_footer_destinations_render_escaped_content_and_keep_order_authentication(): void
    {
        StoreSetting::create(['id' => 1, 'name' => 'Jansen Jeans', 'shipping_policy' => 'Shipping details', 'return_policy' => 'Return details', 'privacy_policy' => 'Privacy details', 'terms_policy' => 'Terms details', 'support_email' => 'help@example.test', 'whatsapp' => '919999999999', 'homepage' => ['footer' => ['about' => '<script>alert(1)</script>', 'faqs' => 'Your order answers']]]);
        $this->get(route('home'))->assertOk()->assertSee('Track Your Order')->assertSee('Returns &amp; Exchanges', false)->assertSee('About Us')->assertSee('FAQs')->assertSee('Shipping &amp; Delivery Policy', false)->assertSee('class="editorial-footer"', false);
        $this->get(route('store.page', 'about'))->assertOk()->assertSee('&lt;script&gt;alert(1)&lt;/script&gt;', false)->assertDontSee('<script>alert(1)</script>', false);
        $this->get(route('store.page', 'faqs'))->assertOk()->assertSee('Your order answers');
        $this->get(route('store.page', 'contact'))->assertOk()->assertSee('help@example.test');
        foreach (['shipping', 'returns', 'privacy', 'terms'] as $policy) $this->get(route('policy', $policy))->assertOk();
        $this->get(route('orders'))->assertRedirect(route('login'));
        $this->get('/pages/unknown')->assertNotFound();
    }

    public function test_unconfigured_content_does_not_create_fake_partnerships_or_broken_links(): void
    {
        $this->get(route('home'))->assertOk()->assertDontSee('id="partners-title"', false)->assertDontSee('>About Us</a>', false)->assertDontSee('>FAQs</a>', false)->assertDontSee('>Privacy Policy</a>', false);
        $this->get(route('store.page', 'about'))->assertNotFound();
        $this->get(route('store.page', 'faqs'))->assertNotFound();
        $this->get(route('store.page', 'contact'))->assertOk();
    }
}
