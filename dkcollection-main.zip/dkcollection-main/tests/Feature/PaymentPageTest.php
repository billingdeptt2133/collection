<?php

namespace Tests\Feature;

use App\Models\{Order, Product, StoreSetting, User};
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;
use Tests\TestCase;

class PaymentPageTest extends TestCase
{
    use RefreshDatabase;

    private function pendingOrder(): Order
    {
        StoreSetting::firstOrCreate(['id' => 1], ['name' => 'Jansen Jeans', 'support_email' => 'help@example.com']);
        $user = User::factory()->create();
        $order = Order::create([
            'user_id' => $user->id, 'checkout_token' => (string) Str::uuid(),
            'name' => 'Buyer', 'phone' => '9876543210', 'address' => 'Example Road',
            'city' => 'Jaipur', 'state' => 'Rajasthan', 'pincode' => '302001',
            'subtotal_paise' => 299800, 'discount_paise' => 10000, 'shipping_paise' => 5000,
            'cod_fee_paise' => 0, 'total_paise' => 294800, 'payment_method' => 'razorpay',
            'status' => 'pending', 'payment_status' => 'pending', 'gateway_order_id' => 'order_page123',
        ]);
        $product = Product::create(['title' => 'New catalog name', 'slug' => 'payment-page-jeans', 'price_paise' => 99900]);
        $variant = $product->variants()->create(['size' => '32', 'color' => 'Indigo', 'stock' => 2]);
        $product->images()->create(['path' => 'products/indigo.webp', 'color' => 'Indigo']);
        $order->items()->create(['variant_id' => $variant->id, 'title' => 'Purchased Jeans', 'size' => '32', 'color' => 'Indigo', 'price_paise' => 149900, 'quantity' => 2]);
        $this->actingAs($user);
        return $order;
    }

    public function test_payment_summary_uses_order_snapshots_and_preserves_gateway_handoff(): void
    {
        Http::preventStrayRequests();
        config(['services.razorpay.key' => 'rzp_test_public', 'services.razorpay.secret' => 'private-key-never-render', 'services.razorpay.webhook_secret' => 'private-webhook-never-render']);
        $order = $this->pendingOrder();
        $this->get(route('payments.show', $order))->assertOk()
            ->assertSee('Complete your payment')->assertSee('Payment pending')
            ->assertSee('Purchased Jeans')->assertSee('Qty 2')->assertSee('1,499.00')->assertSee('2,998.00')
            ->assertSee('100.00')->assertSee('50.00')->assertSee('Pay ₹2,948.00 securely')
            ->assertDontSee('New catalog name')->assertDontSee('999.00')
            ->assertSee('storage/products/indigo.webp')->assertSee('css/payment.css')
            ->assertSee('noindex,nofollow', false)->assertSee('id="pay-button"', false)
            ->assertSee('name="_token"', false)->assertSee('name="razorpay_signature"', false)
            ->assertSee('action="'.route('payments.verify', $order).'"', false)
            ->assertSee('rzp_test_public')->assertSee('order_page123')->assertSee('294800')
            ->assertDontSee('private-key-never-render')->assertDontSee('private-webhook-never-render');
        Http::assertNothingSent();
        $this->assertSame('pending', $order->fresh()->payment_status);
    }

    public function test_missing_catalog_and_unsafe_text_render_safely_without_losing_purchase_details(): void
    {
        $order = $this->pendingOrder();
        $order->items()->first()->update(['variant_id' => null, 'title' => '<script>bad()</script>']);
        StoreSetting::first()->update(['support_email' => 'javascript:alert(1)', 'whatsapp' => 'invalid']);
        $order->update(['shipping_paise' => 0, 'discount_paise' => 0, 'total_paise' => 299800]);
        $this->get(route('payments.show', $order))->assertOk()
            ->assertSee('Product image unavailable')->assertSee('&lt;script&gt;bad()&lt;/script&gt;', false)
            ->assertDontSee('<script>bad()</script>', false)->assertDontSee('javascript:alert(1)', false)
            ->assertSee('Free')->assertDontSee('<dt>Discount</dt>', false)->assertSee('Pay ₹2,998.00 securely');
    }

    public function test_payment_page_remains_owner_only_and_rejects_non_payable_orders(): void
    {
        $order = $this->pendingOrder();
        $owner = User::findOrFail($order->user_id);
        $this->actingAs(User::factory()->create())->get(route('payments.show', $order))->assertNotFound();
        $this->actingAs($owner);
        foreach ([['status' => 'cancelled'], ['payment_status' => 'paid'], ['payment_method' => 'cod'], ['gateway_order_id' => null]] as $change) {
            $order->update(array_merge(['status' => 'pending', 'payment_status' => 'pending', 'payment_method' => 'razorpay', 'gateway_order_id' => 'order_page123'], $change));
            $this->get(route('payments.show', $order))->assertNotFound();
        }
        $this->post(route('logout'));
        $this->get(route('payments.show', $order))->assertRedirect(route('login'));
    }
}
