const test = require('node:test');
const assert = require('node:assert/strict');
const api = require('../../public/js/product-variants.js');
const variants = [
 { id: 1, size: '30', color: 'Indigo', stock: 10 },
 { id: 2, size: '32', color: 'Indigo', stock: 0 },
 { id: 3, size: '32', color: 'Black', stock: 4 },
];
test('exact size and colour choose the correct variant', () => {
 assert.equal(api.variant(variants, '32', 'Black').id, 3);
 assert.equal(api.variant(variants, '32', 'Indigo'), null);
});
test('selling the final item disables its size only for that colour', () => {
 const sold = variants.map(v => v.id === 1 ? {...v, stock: 0} : v);
 assert.equal(api.sizeAvailable(sold, '30', 'Indigo'), false);
 assert.equal(api.sizeAvailable(sold, '32', 'Black'), true);
});
test('quantity is limited to variant stock and a maximum of ten', () => {
 assert.equal(api.limit(variants[2]), 4);
 assert.equal(api.limit({...variants[0], stock: 50}), 10);
 assert.equal(api.limit(null), 0);
});
test('mapped colour gallery never includes another colour or generic main photo', () => {
 const data = {variants, defaultImage: '/generic.jpg', photos: [{src:'/indigo.jpg',color:'Indigo'},{src:'/black.jpg',color:'Black'}]};
 assert.deepEqual(api.gallery(data, 'Black'), ['/black.jpg']);
 assert.deepEqual(api.gallery(data, 'Red'), []);
});
test('unmapped multi-colour products do not pretend generic photos match', () => {
 assert.deepEqual(api.gallery({variants, defaultImage:'/generic.jpg',photos:[]}, 'Black'), []);
});
test('single-colour legacy products retain their default gallery without duplicates', () => {
 assert.deepEqual(api.gallery({variants:[variants[0]],defaultImage:'/a.jpg',photos:[{src:'/a.jpg',color:null},{src:'/b.jpg',color:null}]}, 'Indigo'), ['/a.jpg','/b.jpg']);
});
