const {chromium} = require('playwright');
const assert = require('node:assert/strict');
const fs = require('node:fs');

let browser, page;
(async () => {
    browser = await chromium.launch({headless: true});
    page = await browser.newPage({viewport: {width: 395, height: 850}, reducedMotion: 'reduce'});
    page.setDefaultTimeout(15000);
    const errors = [];
    page.on('pageerror', error => errors.push(error.message));
    fs.mkdirSync('homepage-ui-artifacts', {recursive: true});
    const loadImages = () => page.evaluate(async () => {
        const images = [...document.images];
        images.forEach(image => { image.loading = 'eager'; });
        await Promise.all(images.map(image => image.decode().catch(() => {})));
    });
    for (const width of [360, 395, 768, 1440]) {
        await page.setViewportSize({width, height: 950});
        await page.goto('http://127.0.0.1:8000/', {waitUntil: 'networkidle'});
        await loadImages();
        const layout = await page.evaluate(() => ({
            overflow: document.documentElement.scrollWidth > innerWidth,
            columns: getComputedStyle(document.querySelector('.product-grid')).gridTemplateColumns.split(' ').length,
            imageFit: getComputedStyle(document.querySelector('.product-image img')).objectFit,
            heroRatio: getComputedStyle(document.querySelector('.editorial-slide')).aspectRatio,
            promoRatio: getComputedStyle(document.querySelector('.collection-banner')).aspectRatio,
            brokenImages: [...document.images].filter(image => !image.complete || !image.naturalWidth).length,
        }));
        assert.equal(layout.overflow, false, `Horizontal overflow at ${width}`);
        assert.equal(layout.columns, width > 800 ? 4 : 2, `Product columns at ${width}`);
        assert.equal(layout.imageFit, 'contain');
        assert.equal(layout.brokenImages, 0);
        if (width <= 800) { assert.equal(layout.heroRatio, '9 / 11'); assert.equal(layout.promoRatio, '9 / 10'); }
        const visual = await page.evaluate(() => ({
            buttonColor: getComputedStyle(document.querySelector('.product-add')).color,
            buttonSurface: getComputedStyle(document.querySelector('.product-add')).backgroundImage,
            footerSurface: getComputedStyle(document.querySelector('.editorial-footer')).backgroundImage,
            motion: getComputedStyle(document.querySelector('.catalog')).animationName,
        }));
        assert.equal(visual.buttonColor, 'rgb(255, 255, 255)');
        assert.match(visual.buttonSurface, /linear-gradient/);
        assert.match(visual.footerSurface, /radial-gradient/);
        assert.equal(visual.motion, 'none', 'Reduced motion is respected');
        if (width > 800) {
            // Exercise short rows and wrapping without changing saved category data.
            for (const count of [1, 3, 6, 12]) {
                const centered = await page.evaluate(count => {
                    const grid = document.querySelector('.fit-grid');
                    const original = grid.innerHTML;
                    const template = grid.firstElementChild;
                    grid.replaceChildren(...Array.from({length: count}, () => template.cloneNode(true)));
                    const box = grid.getBoundingClientRect();
                    const rows = new Map();
                    for (const link of grid.children) {
                        const r = link.getBoundingClientRect(), key = Math.round(r.top);
                        if (!rows.has(key)) rows.set(key, []);
                        rows.get(key).push(r);
                    }
                    const result = [...rows.values()].every(row => {
                        const left = Math.min(...row.map(r => r.left));
                        const right = Math.max(...row.map(r => r.right));
                        return Math.abs((left + right) / 2 - (box.left + box.right) / 2) < 2;
                    });
                    grid.innerHTML = original;
                    return result;
                }, count);
                assert.equal(centered, true, `Centered category rows for ${count} categories at ${width}`);
            }
        }
        assert.equal(await page.locator('.product-card').count(), 20);
        await page.locator('.show-more').click();
        await page.waitForFunction(() => document.querySelectorAll('.product-card').length === 21);
        assert.equal(await page.locator('.show-more').isVisible(), false);
        assert.equal(await page.locator('.image-only-banner').count(), 2);
        assert.equal(await page.locator('.image-only-banner button,.editorial-hero-copy,.collection-copy,[data-hero-next]').count(), 0);
        await page.locator('.editorial-hero .image-only-banner').click();
        await page.waitForURL('**/products/fixture-denim-1?color=Blue');
        await page.goto('http://127.0.0.1:8000/');
        await page.locator('.collection-banner.image-only-banner').click();
        await page.waitForURL('**/?category=slim-fit#new-arrivals');
        assert.equal(await page.locator('.product-card').count(), 4);
        await page.goto('http://127.0.0.1:8000/');
        if (width <= 800) {
            await page.locator('[data-menu-drawer]>summary').click();
            await page.locator('#home-navigation a').first().focus();
            await page.keyboard.press('Escape');
            assert.equal(await page.locator('[data-menu-drawer]').getAttribute('open'), null);
        }
        await page.locator('[data-search-panel]>summary').click();
        await page.locator('#home-search').fill('not-in-catalog');
        await page.locator('[data-search-panel] button').click();
        await page.waitForURL('**/?q=not-in-catalog#new-arrivals');
        assert.equal(await page.locator('.product-card').count(), 0);
        assert.equal(await page.locator('.empty-state').isVisible(), true);
        await page.goto('http://127.0.0.1:8000/?category=slim-fit#new-arrivals');
        assert.equal(await page.locator('.product-card').count(), 4);
        await page.locator('.product-add').first().click();
        assert.match(page.url(), /\/products\/fixture-denim-\d+\?color=Blue/);
        await page.goto('http://127.0.0.1:8000/');
        await page.locator('.cart-link').click();
        await page.waitForURL('**/cart');
        await page.goto('http://127.0.0.1:8000/');
        await page.locator('.product-wishlist').first().click();
        await page.waitForURL('**/account');
        console.log(`PASS homepage interactions and layout ${width}px`);
    }
    // Six fixture cards are enough for a compact full-page visual review; production pagination was checked above.
    for (const [label, width] of [['MOBILE', 395], ['DESKTOP', 1440]]) {
        await page.setViewportSize({width, height: 950});
        await page.goto('http://127.0.0.1:8000/', {waitUntil: 'networkidle'});
        await page.evaluate(() => { document.querySelectorAll('.product-card').forEach((card, index) => { if (index >= 6) card.remove(); }); document.querySelector('.show-more')?.remove(); });
        await loadImages();
        await page.evaluate(() => scrollTo(0, 0));
        await page.screenshot({path: `homepage-ui-artifacts/${label.toLowerCase()}.png`, fullPage: true});
        const jpeg = await page.screenshot({type: 'jpeg', quality: 45, fullPage: true});
        console.log(`UI_PREVIEW_${label}_BASE64:${jpeg.toString('base64')}`);
    }
    // Normal motion animates on entry; opting out removes it without hiding content.
    await page.emulateMedia({reducedMotion: 'no-preference'});
    await page.goto('http://127.0.0.1:8000/');
    await page.locator('.catalog').scrollIntoViewIfNeeded();
    await page.waitForFunction(() => document.querySelector('.catalog').classList.contains('home-revealed'));
    assert.equal(await page.locator('.catalog').evaluate(el => getComputedStyle(el).animationName), 'home-rise');
    await page.emulateMedia({reducedMotion: 'reduce'});
    await page.waitForFunction(() => !document.querySelector('.catalog').classList.contains('home-revealed'));
    assert.equal(await page.locator('.catalog').isVisible(), true);
    assert.equal(await page.locator('.catalog').evaluate(el => getComputedStyle(el).animationName), 'none');
    console.log('PASS centered categories, purple glass actions, footer and motion preferences');
    assert.deepEqual(errors, [], 'Browser errors');
    await browser.close();
})().catch(async error => {
    console.error(error);
    if (page && !page.isClosed()) {
        fs.writeFileSync('homepage-ui-artifacts/failure.html', await page.content());
        const jpeg = await page.screenshot({type: 'jpeg', quality: 40, fullPage: true});
        console.log(`UI_PREVIEW_FAILURE_BASE64:${jpeg.toString('base64')}`);
    }
    await browser?.close(); process.exitCode = 1;
});
