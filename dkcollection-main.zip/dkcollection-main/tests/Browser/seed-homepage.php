<?php
// Isolated CI/browser fixture. Never run against a production database.
require __DIR__.'/../../vendor/autoload.php';
$app = require __DIR__.'/../../bootstrap/app.php';
$app->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap();
set_exception_handler(function (Throwable $error) { fwrite(STDERR, $error->getMessage().PHP_EOL); exit(1); });
if (! app()->environment('testing') || config('database.default') !== 'sqlite' || basename(config('database.connections.sqlite.database')) !== 'homepage-ui.sqlite') {
    throw new RuntimeException('Homepage fixture requires testing + isolated homepage-ui.sqlite.');
}
$disk = Illuminate\Support\Facades\Storage::disk('public');
$disk->put('ui-fixture/denim.webp', file_get_contents(__DIR__.'/denim-fixture.webp'));
$disk->put('homepage/image-banners/main/fixture.webp', file_get_contents(public_path('images/home-reference/hero.webp')));
$disk->put('homepage/image-banners/promotional/fixture.webp', file_get_contents(public_path('images/home-reference/collection.webp')));
$categoryIds = [];
foreach (['Slim Fit', 'Straight Fit', 'Relaxed Fit', 'Baggy Fit', 'Tapered Fit', 'Cargo Jeans'] as $name) {
    $categoryIds[] = App\Models\Category::create(['name' => $name, 'slug' => Illuminate\Support\Str::slug($name), 'is_active' => true])->id;
}
$ids = [];
for ($i = 1; $i <= 21; $i++) {
    $product = App\Models\Product::create(['category_id' => $categoryIds[($i - 1) % 6], 'title' => 'Classic Denim '.$i, 'slug' => 'fixture-denim-'.$i, 'article_code' => (string) (3200 + $i), 'price_paise' => 164900, 'mrp_paise' => 249900, 'image_path' => 'ui-fixture/denim.webp', 'is_active' => true, 'sort_order' => $i]);
    $product->variants()->create(['size' => '30', 'color' => 'Blue', 'stock' => $i === 6 ? 0 : 4]);
    $ids[] = $product->id;
}
$store = App\Models\StoreSetting::create(['id' => 1, 'name' => 'Jansen Jeans', 'announcement' => 'FREE SHIPPING ON ₹1,499+ · EASY RETURNS · PREMIUM DENIM FOR ALL', 'free_shipping_above_paise' => 149900, 'shipping_policy' => 'Fixture shipping policy.', 'return_policy' => 'Fixture returns policy.', 'privacy_policy' => 'Fixture privacy policy.', 'terms_policy' => 'Fixture terms policy.', 'support_email' => 'support@example.test', 'homepage' => ['interval' => 15, 'category_ids' => $categoryIds, 'featured_ids' => array_slice($ids, 0, 4), 'new_arrival_ids' => array_slice($ids, 4), 'design' => ['hero_eyebrow' => 'THE DENIM EDIT'], 'footer' => ['about' => 'Fixture brand story', 'sustainability' => 'Fixture sustainability', 'size-guide' => 'Fixture size guide', 'instagram' => 'https://instagram.com/jansen', 'facebook' => 'https://facebook.com/jansen', 'youtube' => 'https://youtube.com/@jansen', 'pinterest' => 'https://pinterest.com/jansen']]]);
$user = App\Models\User::factory()->create(['name' => 'Fixture Customer']);
foreach (['The fit is perfect and the quality is next level.', 'Comfortable denim for everyday wear.', 'Great fit and helpful support.'] as $index => $body) {
    App\Models\Review::forceCreate(['user_id' => $user->id, 'product_id' => $ids[$index], 'rating' => 5, 'body' => $body, 'is_approved' => true]);
}
$homepage = $store->homepage;
$homepage['image_banners'] = [
    'main' => ['desktop_image' => 'homepage/image-banners/main/fixture.webp', 'mobile_image' => 'homepage/image-banners/main/fixture.webp', 'destination_url' => '/products/fixture-denim-1?color=Blue'],
    'promotional' => ['desktop_image' => 'homepage/image-banners/promotional/fixture.webp', 'mobile_image' => 'homepage/image-banners/promotional/fixture.webp', 'destination_url' => '/?category=slim-fit#new-arrivals'],
];
$store->update(['homepage' => $homepage]);
if (App\Models\Review::where('is_approved', true)->count() !== 3) throw new RuntimeException('Incomplete UI fixture.');
echo 'UI fixture ready: 21 products, 2 image banners, 3 approved reviews.'.PHP_EOL;
