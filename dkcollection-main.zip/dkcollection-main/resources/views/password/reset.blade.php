@extends('layout')
@section('title', 'Choose new password | DK Fashion Hub')
@section('content')
<h1>Choose a new password</h1>
<form class="form" method="post" action="{{ route('password.update') }}">@csrf
    <input type="hidden" name="token" value="{{ $token }}">
    <label>Email<input type="email" name="email" value="{{ old('email', $email) }}" required autocomplete="email"></label>
    <label>New password (12+ characters)<input type="password" name="password" minlength="12" required autocomplete="new-password"></label>
    <label>Confirm password<input type="password" name="password_confirmation" minlength="12" required autocomplete="new-password"></label>
    <button class="primary">Update password</button>
</form>
@endsection
