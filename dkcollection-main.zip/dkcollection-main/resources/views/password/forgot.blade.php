@extends('layout')
@section('title', 'Reset password | DK Fashion Hub')
@section('content')
<h1>Reset password</h1><p>Enter your account email. If it exists, we will send a reset link.</p>
<form class="form" method="post" action="{{ route('password.email') }}">@csrf
    <label>Email<input type="email" name="email" value="{{ old('email') }}" required autocomplete="email"></label>
    <button class="primary">Send reset link</button>
</form>
@endsection
