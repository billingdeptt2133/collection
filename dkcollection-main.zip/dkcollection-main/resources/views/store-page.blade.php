@extends('layout')
@section('title', $pageTitle.' | '.($store->name ?? 'Jansen Jeans'))
@section('content')
<section>
    <h1>{{ $pageTitle }}</h1>
    @if($page === 'contact')
        @if($store->support_email)<p><a href="mailto:{{ $store->support_email }}">{{ $store->support_email }}</a></p>@endif
        @if($store->support_phone)<p><a href="tel:{{ preg_replace('/[^0-9+]/', '', $store->support_phone) }}">{{ $store->support_phone }}</a></p>@endif
        @if($store->whatsapp)<p><a href="https://wa.me/{{ preg_replace('/[^0-9]/', '', $store->whatsapp) }}" target="_blank" rel="noopener noreferrer">WhatsApp</a></p>@endif
        @if($store->store_address)<address>{{ $store->store_address }}</address>@endif
        @unless($store->support_email || $store->support_phone || $store->whatsapp)<p>Contact details will be available here soon.</p>@endunless
    @else
        <div style="white-space:pre-line;line-height:1.8">{{ $pageText }}</div>
    @endif
</section>
@endsection
