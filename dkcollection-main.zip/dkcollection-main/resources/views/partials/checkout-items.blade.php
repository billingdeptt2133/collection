<div class="checkout-summary-items">
@foreach($lines as $line)
    @php
        $variant = $line->variant;
        $product = $variant->product;
        $mapped = $product->images->where('color', $variant->color)->first();
        $photo = $mapped ? asset('storage/'.$mapped->path) : ($product->variants->pluck('color')->unique()->count() === 1 ? $product->displayImage() : null);
    @endphp
    <article class="checkout-summary-item"><div class="checkout-item-photo">@if($photo)<img src="{{ $photo }}" alt="{{ $product->title }} — {{ $variant->color }}" loading="lazy">@else<span>DK</span>@endif</div><div><h3>{{ $product->title }}</h3><p>{{ $variant->color }} / Size {{ $variant->size }}</p><p>Qty {{ $line->quantity }}</p></div><strong>₹{{ number_format($product->price_paise * $line->quantity / 100, 2) }}</strong></article>
@endforeach
</div>
