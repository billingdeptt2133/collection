<article class="product-card" data-product-id="{{ $product->id }}" data-product-colour="{{ $card['color'] }}">
    <a href="{{ $card['url'] }}">
        <div class="product-image">
            @if($card['image'])<img src="{{ $card['image'] }}" alt="{{ $card['title'] }}" loading="lazy" decoding="async">@else<span aria-label="Photo unavailable for this colour">DK</span>@endif
            @if($card['soldOut'])<span class="colour-card-status">Sold out</span>@endif
            <span class="card-discover">View details <span aria-hidden="true">↗</span></span>
        </div>
        <div class="product-info">
            @if($product->is_demo)<span class="demo-label">Demo product</span>@endif
            @if(filled($product->pattern))<span class="product-card-fit">{{ $product->pattern }}</span>@endif
            <h3>{{ $card['title'] }}</h3>
            <p class="product-card-prices">
                <span class="product-card-price"><span class="product-card-sr-only">Selling price </span>₹{{ number_format($product->price_paise / 100, 2) }}</span>
                @if($product->mrp_paise > $product->price_paise && $product->price_paise > 0)
                    @php($discountPercent = (int) floor(($product->mrp_paise - $product->price_paise) * 100 / $product->mrp_paise))
                    <del class="product-card-mrp"><span class="product-card-sr-only">MRP </span>₹{{ number_format($product->mrp_paise / 100, 2) }}</del>
                    @if($discountPercent > 0)<span class="product-card-discount">{{ $discountPercent }}% OFF</span>@endif
                @endif
            </p>
            @if($product->article_code)<small class="colour-card-article">Article {{ $product->article_code }}</small>@endif
        </div>
    </a>
</article>
