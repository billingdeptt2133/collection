<svg class="ui-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">
@switch($icon)
    @case('menu')<path d="M4 6h16M4 12h16M4 18h16"/>@break
    @case('search')<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 5 5"/>@break
    @case('heart')<path d="M20.8 4.6a5.4 5.4 0 0 0-7.6 0L12 5.8l-1.2-1.2a5.4 5.4 0 0 0-7.6 7.6L12 21l8.8-8.8a5.4 5.4 0 0 0 0-7.6Z"/>@break
    @case('bag')<path d="M5 7h14l1 14H4L5 7Z"/><path d="M9 8V6a3 3 0 0 1 6 0v2"/>@break
    @case('truck')<path d="M2 5h12v12H2zM14 9h4l4 4v4h-8"/><circle cx="6" cy="18" r="2"/><circle cx="18" cy="18" r="2"/>@break
    @case('returns')<path d="M4 9a8 8 0 1 1 0 7M4 3v6h6"/>@break
    @case('gem')<path d="m3 8 4-5h10l4 5-9 13L3 8Zm0 0h18M7 3l5 18 5-18"/>@break
    @case('card')<rect x="2" y="4" width="20" height="16" rx="2"/><path d="M2 9h20M6 15h4"/>@break
    @case('arrow')<path d="M4 12h16m-6-6 6 6-6 6"/>@break
    @case('chevron')<path d="m9 5 7 7-7 7"/>@break
    @case('close')<path d="m6 6 12 12M6 18 18 6"/>@break
    @case('instagram')<rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r=".7" fill="currentColor"/>@break
    @case('facebook')<path d="M14 21v-8h3l.5-4H14V7c0-1 .5-1.5 1.5-1.5H18V2h-3c-3 0-5 2-5 5v2H7v4h3v8"/>@break
    @case('youtube')<rect x="2" y="5" width="20" height="14" rx="4"/><path d="m10 9 5 3-5 3V9Z"/>@break
    @case('pinterest')<circle cx="12" cy="12" r="9"/><path d="m9 21 3-14m-2 7c5 3 9-6 4-7-5-2-8 5-5 7"/>@break
    @case('whatsapp')<path d="M21 11.5a9 9 0 0 1-13.4 7.8L3 21l1.5-4.5A9 9 0 1 1 21 11.5Z"/><path d="m8 7 2 3-1 1c1 2 2 3 4 4l1-1 3 1c-1 3-4 3-7 0S5 9 8 7Z"/>@break
@endswitch
</svg>
