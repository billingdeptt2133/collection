@php
    $footer = $homepage['footer'] ?? [];
    $needHelp = ['Track Your Order' => route('orders')];
    if (filled($store->return_policy)) $needHelp['Returns & Exchanges'] = route('policy', 'returns');
    $needHelp['Contact Us'] = route('store.page', 'contact');
    if (filled($footer['faqs'] ?? null)) $needHelp['FAQs'] = route('store.page', 'faqs');
    $company = [];
    if (filled($footer['about'] ?? null)) $company['About Us'] = route('store.page', 'about');
    foreach (['privacy' => ['privacy_policy', 'Privacy Policy'], 'terms' => ['terms_policy', 'Terms & Conditions'], 'shipping' => ['shipping_policy', 'Shipping & Delivery Policy'], 'returns' => ['return_policy', 'Returns & Refund Policy']] as $policy => [$field, $label]) {
        if (filled($store->$field)) $company[$label] = route('policy', $policy);
    }
    $socials = [];
    foreach (['instagram' => 'Instagram', 'facebook' => 'Facebook'] as $network => $label) {
        $url = $footer[$network] ?? '';
        if (is_string($url) && preg_match('~^https://(?:www\.)?'.preg_quote($network, '~').'\.com/[^\s]*$~i', $url)) $socials[$network] = ['label' => $label, 'url' => $url];
    }
    if ($store->whatsapp) $socials['whatsapp'] = ['label' => 'WhatsApp', 'url' => 'https://wa.me/'.preg_replace('/[^0-9]/', '', $store->whatsapp)];
@endphp
<footer class="jj-footer">
    <div class="jj-footer-grid">
        <div class="jj-footer-brand">
            <a class="jj-footer-wordmark" href="{{ route('home') }}">{{ $store->name ?? 'Jansen Jeans' }}</a>
            <p>Denim for wherever the day takes you.</p>
            @if($store->store_address)<address>{{ $store->store_address }}</address>@endif
            @if($socials)<div class="jj-footer-socials">
                @foreach($socials as $icon => $social)
                    <a href="{{ $social['url'] }}" aria-label="{{ $social['label'] }}" target="_blank" rel="noopener noreferrer">@include('partials.footer-icon', ['icon' => $icon])</a>
                @endforeach
            </div>@endif
        </div>
        @foreach(['Need Help' => $needHelp, 'Company' => $company] as $heading => $links)
            @if($links)
            <details class="jj-footer-group" data-footer-group open>
                <summary>{{ $heading }}<span class="jj-footer-toggle" aria-hidden="true"></span></summary>
                <nav aria-label="{{ $heading }}" class="jj-footer-links">
                    @foreach($links as $label => $url)<a href="{{ $url }}">{{ $label }}</a>@endforeach
                </nav>
            </details>
            @endif
        @endforeach
        <details class="jj-footer-group" data-footer-group open>
            <summary>Get in touch<span class="jj-footer-toggle" aria-hidden="true"></span></summary>
            <div class="jj-footer-links">
                @foreach($socials as $icon => $social)
                    <a class="jj-footer-social-link" href="{{ $social['url'] }}" target="_blank" rel="noopener noreferrer">@include('partials.footer-icon', ['icon' => $icon]){{ $social['label'] }}</a>
                @endforeach
                @if($store->support_email)<a href="mailto:{{ $store->support_email }}">{{ $store->support_email }}</a>@endif
                @if($store->support_phone)<a href="tel:{{ preg_replace('/[^0-9+]/', '', $store->support_phone) }}">{{ $store->support_phone }}</a>@endif
                <a class="jj-footer-support" href="{{ route('store.page', 'contact') }}">@include('partials.footer-icon', ['icon' => 'support'])<span>{{ $footer['support_label'] ?? 'Help & Support Team' }}</span></a>
            </div>
        </details>
        <div class="jj-footer-bottom"><span>© {{ date('Y') }} {{ $store->name ?? 'Jansen Jeans' }}. All rights reserved.</span><a href="{{ route('cart') }}">Your bag ↗</a></div>
    </div>
</footer>
