@php
    $footer = $homepage['footer'] ?? [];
    $socials = [];
    foreach (['instagram', 'facebook', 'youtube', 'pinterest'] as $network) {
        $url = $footer[$network] ?? '';
        if (is_string($url) && preg_match('~^https://(?:www\.)?'.preg_quote($network, '~').'\.com/[^\s]*$~i', $url)) $socials[$network] = $url;
    }
    if ($store->whatsapp) $socials['whatsapp'] = 'https://wa.me/'.preg_replace('/[^0-9]/', '', $store->whatsapp);
@endphp
<footer class="editorial-footer">
    <div class="footer-shell">
        <div class="footer-top">
            <a class="editorial-brand" href="{{ route('home') }}" aria-label="{{ $store->name ?? 'Jansen Jeans' }} home">
                @if($store->logo_path)<img src="{{ asset('storage/'.$store->logo_path) }}" alt="{{ $store->name ?? 'Jansen Jeans' }}" width="150" height="50">
                @else<span>{{ preg_replace('/\s+jeans$/i', '', $store->name ?? 'Jansen Jeans') }}</span><small>JEANS</small>@endif
            </a>
            @if($socials)<nav class="footer-socials" aria-label="Social media">@foreach($socials as $icon => $url)<a href="{{ $url }}" aria-label="{{ ucfirst($icon) }}" target="_blank" rel="noopener noreferrer">@include('partials.home-ui-icon', ['icon' => $icon])</a>@endforeach</nav>@endif
        </div>
        <div class="footer-columns">
            <nav aria-label="Shop"><h2>SHOP</h2><a href="{{ route('home') }}#new-arrivals">New Arrivals</a><a href="{{ route('home') }}#collections">Shop by Fit</a><a href="{{ route('home') }}#new-arrivals">Best Sellers</a><a href="{{ route('cart') }}">Your Bag</a></nav>
            <nav aria-label="Customer Care"><h2>CUSTOMER CARE</h2><a href="{{ route('orders') }}">Track Your Order</a>@if(filled($store->return_policy))<a href="{{ route('policy', 'returns') }}">Returns &amp; Exchanges</a>@endif<a href="{{ route('store.page', 'contact') }}">Contact Us</a>@if(filled($footer['faqs'] ?? null))<a href="{{ route('store.page', 'faqs') }}">FAQs</a>@endif
            @if($store->support_email)<a href="mailto:{{ $store->support_email }}">{{ $store->support_email }}</a>@endif
            @if($store->support_phone)<a href="tel:{{ preg_replace('/[^0-9+]/', '', $store->support_phone) }}">{{ $store->support_phone }}</a>@endif
            @if(filled($footer['support_label'] ?? null))<span>{{ $footer['support_label'] }}</span>@endif
            </nav>
            <nav aria-label="About Us"><h2>ABOUT US</h2>
                @foreach(['about' => 'Our Story', 'sustainability' => 'Sustainability', 'size-guide' => 'Size Guide'] as $page => $label)@if(filled($footer[$page] ?? null))<a href="{{ route('store.page', $page) }}">{{ $label }}</a>@endif @endforeach
                @if(filled($store->privacy_policy))<a href="{{ route('policy', 'privacy') }}">Privacy Policy</a>@endif
                @if(filled($store->terms_policy))<a href="{{ route('policy', 'terms') }}">Terms &amp; Conditions</a>@endif
                @if(filled($store->shipping_policy))<a href="{{ route('policy', 'shipping') }}">Shipping &amp; Delivery Policy</a>@endif
                @if(filled($store->return_policy))<a href="{{ route('policy', 'returns') }}">Returns &amp; Refund Policy</a>@endif
            </nav>
        </div>
        @if($store->store_address)<address>{{ $store->store_address }}</address>@endif
        <div class="footer-copyright">© {{ date('Y') }} {{ $store->name ?? 'Jansen Jeans' }}. All rights reserved.</div>
    </div>
</footer>
