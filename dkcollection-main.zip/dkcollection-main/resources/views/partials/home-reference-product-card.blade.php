@php
    $discountPercent = 0;
    $isFeatured = in_array($product->id, $homepage['featured_ids'] ?? []);
    $isArrival = in_array($product->id, $homepage['new_arrival_ids'] ?? []);
    $saved = in_array($product->id, $wishlistIds);
@endphp
<article class="product-card" data-product-id="{{ $product->id }}" data-product-colour="{{ $card['color'] }}">
    <div class="product-image">
        <a class="product-photo-link" href="{{ $card['url'] }}" aria-label="{{ $card['title'] }}">
            @if($card['image'])<img src="{{ $card['image'] }}" alt="{{ $card['title'] }}" loading="lazy" decoding="async">@else<span class="photo-unavailable">Photo unavailable</span>@endif
        </a>
        @if($card['soldOut'])<span class="product-badge sold-out">Sold out</span>
        @elseif($isFeatured)<span class="product-badge">BEST SELLER</span>
        @elseif($isArrival)<span class="product-badge">NEW</span>@endif
        @auth
            <form class="product-wishlist" method="post" action="{{ route('wishlist.toggle', $product) }}">
                @csrf
                <button class="wishlist-heart {{ $saved ? 'is-saved' : '' }}" aria-label="{{ $saved ? 'Remove '.$card['title'].' from wishlist' : 'Save '.$card['title'].' to wishlist' }}" aria-pressed="{{ $saved ? 'true' : 'false' }}">@include('partials.home-ui-icon', ['icon' => 'heart'])</button>
            </form>
        @else
            <a class="product-wishlist wishlist-heart" href="{{ route('wishlist') }}" aria-label="Sign in to save {{ $card['title'] }}">@include('partials.home-ui-icon', ['icon' => 'heart'])</a>
        @endauth
        <span class="product-colour-pill">{{ $card['color'] }}</span>
    </div>
    <div class="product-info">
        @if($product->is_demo)<span class="demo-label">Demo product</span>@endif
        @if(filled($product->pattern))<span class="sr-only">{{ $product->pattern }}</span>@endif
        <a href="{{ $card['url'] }}"><h3 title="{{ $card['title'] }}">{{ $card['title'] }}</h3></a>
        <p class="product-card-prices">
            <span class="product-card-price"><span class="sr-only">Selling price </span>₹{{ number_format($product->price_paise / 100, 2) }}</span>
            @if($product->mrp_paise > $product->price_paise && $product->price_paise > 0)
                @php($discountPercent = (int) floor(($product->mrp_paise - $product->price_paise) * 100 / $product->mrp_paise))
                <del class="product-card-mrp"><span class="sr-only">MRP </span>₹{{ number_format($product->mrp_paise / 100, 2) }}</del>
            @endif
        </p>
        @if(isset($discountPercent) && $discountPercent > 0)<span class="product-card-discount">{{ $discountPercent }}% OFF</span>@endif
        <div class="product-card-bottom">
            @if($product->article_code)<small class="colour-card-article">Article {{ $product->article_code }}</small>@else<span></span>@endif
            <a class="product-add" href="{{ $card['url'] }}" aria-label="{{ $card['soldOut'] ? 'View '.$card['title'] : 'Choose size and add '.$card['title'].' to cart' }}">{{ $card['soldOut'] ? 'VIEW' : '+ ADD' }}</a>
        </div>
    </div>
</article>
