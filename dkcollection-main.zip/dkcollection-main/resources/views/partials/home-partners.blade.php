@php
    $partners = collect($homepage['partners'] ?? [])->filter(fn ($partner) =>
        is_array($partner) && !empty($partner['visible']) && filled($partner['name'] ?? null)
        && is_string($partner['image'] ?? null)
        && preg_match('~^homepage/partners/[A-Za-z0-9_-]+\.(?:jpe?g|png|webp)$~i', $partner['image'])
    )->take(12);
@endphp
@if($partners->isNotEmpty())
<section class="jj-partners" aria-labelledby="partners-title">
    <div class="home-section-heading">
        <span class="eyebrow">OUR PARTNER NETWORK</span>
        <h2 id="partners-title">Shop with confidence</h2>
        <p>Payments, delivery and retail — connected by trust.</p>
    </div>
    <div class="jj-partners-track" tabindex="0" role="region" aria-label="Our partners, scroll horizontally" data-partner-track>
        @foreach($partners as $partner)
            <article class="jj-partner-card">
                <img src="{{ asset('storage/'.$partner['image']) }}" alt="{{ $partner['name'] }}" width="200" height="80" loading="lazy" decoding="async" draggable="false">
                @if(filled($partner['label'] ?? null))<span>{{ $partner['label'] }}</span>@endif
            </article>
        @endforeach
    </div>
</section>
@endif
