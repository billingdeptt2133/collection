@if($banner['desktop_image'])
<section class="{{ $slot === 'main' ? 'editorial-hero' : 'collection-section page-shell' }}" aria-label="{{ $slot === 'main' ? 'Main banner' : 'Promotional banner' }}">
    <a class="{{ $slot === 'main' ? 'editorial-slide' : 'collection-banner' }} image-only-banner" href="{{ $banner['destination_url'] }}" aria-label="{{ $slot === 'main' ? 'Shop main banner' : 'Shop promotional banner' }}">
        <picture>
            @if($banner['mobile_image'])<source media="(max-width:800px)" srcset="{{ asset('storage/'.$banner['mobile_image']) }}">@endif
            <img src="{{ asset('storage/'.$banner['desktop_image']) }}" alt="{{ $slot === 'main' ? 'Main collection banner' : 'Promotional collection banner' }}" @if($slot === 'main')fetchpriority="high"@else loading="lazy"@endif decoding="async">
        </picture>
    </a>
</section>
@endif
