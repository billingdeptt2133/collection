@extends('layout')
@section('title',$policyTitle.' | DK Fashion Hub')
@section('robots','index,follow')
@section('content')
<section><h1 style="color:var(--ink);font-size:36px">{{ $policyTitle }}</h1><div style="white-space:pre-line;line-height:1.8">{{ $policyText }}</div></section>
@endsection
