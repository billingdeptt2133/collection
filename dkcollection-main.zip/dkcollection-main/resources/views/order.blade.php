@extends('layout')
@section('title', 'Order #'.$order->id.' | '.($store->name ?? 'DK Fashion Hub'))
@section('robots', 'noindex,nofollow')
@push('styles')
<link rel="stylesheet" href="{{ asset('css/order.css') }}?v=1">
@endpush
@section('content')
<div class="dk-order">
    <nav class="dk-order-breadcrumb" aria-label="Breadcrumb"><a href="{{ route('orders') }}">← My orders</a><span aria-hidden="true">/</span><span>Order #{{ $order->id }}</span></nav>
    <header class="dk-order-heading"><div><p class="dk-order-reference">ORDER #{{ $order->id }} · {{ $order->created_at->format('d M Y') }}</p><h1>{{ $presentation['heading'] }}</h1><p>{{ $presentation['message'] }}</p></div><button class="dk-order-button dk-order-print" type="button" data-print-order>Print order</button></header>

    @if(! $presentation['cancelled'] && ! $presentation['returned'])
    <section class="dk-order-panel dk-order-progress" aria-label="Order progress">
        <ol>
            @foreach(['Order placed', 'Preparing', 'Dispatched', 'Delivered'] as $index => $label)
                @php($done = ! $presentation['needsPayment'] && ($index < $presentation['stage'] || $order->status === 'delivered'))
                @php($current = $index === $presentation['stage'] && $order->status !== 'delivered')
                <li @class(['is-complete' => $done, 'is-current' => $current]) @if($current) aria-current="step" @endif><span class="dk-order-step" aria-hidden="true">{{ $done ? '✓' : $index + 1 }}</span><strong>{{ $label }}</strong><small>{{ $done ? 'Completed' : ($current ? ($presentation['needsPayment'] ? 'Awaiting payment' : 'In progress') : 'Pending') }}</small></li>
            @endforeach
        </ol>
        <p class="dk-order-progress-note">{{ $presentation['needsPayment'] ? 'Payment is confirmed only after verification.' : ($order->status === 'delivered' ? 'Your parcel has been delivered.' : ($order->status === 'shipped' ? 'Your parcel has been dispatched.' : 'Delivery details will appear after dispatch.')) }}</p>
    </section>
    @else
        <p class="dk-order-state-note" role="status">{{ $presentation['returned'] ? 'Returned parcel · Our store will help with the next steps.' : 'Cancelled order · Payment and refund status are handled separately.' }}</p>
    @endif

    <div class="dk-order-grid">
        <div class="dk-order-main">
            <section class="dk-order-panel dk-order-items"><h2>Items in your order</h2><div class="dk-order-item-labels" aria-hidden="true"><span>Product</span><span>Quantity</span><span>Unit price</span><span>Total</span></div>
                @foreach($order->items as $item)
                    @php($image = \App\Support\OrderPresentation::image($item))
                    <article class="dk-order-item"><div class="dk-order-product"><div class="dk-order-photo">@if($image)<img src="{{ $image }}" alt="{{ $item->title }} — {{ $item->color }}" width="110" height="132" loading="lazy">@else<span aria-label="Product image unavailable">DK</span>@endif</div><div><h3>{{ $item->title }}</h3><p>Size {{ $item->size }} <span aria-hidden="true">·</span> {{ $item->color }}</p><p class="dk-order-mobile-quantity">Qty {{ $item->quantity }}</p></div></div><div class="dk-order-quantity"><span class="dk-order-sr-only">Quantity </span>{{ $item->quantity }}</div><div class="dk-order-unit"><span class="dk-order-sr-only">Unit price </span>₹{{ number_format($item->price_paise / 100, 2) }}<small class="dk-order-mobile-each"> each</small></div><strong class="dk-order-line-total"><span class="dk-order-sr-only">Item total </span>₹{{ number_format($item->price_paise * $item->quantity / 100, 2) }}</strong></article>
                @endforeach
            </section>

            <section class="dk-order-panel dk-order-delivery"><div class="dk-order-panel-heading"><h2>Delivery information</h2><span class="dk-order-tag">{{ $order->shipping_provider === 'shiprocket' ? 'Courier updates' : 'Store updates' }}</span></div>
                @if($presentation['courier'] || $presentation['trackingNumber'])
                    <dl class="dk-order-delivery-fields">@if($presentation['courier'])<div><dt>Courier</dt><dd>{{ $presentation['courier'] }}</dd></div>@endif @if($presentation['trackingNumber'])<div><dt>Tracking number</dt><dd>{{ $presentation['trackingNumber'] }}</dd></div>@endif</dl>
                    @if($presentation['trackingUrl'])<a class="dk-order-button" href="{{ $presentation['trackingUrl'] }}" target="_blank" rel="noopener noreferrer">Track with courier ↗</a>@endif
                @elseif(! $presentation['cancelled'] && ! $presentation['returned'])
                    @if($order->status === 'delivered')<h3>Your parcel has been delivered</h3><p>Contact our store if you need courier details.</p>
                    @elseif($order->status === 'shipped')<h3>Your parcel has been dispatched</h3><p>Courier and tracking details will appear when our store adds them.</p>
                    @else<h3>{{ $presentation['needsPayment'] ? 'Awaiting payment confirmation' : 'Preparing your shipment' }}</h3><p>Courier and tracking number will be added after dispatch.</p>@endif
                @else
                    <p>Contact our store for help with delivery details.</p>
                @endif
                @if($order->shipping_provider === 'shiprocket' && $order->shipment?->tracking_status)<p class="dk-order-carrier-status">{{ $order->shipment->tracking_status }}</p>@endif
                @if($order->shipping_provider === 'shiprocket' && $order->shipment?->synced_at)<p class="dk-order-muted">Last verified {{ $order->shipment->synced_at->format('d M Y, h:i A') }}</p>@elseif($order->shipping_provider !== 'shiprocket')<p class="dk-order-muted">Updates provided by our store.</p>@endif
                @if($presentation['events'])<ol class="dk-order-events" aria-label="Courier tracking history">@foreach($presentation['events'] as $event)@if(is_array($event))<li><strong>{{ $event['activity'] ?? '' }}</strong><span>{{ $event['date'] ?? '' }}@if(filled($event['location'] ?? null)) · {{ $event['location'] }}@endif</span></li>@endif @endforeach</ol>
                @elseif($order->shipped_at || $order->delivered_at)<ol class="dk-order-events" aria-label="Delivery milestones">@if($order->delivered_at)<li><strong>Delivered</strong><span>{{ \Illuminate\Support\Carbon::parse($order->delivered_at)->format('d M Y, h:i A') }}</span></li>@endif @if($order->shipped_at)<li><strong>Dispatched</strong><span>{{ \Illuminate\Support\Carbon::parse($order->shipped_at)->format('d M Y, h:i A') }}</span></li>@endif</ol>@endif
            </section>

            <section class="dk-order-panel dk-order-address"><h2>Shipping address</h2><address><strong>{{ $order->name }}</strong><span>{{ $order->address }}</span><span>{{ $order->city }}, {{ $order->state }} {{ $order->pincode }}</span><span>{{ $order->phone }}</span></address></section>
        </div>

        <aside class="dk-order-aside" aria-label="Order summary and payment">
            <section class="dk-order-panel dk-order-summary"><h2>Order summary</h2><dl><div><dt>Subtotal</dt><dd>₹{{ number_format($order->subtotal_paise / 100, 2) }}</dd></div><div><dt>Discount</dt><dd>{{ $order->discount_paise > 0 ? '−' : '' }}₹{{ number_format($order->discount_paise / 100, 2) }}</dd></div><div><dt>Shipping</dt><dd @class(['dk-order-free' => (int)$order->shipping_paise === 0])>{{ (int)$order->shipping_paise === 0 ? 'FREE' : '₹'.number_format($order->shipping_paise / 100, 2) }}</dd></div><div><dt>COD fee</dt><dd>₹{{ number_format($order->cod_fee_paise / 100, 2) }}</dd></div><div class="dk-order-total"><dt>Total</dt><dd>₹{{ number_format($order->total_paise / 100, 2) }}</dd></div></dl></section>
            <section class="dk-order-payment"><h2>{{ $order->payment_method === 'cod' ? 'Cash on delivery' : 'Online payment' }}</h2><p>
                @if($order->payment_status === 'paid')Payment received · ₹{{ number_format($order->total_paise / 100, 2) }}. Any refund is confirmed separately.
                @elseif($presentation['cancelled'] || $presentation['returned'])This order is closed or returning. Contact our store for payment assistance.
                @elseif($order->payment_method === 'cod' && $order->status === 'delivered')COD collection is awaiting confirmation by our store.
                @elseif($order->payment_method === 'cod')Pay ₹{{ number_format($order->total_paise / 100, 2) }} when your order arrives.
                @else Awaiting verified payment.
                @endif
            </p>@if($presentation['needsPayment'])<a class="dk-order-button dk-order-button-primary" href="{{ route('payments.show', $order) }}">Complete payment</a>@endif</section>
            <section class="dk-order-panel dk-order-help"><h2>Need help with this order?</h2><p>We’re here to help you.</p>
                @php($supportEmail = filter_var($store->support_email, FILTER_VALIDATE_EMAIL))
                @php($whatsapp = preg_match('/^[0-9]{7,15}$/', (string)$store->whatsapp) ? $store->whatsapp : null)
                @if($whatsapp)<a class="dk-order-button" href="https://wa.me/{{ $whatsapp }}" target="_blank" rel="noopener noreferrer">Contact support</a>
                @elseif($supportEmail)<a class="dk-order-button" href="mailto:{{ rawurlencode($supportEmail) }}">Contact support</a>
                @elseif($store->support_phone)<p>{{ $store->support_phone }}</p>
                @else<p class="dk-order-muted">Support contact details will appear here when configured by our store.</p>@endif
            </section>
        </aside>
    </div>
    <div class="dk-order-actions"><button class="dk-order-button dk-order-mobile-print" type="button" data-print-order>Print order</button><a class="dk-order-button dk-order-button-primary" href="{{ route('home') }}">Continue shopping →</a></div>
    <p class="dk-order-print-note">Order summary — not a tax invoice.</p>
</div>
<script src="{{ asset('js/order.js') }}?v=1" defer></script>
@endsection
