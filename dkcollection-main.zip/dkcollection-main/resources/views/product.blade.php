@extends('layout')
@section('title', $product->seo_title ?: $product->title.' | DK Fashion Hub')
@section('description', $product->seo_description ?: \Illuminate\Support\Str::limit(strip_tags($product->description ?: $product->title.' at DK Fashion Hub'), 155))
@section('canonical', route('products.show', $product->slug))
@section('robots', $product->is_demo ? 'noindex,follow' : 'index,follow')
@section('og_image', $product->displayImage() ?: '')
@push('styles')
<link rel="stylesheet" href="{{ asset('css/product-detail.css') }}?v=2">
@endpush
@section('content')
@php
    $initialColor = $presentation['initialColor'];
    $initialPhotos = $product->images->where('color', $initialColor)->values();
    $hasMappedPhotos = $product->images->contains(fn ($image) => filled($image->color));
    $gallery = $initialPhotos->map(fn ($image) => asset('storage/'.$image->path))->all();
    if (! $hasMappedPhotos && $product->variants->pluck('color')->unique()->count() === 1) {
        $gallery = array_values(array_unique(array_filter(array_merge([$product->displayImage()], $product->images->map(fn ($image) => asset('storage/'.$image->path))->all()))));
    }
    $colors = $product->variants->pluck('color')->unique()->values();
    $sizes = $product->variants->pluck('size')->unique()->values();
@endphp
<div class="pdp" data-product-detail data-product-title="{{ $product->title }}"
    data-presentation="{{ json_encode($presentation, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) }}"
    data-availability-url="{{ route('products.availability', $product->slug) }}">
    <nav class="pdp-breadcrumb" aria-label="Breadcrumb">
        <a href="{{ route('home') }}">Home</a><span>/</span>
        @if($product->category)<a href="{{ route('home', ['category' => $product->category->slug]) }}#new-arrivals">{{ $product->category->name }}</a><span>/</span>@endif
        <span>{{ $product->title }}</span>
    </nav>
    <div class="pdp-layout">
        <div class="pdp-gallery">
            <div class="pdp-gallery-main">
                <div class="pdp-track" data-gallery-track aria-label="Product photographs" tabindex="0">
                    @foreach($gallery as $src)
                        <div class="pdp-photo"><img src="{{ $src }}" alt="{{ $product->title }} — view {{ $loop->iteration }}" loading="{{ $loop->first ? 'eager' : 'lazy' }}" decoding="async"></div>
                    @endforeach
                </div>
                <p class="pdp-photo-empty" data-gallery-empty @if(count($gallery)) hidden @endif>No photos assigned to this colour yet.</p>
                @auth
                    <form class="pdp-wishlist" method="post" action="{{ route('wishlist.toggle', $product) }}">
                        @csrf
                        <button type="submit" class="{{ $wishlisted ? 'is-saved' : '' }}" aria-pressed="{{ $wishlisted ? 'true' : 'false' }}" aria-label="{{ $wishlisted ? 'Remove from wishlist' : 'Add to wishlist' }}">
                            <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8L12 21l8.8-8.6a5.5 5.5 0 0 0 0-7.8Z"/></svg>
                        </button>
                    </form>
                @else
                    <a class="pdp-wishlist pdp-wishlist-link" href="{{ route('login') }}" aria-label="Sign in to save this product">
                        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8L12 21l8.8-8.6a5.5 5.5 0 0 0 0-7.8Z"/></svg>
                    </a>
                @endauth
                <button type="button" class="pdp-gallery-arrow pdp-gallery-prev" data-gallery-prev aria-label="Previous photograph" hidden>‹</button>
                <button type="button" class="pdp-gallery-arrow pdp-gallery-next" data-gallery-next aria-label="Next photograph" hidden>›</button>
                <span class="pdp-gallery-count" data-gallery-count @if(!count($gallery)) hidden @endif>1 / {{ count($gallery) }}</span>
            </div>
            <div class="pdp-thumbnails" data-gallery-thumbnails aria-label="Choose a photograph"></div>
        </div>
        <div class="pdp-info">
            @if($product->is_demo)<p class="demo-label">Demo product · sample price and image</p>@endif
            <span class="pdp-eyebrow">{{ $product->category?->name ?? 'DK COLLECTION' }}</span>
            <h1 data-product-heading>{{ $initialColor ? $initialColor.' ' : '' }}{{ $product->title }}</h1>
            <div class="pdp-price">
                <strong>₹{{ number_format($product->price_paise / 100, 2) }}</strong>
                @if($product->mrp_paise > $product->price_paise)
                    <del>₹{{ number_format($product->mrp_paise / 100, 2) }}</del>
                    <span>{{ round((1 - $product->price_paise / $product->mrp_paise) * 100) }}% off</span>
                @endif
            </div>
            <form class="pdp-cart" method="post" action="{{ route('cart.add') }}" data-cart-form>
                @csrf
                <div data-variant-fallback>
                    <label for="pdp-variant">Size and colour</label>
                    <select id="pdp-variant" name="variant_id" required>
                        <option value="">Choose an option</option>
                        @foreach($product->variants as $variant)
                            <option value="{{ $variant->id }}" @disabled($variant->stock < 1) @selected((string)old('variant_id') === (string)$variant->id)>{{ $variant->size }} / {{ $variant->color }}{{ $variant->stock < 1 ? ' — Sold out' : '' }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="pdp-options" data-variant-controls hidden>
                    <fieldset><legend>Select size</legend><div class="pdp-size-list">
                        @foreach($sizes as $size)<button type="button" class="pdp-size" data-size="{{ $size }}" aria-pressed="false">{{ $size }}</button>@endforeach
                    </div></fieldset>
                    <fieldset><legend>Colour: <span data-color-name>{{ $initialColor }}</span></legend><div class="pdp-color-list">
                        @foreach($colors as $color)<button type="button" class="pdp-color" data-color="{{ $color }}" aria-pressed="false"><span class="pdp-swatch" aria-hidden="true"></span><span>{{ $color }}</span></button>@endforeach
                    </div></fieldset>
                </div>
                <label for="pdp-quantity">Quantity</label>
                <div class="pdp-quantity"><button type="button" data-quantity-minus aria-label="Decrease quantity">−</button><input id="pdp-quantity" type="number" name="quantity" min="1" max="10" value="{{ old('quantity', 1) }}" required><button type="button" data-quantity-plus aria-label="Increase quantity">+</button></div>
                <p class="pdp-stock" data-stock-status role="status"></p>
                <button type="submit" class="pdp-add" data-add-cart @disabled($product->variants->where('stock', '>', 0)->isEmpty())>{{ $product->variants->where('stock', '>', 0)->isEmpty() ? 'Sold out' : 'Add to Cart' }}</button>
                <button type="submit" class="pdp-add pdp-buy" formaction="{{ route('buy-now') }}" data-buy-now @disabled($product->variants->where('stock', '>', 0)->isEmpty())>Buy Now</button>
            </form>
            <form class="delivery-check pdp-delivery" data-url="{{ route('delivery.check') }}">
                <label for="pdp-pincode">Check delivery at your pincode</label>
                <div><input id="pdp-pincode" name="pincode" inputmode="numeric" pattern="[0-9]{6}" maxlength="6" placeholder="6-digit pincode" required><button type="submit">Check</button></div>
                <span role="status"></span>
            </form>
        </div>
    </div>
    <details class="pdp-section" open><summary>Product Details</summary><div class="pdp-section-body">
        @if($product->description)<p class="pdp-description">{{ $product->description }}</p>@endif
        <dl class="pdp-specs">
            @if($product->product_code)<div><dt>Product code</dt><dd>{{ $product->product_code }}</dd></div>@endif
            @if($product->article_code)<div><dt>Article</dt><dd>{{ $product->article_code }}</dd></div>@endif
            @if($product->pattern)<div><dt>Fit</dt><dd>{{ $product->pattern }}</dd></div>@endif
        </dl>
    </div></details>
    <details class="pdp-section" open><summary>Customer Reviews</summary><div class="pdp-section-body">
        @forelse($product->approvedReviews as $review)
            <article class="pdp-review"><strong>{{ $review->rating }}/5 stars</strong><p>{{ $review->body }}</p></article>
        @empty
            <p class="pdp-review-empty">No reviews yet.</p>
        @endforelse
        @auth
            <form class="pdp-review-form" method="post" action="{{ route('reviews.store', $product) }}">
                @csrf
                <h3>Write a Review</h3>
                <label for="pdp-rating">Rating</label><select id="pdp-rating" name="rating" required>@for($i=5;$i>=1;$i--)<option value="{{ $i }}">{{ $i }} stars</option>@endfor</select>
                <label for="pdp-review">Review</label><textarea id="pdp-review" name="body" maxlength="2000" required placeholder="Share your thoughts…">{{ old('body') }}</textarea>
                <button type="submit">Submit Review</button><small>For delivered orders</small>
            </form>
        @else
            <p><a href="{{ route('login') }}">Sign in</a> to review a delivered order.</p>
        @endauth
    </div></details>
</div>
@php
    $schema = ['@context' => 'https://schema.org', '@type' => 'Product', 'name' => $product->title,
        'description' => strip_tags($product->description ?: $product->title),
        'url' => route('products.show', $product->slug), 'sku' => $product->product_code ?: (string) $product->id,
        'offers' => ['@type' => 'Offer', 'priceCurrency' => 'INR', 'price' => number_format($product->price_paise / 100, 2, '.', ''),
            'availability' => $product->variants->sum('stock') > 0 ? 'https://schema.org/InStock' : 'https://schema.org/OutOfStock',
            'url' => route('products.show', $product->slug)]];
    if ($product->displayImage()) $schema['image'] = [$product->displayImage()];
    if ($product->approvedReviews->isNotEmpty()) $schema['aggregateRating'] = ['@type' => 'AggregateRating',
        'ratingValue' => round($product->approvedReviews->avg('rating'), 1), 'reviewCount' => $product->approvedReviews->count()];
@endphp
<script type="application/ld+json">{!! json_encode($schema, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_SLASHES) !!}</script>
<script src="{{ asset('js/product-variants.js') }}?v=2" defer></script>
<script src="{{ asset('js/product-detail.js') }}?v=3" defer></script>
<script src="{{ asset('js/delivery.js') }}" defer></script>
@endsection
