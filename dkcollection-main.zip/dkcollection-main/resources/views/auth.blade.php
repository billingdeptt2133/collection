@extends('layout')
@section('title', 'Account | DK Fashion Hub')
@section('content')
@if(session('url.intended'))<p class="muted">Log in or create an account to continue. Your shopping bag will stay with you.</p>@endif
<h1 style="color:var(--ink);font-size:48px">Your account</h1><div class="product-detail"><section><h2>Log in</h2><form class="form" method="post" action="{{ route('login.submit') }}">@csrf<label>Email<input type="email" name="email" value="{{ old('email') }}" required></label><label>Password<input type="password" name="password" required></label><button class="primary">Log in</button><a href="{{ route('password.request') }}">Forgot password?</a></form></section><section><h2>Create account</h2><form class="form" method="post" action="{{ route('register') }}">@csrf<label>Name<input name="name" maxlength="100" required></label><label>Email<input type="email" name="email" required></label><label>Password (12+ characters)<input type="password" name="password" minlength="12" required></label><label>Confirm password<input type="password" name="password_confirmation" required></label><button class="primary">Register</button></form></section></div>
@endsection

