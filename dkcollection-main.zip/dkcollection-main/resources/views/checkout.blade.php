@extends('checkout-layout')
@section('title', 'Checkout')
@section('content')
@php
    $subtotal = $lines->sum(fn ($line) => $line->variant->product->price_paise * $line->quantity);
    $itemCount = $lines->sum('quantity');
    $states = ['Andaman and Nicobar Islands', 'Andhra Pradesh', 'Arunachal Pradesh', 'Assam', 'Bihar', 'Chandigarh', 'Chhattisgarh', 'Dadra and Nagar Haveli and Daman and Diu', 'Delhi', 'Goa', 'Gujarat', 'Haryana', 'Himachal Pradesh', 'Jammu and Kashmir', 'Jharkhand', 'Karnataka', 'Kerala', 'Ladakh', 'Lakshadweep', 'Madhya Pradesh', 'Maharashtra', 'Manipur', 'Meghalaya', 'Mizoram', 'Nagaland', 'Odisha', 'Puducherry', 'Punjab', 'Rajasthan', 'Sikkim', 'Tamil Nadu', 'Telangana', 'Tripura', 'Uttar Pradesh', 'Uttarakhand', 'West Bengal'];
@endphp
<h1>Checkout</h1>
@if(! $store->checkout_enabled)
    <p class="checkout-errors" role="status">Checkout is temporarily unavailable. Please try again later.</p><a href="{{ route('cart') }}">Return to your bag</a>
@else
    <div class="checkout-identity" data-account-identity @guest hidden @endguest><span aria-hidden="true">✓</span><div><strong data-account-name>Signed in as {{ auth()->user()?->name }}</strong><small data-account-email>{{ auth()->user()?->email }}</small></div></div>
    @guest
        <p class="checkout-account-prompt" data-account-prompt>Already have an account? <button type="submit" form="checkout-details-form" formaction="{{ route('checkout.login') }}" formnovalidate data-open-login>Log in</button></p>
    @endguest
    <div class="checkout-grid" data-checkout-details data-account-url="{{ route('checkout.account') }}" data-quote-url="{{ route('checkout.quote') }}">
        <div class="checkout-form">
        <p class="checkout-errors" data-account-status role="alert" hidden tabindex="-1"></p>
        @guest
        <form data-login-form hidden>
            @csrf<input type="hidden" name="checkout_token" value="{{ session('checkout_token') }}"><input type="hidden" name="mode" value="login">
            <section><h2>Log in</h2><label for="checkout-login-email">Email address</label><input id="checkout-login-email" name="email" type="email" autocomplete="username" maxlength="255" required>
            <label for="checkout-login-password">Password</label><div class="checkout-password"><input id="checkout-login-password" name="password" type="password" autocomplete="current-password" maxlength="255" required><button type="button" data-password-toggle aria-controls="checkout-login-password" aria-pressed="false">Show</button></div>
            <button class="checkout-primary" type="submit">Log in</button><p>New customer? <button type="button" data-open-register>Create account</button></p></section>
        </form>
        @endguest
        <form id="checkout-details-form" class="checkout-form" method="post" action="{{ route('checkout.details') }}">
            @csrf<input type="hidden" name="checkout_token" value="{{ session('checkout_token') }}">
            <section data-contact-section><h2 data-contact-heading>{{ auth()->check() ? 'Contact details' : 'Contact & account' }}</h2>
                <label for="checkout-name">Full name</label><input id="checkout-name" name="name" autocomplete="name" maxlength="100" value="{{ old('name', $draft['name'] ?? auth()->user()?->name) }}" placeholder="Enter your full name" required>
                @guest
                    <div data-registration-field><label for="checkout-email">Email address</label><input id="checkout-email" name="email" type="email" autocomplete="email" maxlength="255" value="{{ old('email', $draft['email'] ?? '') }}" placeholder="Enter your email address" required></div>
                @endguest
                <label for="checkout-phone">Mobile number</label><input id="checkout-phone" name="phone" type="tel" autocomplete="tel" maxlength="20" value="{{ old('phone', $draft['phone'] ?? '') }}" placeholder="Enter your mobile number" required>
                @guest
                    <div data-registration-field><label for="checkout-password">Create password</label><div class="checkout-password"><input id="checkout-password" name="password" type="password" autocomplete="new-password" minlength="12" maxlength="255" aria-describedby="checkout-password-help" placeholder="Create a password" required><button type="button" data-password-toggle aria-controls="checkout-password" aria-pressed="false" aria-label="Show password">Show</button></div><small id="checkout-password-help">At least 12 characters. Your account is created when you continue.</small></div><button type="button" class="checkout-primary" data-create-account hidden>Create account</button>
                @endguest
            </section>
            <section><h2>Shipping address</h2>
                <label for="checkout-address">Address line 1</label><input id="checkout-address" name="address" autocomplete="address-line1" maxlength="350" value="{{ old('address', $draft['address'] ?? '') }}" placeholder="House no., building, street, area" required>
                <label for="checkout-address2">Address line 2 <span>(optional)</span></label><input id="checkout-address2" name="address2" autocomplete="address-line2" maxlength="140" value="{{ old('address2', $draft['address2'] ?? '') }}" placeholder="Apartment, landmark, society">
                <div class="checkout-field-pair"><div><label for="checkout-city">City</label><input id="checkout-city" name="city" autocomplete="address-level2" maxlength="100" value="{{ old('city', $draft['city'] ?? '') }}" placeholder="Enter city" required></div><div><label for="checkout-state">State</label><select id="checkout-state" name="state" autocomplete="address-level1" required><option value="">Select state</option>@foreach($states as $state)<option value="{{ $state }}" @selected(old('state', $draft['state'] ?? '') === $state)>{{ $state }}</option>@endforeach</select></div></div>
                <label for="checkout-pincode">Pincode</label><div class="checkout-pincode"><input id="checkout-pincode" name="pincode" autocomplete="postal-code" inputmode="numeric" pattern="[0-9]{6}" maxlength="6" value="{{ old('pincode', $draft['pincode'] ?? '') }}" placeholder="Enter 6-digit pincode" required><button type="button" data-check-delivery>Check delivery</button></div><p class="checkout-help" data-delivery-status role="status">Enter your pincode to calculate delivery.</p>
            </section>
            <button class="checkout-primary" type="submit">Continue to Payment <span aria-hidden="true">→</span></button><p class="checkout-help checkout-submit-note">You will review the final amount before placing your order.</p>
        </form>
        </div>
        <aside class="checkout-summary"><details open><summary>Order summary <span>{{ $itemCount }} {{ $itemCount === 1 ? 'item' : 'items' }} · ₹{{ number_format($subtotal / 100, 2) }}</span></summary><div class="checkout-summary-body"><a class="checkout-edit-bag" href="{{ route('cart') }}">Edit bag</a>@include('partials.checkout-items')<dl class="checkout-totals"><div><dt>Subtotal</dt><dd>₹{{ number_format($subtotal / 100, 2) }}</dd></div><div><dt>Delivery</dt><dd data-shipping-preview>Enter pincode</dd></div></dl><div class="checkout-grand-total"><span>Bag subtotal</span><strong>₹{{ number_format($subtotal / 100, 2) }}</strong></div><p class="checkout-help">Final total will include delivery, any coupon discount and payment fees.</p></div></details></aside>
    </div>
@endif
@endsection
