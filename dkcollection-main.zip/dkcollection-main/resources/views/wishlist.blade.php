@extends('layout')
@section('title', 'Wishlist | DK Fashion Hub')
@section('content')
<h1 style="color:var(--ink);font-size:48px">Wishlist</h1><div class="product-grid">@forelse($products as $product)<a class="product-card" href="{{ route('products.show', $product->slug) }}"><div class="product-image">@if($product->displayImage())<img src="{{ $product->displayImage() }}" alt="{{ $product->title }}">@else<span>DK</span>@endif</div><h3>{{ $product->title }}</h3><p>₹{{ number_format($product->price_paise / 100, 2) }}</p></a>@empty<p>No saved items yet.</p>@endforelse</div>{{ $products->links() }}
@endsection
