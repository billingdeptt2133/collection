@extends('layout')
@section('title', 'Orders | DK Fashion Hub')
@section('content')
<h1 style="color:var(--ink);font-size:48px">My orders</h1>@forelse($orders as $order)<div class="card"><a href="{{ route('orders.show', $order) }}">Order #{{ $order->id }}</a> · {{ $order->created_at->format('d M Y') }} · {{ ucfirst($order->status) }} · ₹{{ number_format($order->total_paise / 100, 2) }}</div>@empty<p>No orders yet.</p>@endforelse{{ $orders->links() }}
@endsection
