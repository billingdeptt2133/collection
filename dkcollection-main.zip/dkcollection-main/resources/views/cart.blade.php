@extends('layout')
@section('title', 'Shopping Bag | DK Fashion Hub')
@section('robots', 'noindex,follow')
@push('styles')
<link rel="stylesheet" href="{{ asset('css/cart.css') }}?v=1">
@endpush
@section('content')
@php
    $subtotal = $lines->sum(fn ($line) => $line->variant->product->price_paise * $line->quantity);
    $itemCount = $lines->sum('quantity');
@endphp
<div class="bag">
    <header class="bag-heading"><h1>Your Shopping Bag</h1><span>{{ $itemCount }} {{ $itemCount === 1 ? 'item' : 'items' }}</span></header>
    @if($lines->isEmpty())
        <div class="bag-empty"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 7h14l1 14H4L5 7Zm3 0V5a4 4 0 0 1 8 0v2"/></svg><h2>Your bag is waiting</h2><p>Find your next favourite fit.</p><a class="bag-checkout" href="{{ route('home') }}#new-arrivals">Explore products</a></div>
    @else
        <div class="bag-mobile-summary"><div><span>Subtotal ({{ $itemCount }} {{ $itemCount === 1 ? 'item' : 'items' }})</span><strong>₹{{ number_format($subtotal / 100, 2) }}</strong></div><a class="bag-checkout" href="{{ route('checkout') }}">Proceed to Checkout</a></div>
        <div class="bag-layout">
            <section class="bag-items" aria-label="Shopping bag products">
                @foreach($lines as $line)
                    @php
                        $variant = $line->variant;
                        $product = $variant->product;
                        $photo = $product->images->where('color', $variant->color)->first();
                        $singleColor = $product->variants->pluck('color')->unique()->count() === 1;
                        $image = $photo ? asset('storage/'.$photo->path) : ($singleColor ? $product->displayImage() : null);
                        $limit = min(10, $variant->stock);
                    @endphp
                    <article class="bag-item">
                        <a class="bag-photo" href="{{ route('products.show', $product->slug) }}" aria-label="View {{ $product->title }}">@if($image)<img src="{{ $image }}" alt="{{ $product->title }} — {{ $variant->color }}" loading="lazy">@else<span>Photo unavailable</span>@endif</a>
                        <div class="bag-item-info">
                            <a class="bag-product-name" href="{{ route('products.show', $product->slug) }}">{{ $product->title }}</a>
                            <p class="bag-item-price">₹{{ number_format($product->price_paise / 100, 2) }} <span>each</span></p>
                            <dl><div><dt>Colour:</dt><dd>{{ $variant->color }}</dd></div><div><dt>Size:</dt><dd>{{ $variant->size }}</dd></div>@if($variant->shade_code)<div><dt>Shade:</dt><dd>{{ $variant->shade_code }}</dd></div>@endif</dl>
                            <form class="bag-quantity-form" method="post" action="{{ route('cart.update', $variant) }}" data-bag-quantity>
                                @csrf @method('PATCH')
                                <label class="bag-sr-only" for="bag-qty-{{ $variant->id }}">Quantity for {{ $product->title }} {{ $variant->size }} {{ $variant->color }}</label>
                                <div class="bag-quantity"><button type="button" data-qty-step="-1" aria-label="Decrease quantity" @disabled($line->quantity <= 1)>−</button><input id="bag-qty-{{ $variant->id }}" name="quantity" type="number" min="1" max="{{ $limit }}" value="{{ $line->quantity }}" required><button type="button" data-qty-step="1" aria-label="Increase quantity" @disabled($line->quantity >= $limit)>+</button></div>
                                <button class="bag-text-button" type="submit">Update</button>
                            </form>
                            <div class="bag-actions">
                                <details class="bag-edit"><summary>Edit</summary><form method="post" action="{{ route('cart.update', $variant) }}">@csrf @method('PATCH')<input type="hidden" name="quantity" value="{{ $line->quantity }}"><label for="bag-variant-{{ $variant->id }}">Size and colour</label><select id="bag-variant-{{ $variant->id }}" name="variant_id" required>@foreach($product->variants as $option)<option value="{{ $option->id }}" @selected($option->id === $variant->id) @disabled($option->stock < 1)>{{ $option->size }} / {{ $option->color }}{{ $option->stock < 1 ? ' — Sold out' : '' }}</option>@endforeach</select><button class="bag-text-button" type="submit">Save</button></form></details>
                                <form method="post" action="{{ route('cart.update', $variant) }}">@csrf @method('PATCH')<input type="hidden" name="quantity" value="0"><button class="bag-text-button" type="submit" aria-label="Remove {{ $product->title }} {{ $variant->size }} {{ $variant->color }}">Remove</button></form>
                            </div>
                            <p class="bag-line-total">Item total <strong>₹{{ number_format($product->price_paise * $line->quantity / 100, 2) }}</strong></p>
                        </div>
                    </article>
                @endforeach
                <p class="bag-stock-note"><span aria-hidden="true">ⓘ</span> Items in your bag are not reserved. Availability is checked when you order.</p>
                <a class="bag-continue" href="{{ route('home') }}#new-arrivals">← Continue Shopping</a>
            </section>
            <aside class="bag-overview" aria-label="Order overview"><h2>Order overview</h2><dl><div><dt>Subtotal</dt><dd>₹{{ number_format($subtotal / 100, 2) }}</dd></div><div><dt>Delivery</dt><dd>Calculated at checkout</dd></div></dl><div class="bag-total"><span>Bag total</span><strong>₹{{ number_format($subtotal / 100, 2) }}</strong></div><p class="bag-fee-note">Delivery charges, payment fees and any coupon discount are calculated at checkout.</p><a class="bag-checkout" href="{{ route('checkout') }}">Proceed to Checkout</a>@guest<p class="bag-login-note">Log in or create an account at checkout. Your bag will be preserved.</p>@endguest<a class="bag-summary-continue" href="{{ route('home') }}#new-arrivals">Continue Shopping</a></aside>
        </div>
    @endif
    @if($recommendations->isNotEmpty())
        <section class="bag-recommendations"><h2>You may also like</h2><div class="bag-recommendation-grid">@foreach($recommendations as $recommended)<article><div class="bag-recommendation-photo"><a href="{{ route('products.show', $recommended->slug) }}">@if($recommended->displayImage())<img src="{{ $recommended->displayImage() }}" alt="{{ $recommended->title }}" loading="lazy">@else<span>DK</span>@endif</a>@auth<form class="bag-heart" method="post" action="{{ route('wishlist.toggle', $recommended) }}">@csrf<button type="submit" aria-label="Toggle wishlist for {{ $recommended->title }}">♡</button></form>@else<a class="bag-heart" href="{{ route('login') }}" aria-label="Sign in to save {{ $recommended->title }}">♡</a>@endauth</div><h3><a href="{{ route('products.show', $recommended->slug) }}">{{ $recommended->title }}</a></h3><p>₹{{ number_format($recommended->price_paise / 100, 2) }}</p><a class="bag-view-product" href="{{ route('products.show', $recommended->slug) }}">View product</a></article>@endforeach</div></section>
    @endif
</div>
<script src="{{ asset('js/cart.js') }}?v=1" defer></script>
@endsection
