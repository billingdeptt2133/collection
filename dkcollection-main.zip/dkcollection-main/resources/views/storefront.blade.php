<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#111827">
    <title>{{ $store->name ?? 'Jansen Jeans' }} | Modern Style, Everyday</title>
    <meta name="description" content="Explore everyday denim and find your perfect fit at {{ $store->name ?? 'Jansen Jeans' }}.">
    <meta name="robots" content="{{ request()->query() || ! $store->checkout_enabled ? 'noindex,follow' : 'index,follow' }}">
    <link rel="canonical" href="{{ route('home') }}">
    <meta property="og:type" content="website">
    <meta property="og:title" content="{{ $store->name ?? 'Jansen Jeans' }}">
    <meta property="og:description" content="Explore everyday denim and find your perfect fit.">
    <meta property="og:url" content="{{ route('home') }}">
    <link rel="stylesheet" href="{{ asset('css/home-editorial.css') }}?v=3">
    <script src="{{ asset('js/home-editorial.js') }}?v=3" defer></script>
</head>
<body class="home-page editorial-home">
@php
    $design = $homepage['design'] ?? [];
@endphp
<a class="skip-link" href="#main-content">Skip to content</a>
<div class="announcement" aria-label="Store announcement">
    <div class="announcement-track">
        <span>{{ $store->announcement ?: 'TIMELESS FITS. MODERN STYLE. · JANSEN JEANS' }}</span>
    </div>
</div>
<header class="editorial-header">
    <div class="header-shell">
        <details class="menu-drawer" data-menu-drawer>
            <summary class="icon-button" aria-label="Open navigation">@include('partials.home-ui-icon', ['icon' => 'menu'])</summary>
            <div class="drawer-panel" id="home-navigation">
                <div class="drawer-heading"><strong>{{ $store->name ?? 'Jansen Jeans' }}</strong><button class="icon-button" type="button" data-menu-close aria-label="Close navigation">@include('partials.home-ui-icon', ['icon' => 'close'])</button></div>
                <nav aria-label="Mobile navigation">
                    <a href="{{ route('home') }}">Home</a><a href="{{ route('home') }}#new-arrivals">New Arrivals</a><a href="{{ route('home') }}#collections">Shop by Fit</a><a href="{{ route('orders') }}">Track Your Order</a><a href="{{ route('wishlist') }}">Wishlist</a><a href="{{ auth()->check() ? route('orders') : route('login') }}">Account</a>
                    @if(filled($homepage['footer']['size-guide'] ?? null))<a href="{{ route('store.page', 'size-guide') }}">Fit &amp; Size Guide</a>@endif
                    @auth @if(auth()->user()->is_admin)<a href="{{ route('admin.dashboard') }}">Admin</a>@endif @endauth
                </nav>
                <div class="drawer-contact"><strong>Customer Support</strong>@if($store->support_email)<a href="mailto:{{ $store->support_email }}">{{ $store->support_email }}</a>@endif @if($store->support_phone)<a href="tel:{{ preg_replace('/[^0-9+]/', '', $store->support_phone) }}">{{ $store->support_phone }}</a>@endif</div>
            </div>
            <button class="drawer-backdrop" type="button" data-menu-close aria-label="Close navigation"></button>
        </details>
        <a class="editorial-brand" href="{{ route('home') }}" aria-label="{{ $store->name ?? 'Jansen Jeans' }} home">
            @if($store->logo_path)<img src="{{ asset('storage/'.$store->logo_path) }}" alt="{{ $store->name ?? 'Jansen Jeans' }}" width="150" height="50">
            @else<span>{{ preg_replace('/\s+jeans$/i', '', $store->name ?? 'Jansen Jeans') }}</span><small>JEANS</small>@endif
        </a>
        <nav class="desktop-navigation" aria-label="Main navigation"><a href="{{ route('home') }}#new-arrivals">New Arrivals</a><a href="{{ route('home') }}#collections">Shop by Fit</a><a href="{{ auth()->check() ? route('orders') : route('login') }}">Account</a>@auth @if(auth()->user()->is_admin)<a href="{{ route('admin.dashboard') }}">Admin</a>@endif @endauth</nav>
        <div class="header-actions">
            <details class="search-panel" data-search-panel>
                <summary class="icon-button" aria-label="Search products">@include('partials.home-ui-icon', ['icon' => 'search'])</summary>
                <form method="get" action="{{ route('home') }}#new-arrivals" role="search"><label for="home-search">Search denim</label><div><input id="home-search" type="search" name="q" maxlength="80" value="{{ request('q') }}" placeholder="Search products…"><button type="submit">Search</button></div></form>
            </details>
            <a class="icon-button" href="{{ route('wishlist') }}" aria-label="Wishlist">@include('partials.home-ui-icon', ['icon' => 'heart'])@if(count($wishlistIds))<span class="wishlist-count">{{ count($wishlistIds) }}</span>@endif</a>
            <a class="icon-button cart-link" href="{{ route('cart') }}" aria-label="Shopping bag, {{ $cartCount }} items">@include('partials.home-ui-icon', ['icon' => 'bag'])<span class="cart-count">{{ $cartCount }}</span></a>
        </div>
    </div>
</header>
<main id="main-content">
    @if(session('message'))<p class="home-message" role="status">{{ session('message') }}</p>@endif
    @include('partials.home-image-banner', ['slot' => 'main', 'banner' => $imageBanners['main']])
    <section class="trust-strip" aria-label="Shopping benefits">
        @foreach(['shipping' => ['truck', $store->free_shipping_above_paise !== null ? 'FREE SHIPPING' : 'DELIVERY', $store->free_shipping_above_paise ? 'On ₹'.number_format($store->free_shipping_above_paise / 100) . '+' : 'See delivery policy'], 'returns' => ['returns', 'EASY RETURNS', 'See return policy'], 'quality' => ['gem', 'PREMIUM QUALITY', 'Everyday denim'], 'payments' => ['card', 'SECURE PAYMENTS', 'Checkout securely']] as $key => [$icon, $title, $caption])
            <div>@include('partials.home-ui-icon', ['icon' => $icon])<strong>{{ $design['trust_'.$key.'_title'] ?? $title }}</strong><small>{{ $design['trust_'.$key.'_caption'] ?? $caption }}</small></div>
        @endforeach
    </section>
    <section class="fit-section page-shell" id="collections" aria-labelledby="collections-title">
        <div class="editorial-section-heading"><h2 id="collections-title">{{ $design['fit_heading'] ?? 'SHOP BY FIT' }}</h2><p>{{ $design['fit_caption'] ?? 'FIND YOUR PERFECT DENIM' }}</p></div>
        <nav class="fit-grid" aria-label="Shop denim fits">@foreach($heroCategories as $category)<a href="{{ route('home', ['category' => $category->slug]) }}#new-arrivals" @if(request('category') === $category->slug)aria-current="page"@endif><span>{{ $category->name }}</span>@include('partials.home-ui-icon', ['icon' => 'chevron'])</a>@endforeach</nav>
    </section>
    <section class="catalog page-shell" id="new-arrivals" aria-labelledby="catalog-title">
        <div class="editorial-section-heading"><h2 id="catalog-title">{{ $design['catalog_heading'] ?? 'BEST SELLERS & NEW ARRIVALS' }}</h2><p>{{ $design['catalog_caption'] ?? 'THE LATEST STYLES FOR EVERYDAY LIVING' }}</p></div>
        @if(request('q') || request('category'))<div class="filter-status"><span>{{ request('q') ? 'Results for “'.request('q').'”' : ($categories->firstWhere('slug', request('category'))?->name ?? 'Collection') }}</span><a href="{{ route('home') }}#new-arrivals">Clear filters</a></div>@endif
        <div class="product-grid">
            @forelse($products as $product)
                @foreach(\App\Support\ProductPresentation::cards($product) as $card)@include('partials.home-reference-product-card')@endforeach
            @empty<div class="empty-state">No products found. Try another search or category.</div>@endforelse
        </div>
        @if($products->hasMorePages())<button class="show-more" data-next="{{ $products->nextPageUrl() }}" aria-live="polite" type="button">Show more products</button>@endif
    </section>
    @include('partials.home-image-banner', ['slot' => 'promotional', 'banner' => $imageBanners['promotional']])
    @if($videoReviews->isNotEmpty() || $reviews->isNotEmpty())
    <section class="reviews-section page-shell" id="reviews" aria-labelledby="reviews-title">
        <div class="editorial-section-heading"><h2 id="reviews-title">{{ $design['reviews_heading'] ?? 'REAL PEOPLE. REAL FITS.' }}</h2></div>
        @if($videoReviews->isNotEmpty())
            <div class="home-video-track">@foreach($videoReviews as $video)<article class="home-video-card"><iframe src="https://www.youtube-nocookie.com/embed/{{ $video['id'] }}" title="{{ $video['name'] }} — review" loading="lazy" referrerpolicy="strict-origin-when-cross-origin" sandbox="allow-scripts allow-same-origin allow-presentation" allow="accelerometer; encrypted-media; picture-in-picture; web-share" allowfullscreen></iframe><strong>{{ $video['name'] }}</strong></article>@endforeach</div>
        @else
            <div class="review-track">@foreach($reviews as $review)<blockquote><div class="review-stars" aria-label="{{ $review->rating }} out of 5 stars">{{ str_repeat('★', max(0, min(5, (int) $review->rating))) }}</div><p>“{{ $review->body }}”</p><cite>— {{ $review->user?->name ?? 'Customer' }}</cite></blockquote>@endforeach</div>
        @endif
    </section>
    @endif
    @include('partials.home-partners')
</main>
@include('partials.home-reference-footer')
</body>
</html>
