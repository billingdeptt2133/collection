@if($paginator->hasPages())
<nav class="inline" role="navigation" aria-label="Pagination">
@if($paginator->onFirstPage())<span class="muted">← Previous</span>@else<a class="button secondary" href="{{ $paginator->previousPageUrl() }}" rel="prev">← Previous</a>@endif
<span class="muted">Page {{ $paginator->currentPage() }} of {{ $paginator->lastPage() }} · {{ $paginator->total() }} records</span>
@if($paginator->hasMorePages())<a class="button secondary" href="{{ $paginator->nextPageUrl() }}" rel="next">Next →</a>@else<span class="muted">Next →</span>@endif
</nav>
@endif
