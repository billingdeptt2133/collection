@php
    $defaultSizes = ['28','30','32','34','36','38','40'];
    $colourRows = old('colours');
    if (!is_array($colourRows)) {
        $colourRows = $product->variants->groupBy('color')->map(function($variants,$name) use($defaultSizes) {
            $sizes = collect($defaultSizes)->merge($variants->pluck('size'))->unique()->values();
            return ['name'=>$name,'sizes'=>$sizes->map(function($size) use($variants) {
                $v=$variants->first(fn($v)=>(string)$v->size===(string)$size);
                return ['size'=>$size,'stock'=>$v?->stock ?? 0,'shade_code'=>$v?->shade_code,'barcode'=>$v?->barcode];
            })->all()];
        })->values()->all();
        if (!$colourRows) $colourRows = [['name'=>'','sizes'=>array_map(fn($size)=>['size'=>$size,'stock'=>0],$defaultSizes)]];
    }
@endphp
<div class="product-colours" data-colour-editor><h2>Colours, photos & stock</h2><p>0 = sold out for that size and colour. Upload up to 5 photos per colour at a time; 30 per product. First photo is the colour’s main image.</p>
<div data-colour-panels>
@foreach($colourRows as $index=>$colour)
<section class="colour-panel" data-colour-panel><label>Colour name<input name="colours[{{ $index }}][name]" value="{{ $colour['name'] }}" data-colour-name maxlength="50" pattern="[^,]+" required>@error('colours.'.$index.'.name')<small class="field-error">{{ $message }}</small>@enderror</label>
@php($photos=$product->images->where('color',$colour['name']))
<div class="colour-photos" data-saved-photos data-photo-count="{{ $photos->count() }}">@foreach($photos as $photo)<figure><img src="{{ asset('storage/'.$photo->path) }}" alt="{{ $colour['name'] }} photo" width="64" height="80" loading="lazy">@if($loop->first)<figcaption>Main</figcaption>@endif</figure>@endforeach</div>
<label>+ Upload colour photos<input type="file" name="colours[{{ $index }}][photos][]" data-colour-upload multiple accept="image/jpeg,image/png,image/webp"><small>Up to 5 photos · 4 MB each. Select files again after a validation error.</small>@foreach($errors->get('colours.'.$index.'.photos.*') as $messages)@foreach($messages as $message)<small class="field-error">{{ $message }}</small>@endforeach @endforeach</label>
<div class="colour-photos" data-upload-previews></div>
<div class="size-stock-grid">
@foreach($colour['sizes'] as $sizeIndex=>$row)
<div @class(['size-stock-cell','is-zero'=>(int)$row['stock']===0])><label>Size {{ $row['size'] }}<input type="hidden" name="colours[{{ $index }}][sizes][{{ $sizeIndex }}][size]" value="{{ $row['size'] }}"><input type="number" name="colours[{{ $index }}][sizes][{{ $sizeIndex }}][stock]" value="{{ $row['stock'] }}" min="0" max="100000" step="1" required>@error('colours.'.$index.'.sizes.'.$sizeIndex.'.stock')<small class="field-error">{{ $message }}</small>@enderror</label><input type="hidden" name="colours[{{ $index }}][sizes][{{ $sizeIndex }}][shade_code]" value="{{ $row['shade_code'] ?? '' }}"><input type="hidden" name="colours[{{ $index }}][sizes][{{ $sizeIndex }}][barcode]" value="{{ $row['barcode'] ?? '' }}"></div>
@endforeach
</div><small>0 = Out of stock</small><br><button type="button" data-add-size>+ Add extra size</button>
@if($photos->isEmpty())<p class="muted">No matching colour photos saved yet.</p>@endif
</section>
@endforeach
</div><button type="button" data-add-colour>+ Add colour</button><p data-colour-message role="status"></p></div>
