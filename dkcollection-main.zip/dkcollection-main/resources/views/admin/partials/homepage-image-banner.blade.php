<form class="hp-card hp-form" method="post" enctype="multipart/form-data" action="{{ route('admin.homepage.banners.save', $slot) }}">
    @csrf
    <h2>{{ $label }}</h2>
    <div class="hp-pair">
        @foreach(['desktop_image' => 'Desktop image', 'mobile_image' => 'Mobile image'] as $field => $fieldLabel)
            <label>{{ $fieldLabel }}
                @if($banner[$field])<img class="hp-preview" src="{{ asset('storage/'.$banner[$field]) }}" alt="{{ $label }} {{ strtolower($fieldLabel) }} preview">@endif
                <input type="file" name="{{ $slot }}[{{ $field }}]" accept="image/jpeg,image/png,image/webp" @required($field === 'desktop_image' && !$banner[$field])>
                @error($slot.'.'.$field)<span role="alert">{{ $message }}</span>@enderror
            </label>
        @endforeach
    </div>
    <small>JPG, PNG or WebP · up to 4 MB and 4096 × 4096 px. Leave uploads empty to keep the current images. Without a mobile image, desktop is used.</small>
    <label>Destination URL<input type="text" inputmode="url" name="{{ $slot }}[destination_url]" maxlength="2048" value="{{ old($slot.'.destination_url', $banner['destination_url']) }}" placeholder="/products/your-product or {{ url('/products/your-product') }}" required></label>
    @error($slot.'.destination_url')<span role="alert">{{ $message }}</span>@enderror
    @error($slot)<span role="alert">{{ $message }}</span>@enderror
    <button class="hp-primary" type="submit">Save {{ strtolower($label) }}</button>
</form>
