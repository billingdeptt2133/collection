@extends('admin.layout')
@section('title','Activity log')
@section('content')
<h1>Admin activity</h1><p class="muted">Successful admin actions since this update. Passwords, codes, payment secrets and customer form values are excluded.</p><section class="table-wrap"><table><thead><tr><th>Date</th><th>Administrator</th><th>Action</th><th>Record IDs</th></tr></thead><tbody>@forelse($audits as $a)<tr><td>{{ $a->created_at }}</td><td>{{ $a->name ?? 'Removed account' }}</td><td>{{ $a->action }}</td><td>{{ $a->context }}</td></tr>@empty<tr><td colspan="4">No recorded actions yet.</td></tr>@endforelse</tbody></table>{{ $audits->links('admin.partials.pagination') }}</section>
@endsection
