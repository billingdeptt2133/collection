@extends('admin.layout')
@section('title','Product editor')
@section('admin-head')<link rel="stylesheet" href="{{ asset('css/admin-product.css') }}?v=2">@endsection
@section('content')
<div class="page-head"><div><h1>{{ $product->exists ? 'Edit product' : 'Add product' }}</h1><p class="muted">All product details in one place. Each colour gets its own store card.</p></div><a href="{{ route('admin.products') }}">← Products</a></div>
<form class="product-editor" id="product-editor" action="{{ $product->exists ? route('admin.products.update', $product) : route('admin.products.store') }}" method="post" enctype="multipart/form-data" data-product-editor>
@csrf
@if($product->exists)<input type="hidden" name="stock_snapshot" value="{{ old('stock_snapshot', hash('sha256', $product->variants->sortBy('id')->map(fn($v)=>$v->id.':'.$v->stock)->implode('|'))) }}">@endif
<div class="product-editor-main">
<section class="editor-card"><h2>Product details</h2><div class="editor-fields">
<label>Product title <span aria-hidden="true">*</span><input name="title" value="{{ old('title', $product->title) }}" required maxlength="180" placeholder="Baloon Baggy Fit">@error('title')<small class="field-error">{{ $message }}</small>@enderror<small>Enter the shared name. Colour is added automatically on store cards.</small></label>
<label>Category<select name="category_id"><option value="">Choose category</option>@foreach($categories as $category)<option value="{{ $category->id }}" @selected((string)$category->id === (string)old('category_id', $product->category_id))>{{ $category->name }}</option>@endforeach</select>@error('category_id')<small class="field-error">{{ $message }}</small>@enderror</label>
<label>Product code<input name="product_code" value="{{ old('product_code', $product->product_code) }}" maxlength="64" placeholder="DK-104"></label>
<label>Article number<input name="article_code" value="{{ old('article_code', $product->article_code) }}" maxlength="64" placeholder="1336"><small>Same article for every colour.</small></label>
<label>Pattern / fit<input name="pattern" value="{{ old('pattern', $product->pattern) }}" maxlength="64" placeholder="Baggy fit"></label>
<label class="editor-wide">Description<textarea name="description" maxlength="5000" rows="4" placeholder="Fabric, fit, care and product details">{{ old('description', $product->description) }}</textarea>@error('description')<small class="field-error">{{ $message }}</small>@enderror</label>
</div></section>
<section class="editor-card editor-colours">@include('admin.partials.product-colours')</section>
</div>
<aside class="product-editor-aside">
<section class="editor-card"><h2>Pricing & visibility</h2><div class="editor-fields">
<label>Selling price (₹) *<input type="number" name="price_rupees" min="0.01" max="1000000" step="0.01" value="{{ old('price_rupees', $product->exists ? number_format($product->price_paise / 100, 2, '.', '') : '') }}" required placeholder="1499">@error('price_rupees')<small class="field-error">{{ $message }}</small>@enderror @error('price_paise')<small class="field-error">{{ $message }}</small>@enderror</label>
<label>MRP (₹)<input type="number" name="mrp_rupees" min="0.01" step="0.01" value="{{ old('mrp_rupees', $product->mrp_paise === null ? '' : number_format($product->mrp_paise / 100, 2, '.', '')) }}" placeholder="1999">@error('mrp_paise')<small class="field-error">{{ $message }}</small>@enderror</label>
</div><p class="muted">One price for all colours. Currently: {{ $product->is_active ? 'Published' : 'Draft / archived' }}.</p>
<label>Product cover image<input type="file" name="image" accept="image/jpeg,image/png,image/webp" data-cover-upload><small>JPG, PNG or WebP · up to 4 MB. Store colour cards use their matching colour photos.</small>@error('image')<small class="field-error">{{ $message }}</small>@enderror</label>
<div class="cover-preview" data-cover-preview>@if($product->displayImage())<img src="{{ $product->displayImage() }}" alt="Current cover" width="160" height="180">@endif</div>
</section>
<section class="editor-card"><h2>Product readiness</h2><ul class="editor-readiness"><li data-ready-title>Product title</li><li data-ready-price>Selling price</li><li data-ready-colours>Colour names</li><li data-ready-photos>Matching colour photos</li><li data-ready-stock>At least one size in stock</li></ul><small>This checklist is guidance. Zero-stock products can be saved and shown as sold out.</small></section>
<details class="editor-card"><summary>Optional SEO</summary><div class="editor-fields"><label>SEO title<input name="seo_title" value="{{ old('seo_title', $product->seo_title) }}" maxlength="70"></label><label>SEO description<textarea name="seo_description" maxlength="160" rows="3">{{ old('seo_description', $product->seo_description) }}</textarea></label></div></details>
</aside>
<div class="editor-save-bar"><span data-save-status role="status">Ready to edit</span><div><button type="submit" name="is_active" value="0">Save draft</button><button class="primary" type="submit" name="is_active" value="1">{{ $product->is_active ? 'Publish changes' : 'Publish product' }}</button></div></div>
</form>
@if($product->exists)
<details class="editor-card gallery-management"><summary>Manage saved photos · colour mapping & removal</summary><p class="muted">Changes below save separately. Save product changes first. If you rename a colour, map its existing photos to the new name.</p><div class="saved-photo-grid">
@foreach($product->images as $image)
<article><img src="{{ asset('storage/'.$image->path) }}" width="90" height="110" alt="{{ $image->color ?: 'Common' }} product photo" loading="lazy"><form method="post" action="{{ route('admin.images.color', $image) }}">@csrf @method('PATCH')<label>Photo colour<select name="color"><option value="">Common photo</option>@foreach($product->variants->pluck('color')->unique()->values() as $color)<option value="{{ $color }}" @selected($image->color === $color)>{{ $color }}</option>@endforeach</select></label><button type="submit">Save colour</button></form><form method="post" action="{{ route('admin.images.delete', $image) }}">@csrf @method('DELETE')<button type="submit" data-confirm-remove-photo>Remove photo</button></form></article>
@endforeach
</div></details>
<details class="editor-card editor-danger"><summary>Danger zone · Archive or move to Recycle Bin</summary><p>Archive hides the product in the current product list. Recycle Bin keeps its photos, sizes and stock in a separate space, where you can restore it.</p><form method="post" action="{{ route('admin.products.archive', $product) }}">@csrf @method('PATCH')<button type="submit">Archive / hide from store</button></form><form method="post" action="{{ route('admin.products.delete', $product) }}" data-trash-product>@csrf @method('DELETE')<button type="submit">Move to Recycle Bin</button></form><p><a href="{{ route('admin.products.recycle-bin') }}">Open Recycle Bin →</a></p></details>
@endif
<script src="{{ asset('js/admin-product.js') }}?v=3" defer></script>
@endsection
