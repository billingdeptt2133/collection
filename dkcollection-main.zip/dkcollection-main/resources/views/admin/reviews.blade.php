@extends('admin.layout')
@section('title','Reviews')
@section('content')
<section><h1>Customer reviews</h1><form class="toolbar" method="get"><select name="status"><option value="pending">Pending</option><option value="approved" @selected(request('status')==='approved')>Approved</option><option value="rejected" @selected(request('status')==='rejected')>Rejected</option></select><button>Filter</button></form>@foreach($reviews as $review)<div class="card"><strong>{{ $review->rating }}/5</strong><p>{{ $review->body }}</p><small>{{ $review->user?->name }} · Product #{{ $review->product_id }}</small><form method="post" action="{{ route('admin.reviews.approve', $review) }}">@csrf @method('PATCH')<button>Approve</button></form><form method="post" action="{{ route('admin.reviews.reject', $review) }}">@csrf @method('DELETE')<button>Reject</button></form></div>@endforeach{{ $reviews->links('admin.partials.pagination') }}</section>
@endsection
