@extends('admin.layout')
@section('title','Customers')
@section('content')
<h1>Customers</h1><p class="muted">Customer accounts and order history.</p><form class="toolbar" method="get"><input name="q" value="{{ request('q') }}" placeholder="Name or email"><button>Search</button></form><section><table><thead><tr><th>Name</th><th>Email</th><th>Joined</th><th></th></tr></thead><tbody>@forelse($customers as $customer)<tr><td>{{ $customer->name }}</td><td>{{ $customer->email }}</td><td>{{ $customer->created_at->format('d M Y') }}</td><td><a href="{{ route('admin.customers.show',$customer) }}">Profile & orders</a></td></tr>@empty<tr><td colspan="4">No matching customers.</td></tr>@endforelse</tbody></table>{{ $customers->links('admin.partials.pagination') }}</section>
@endsection
