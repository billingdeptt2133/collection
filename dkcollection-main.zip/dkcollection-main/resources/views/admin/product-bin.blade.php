@extends('admin.layout')
@section('title','Product Recycle Bin')
@section('content')
<div class="page-head"><div><h1>Product Recycle Bin</h1><p class="muted">Trashed products are hidden from the store. Photos, colours, sizes and stock are kept for restoration.</p></div><a href="{{ route('admin.products') }}">← Products</a></div>
<p>Restore returns a product as a <strong>draft</strong>. Publish it from the editor after checking its details. Products linked to orders cannot be permanently deleted. Nothing is deleted automatically.</p>
<form class="toolbar" method="get"><input name="q" value="{{ request('q') }}" maxlength="100" placeholder="Product name or article"><button type="submit">Search</button></form>
<section class="table-wrap"><table><thead><tr><th>Product</th><th>Article / variants</th><th>Trashed on</th><th>Actions</th></tr></thead><tbody>
@forelse($products as $product)
<tr><td><div class="inline">@if($product->displayImage())<img class="product-thumb" src="{{ $product->displayImage() }}" alt="{{ $product->title }}" loading="lazy">@endif<strong>{{ $product->title }}</strong></div></td><td>{{ $product->article_code ?: '—' }}<br>{{ $product->variants_count }} variants</td><td>{{ $product->deleted_at->format('d M Y, h:i A') }}</td><td>
<form method="post" action="{{ route('admin.products.restore',$product) }}">@csrf @method('PATCH')<button type="submit">Restore as draft</button></form>
@if(in_array($product->id,$orderedIds))<p class="muted">Order-linked · permanent delete protected</p>
@else<details><summary>Permanently delete</summary><p>This cannot be undone. <a href="{{ route('admin.security') }}">Confirm your password</a> first, then return here.</p><form method="post" action="{{ route('admin.products.force-delete',$product) }}" data-bin-delete>@csrf @method('DELETE')<label>Type DELETE<input name="confirmation" required pattern="DELETE" autocomplete="off" maxlength="6"></label><button type="submit">Permanently delete</button></form></details>@endif
</td></tr>
@empty<tr><td colspan="4">Recycle Bin is empty.</td></tr>@endforelse
</tbody></table>{{ $products->links('admin.partials.pagination') }}</section>
<script src="{{ asset('js/admin-bin.js') }}?v=1" defer></script>
@endsection
