@extends('admin.layout')
@section('title','Orders')
@section('content')
<h1>Orders & fulfilment</h1><p class="muted">Payment verification and fulfilment are tracked separately.</p>
@include('admin.partials.order-filters')
<section class="table-wrap">@include('admin.partials.order-table'){{ $orders->links('admin.partials.pagination') }}</section>
@endsection
