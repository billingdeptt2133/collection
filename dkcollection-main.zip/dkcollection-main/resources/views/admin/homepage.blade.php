@extends('admin.layout')
@section('title', 'Homepage Banners')
@section('robots', 'noindex,nofollow')
@section('content')
<link rel="stylesheet" href="{{ asset('css/admin-homepage.css') }}?v=2">
<div class="admin-hp" style="display:block">
    <div class="hp-content">
        <header class="hp-header"><div><h1>Homepage Banners</h1><p>Upload desktop and mobile images, then set the page each image opens.</p></div><a href="{{ route('home') }}" target="_blank" rel="noopener">View live store ↗</a></header>
        @foreach(['main' => 'Main Banner', 'promotional' => 'Promotional Banner'] as $slot => $label)
            @include('admin.partials.homepage-image-banner', ['banner' => $imageBanners[$slot]])
        @endforeach
    </div>
</div>
@endsection
