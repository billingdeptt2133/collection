@extends('admin.layout')
@section('title','Categories')
@section('content')
<section><h2>Categories</h2><form class="form" method="post" action="{{ route('admin.categories.store') }}">@csrf<input name="name" placeholder="Category name" required><button class="primary">Add category</button></form>@foreach($categories as $category)<form class="card" method="post" action="{{ route('admin.categories.update', $category) }}">@csrf @method('PATCH')<input name="name" value="{{ $category->name }}" required><label><input type="checkbox" name="is_active" value="1" @checked($category->is_active)> Active</label><button>Save</button></form>@endforeach</section>
@endsection
