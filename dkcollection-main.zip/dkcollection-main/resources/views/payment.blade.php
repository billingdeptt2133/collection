<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex,nofollow">
    <meta name="theme-color" content="#fffdf9">
    <title>Pay for order #{{ $order->id }} | Jansen Jeans</title>
    <link rel="stylesheet" href="{{ asset('css/payment.css') }}?v=1">
</head>
<body class="payment-page">
    <a class="payment-skip" href="#payment-main">Skip to payment</a>
    <header class="payment-header">
        <div class="payment-header-inner">
            <a class="payment-brand" href="{{ route('home') }}">JANSEN JEANS</a>
            <nav aria-label="Store navigation">
                <a href="{{ route('home') }}">Shop</a>
                <a href="{{ route('orders') }}">Orders</a>
                <a href="{{ route('wishlist') }}">Wishlist</a>
                <a href="{{ route('cart') }}">Bag</a>
            </nav>
        </div>
    </header>

    <main id="payment-main" class="payment-shell">
        @if($errors->any())
            <div class="payment-notice payment-notice-error" role="alert">
                @foreach($errors->all() as $error)<p>{{ $error }}</p>@endforeach
            </div>
        @endif
        @if(session('message'))
            <p class="payment-notice" role="status">{{ session('message') }}</p>
        @endif

        <div class="payment-heading">
            <h1>Complete your payment</h1>
            <span class="payment-status"><span aria-hidden="true">◷</span> Payment pending</span>
            <p>Your order is awaiting payment.</p>
        </div>

        <div class="payment-grid">
            <section class="payment-summary payment-panel" aria-labelledby="summary-heading">
                <div class="payment-panel-heading">
                    <h2 id="summary-heading">Order summary</h2>
                    <span>Order #{{ $order->id }}</span>
                </div>
                <ul class="payment-items">
                    @foreach($order->items as $item)
                        @php($image = \App\Support\OrderPresentation::image($item))
                        <li class="payment-item">
                            <div class="payment-photo">
                                @if($image)
                                    <img src="{{ $image }}" alt="{{ $item->title }} — {{ $item->color }}" width="104" height="130">
                                @else
                                    <span role="img" aria-label="Product image unavailable">JJ</span>
                                @endif
                            </div>
                            <div class="payment-item-info">
                                <h3>{{ $item->title }}</h3>
                                <p>{{ $item->color }} <span aria-hidden="true">/</span> Size {{ $item->size }}</p>
                                <p>Qty {{ $item->quantity }} <span aria-hidden="true">·</span> ₹{{ number_format($item->price_paise / 100, 2) }} each</p>
                            </div>
                            <strong class="payment-item-total"><span class="payment-sr-only">Item total </span>₹{{ number_format($item->price_paise * $item->quantity / 100, 2) }}</strong>
                        </li>
                    @endforeach
                </ul>
                <dl class="payment-totals">
                    <div><dt>Subtotal</dt><dd>₹{{ number_format($order->subtotal_paise / 100, 2) }}</dd></div>
                    @if($order->discount_paise > 0)
                        <div><dt>Discount</dt><dd>−₹{{ number_format($order->discount_paise / 100, 2) }}</dd></div>
                    @endif
                    <div><dt>Delivery</dt><dd>{{ (int) $order->shipping_paise === 0 ? 'Free' : '₹'.number_format($order->shipping_paise / 100, 2) }}</dd></div>
                    @if($order->cod_fee_paise > 0)
                        <div><dt>COD fee</dt><dd>₹{{ number_format($order->cod_fee_paise / 100, 2) }}</dd></div>
                    @endif
                    <div class="payment-grand-total"><dt>Total</dt><dd>₹{{ number_format($order->total_paise / 100, 2) }}</dd></div>
                </dl>
            </section>

            <section class="payment-action payment-panel" aria-labelledby="payment-action-heading">
                <div class="payment-lock" aria-hidden="true">
                    <svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="5" y="10" width="14" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3M12 14v3"/></svg>
                </div>
                <h2 id="payment-action-heading">One last step</h2>
                <p id="payment-description">Continue to Razorpay to choose your payment method.</p>
                <button type="button" id="pay-button" class="payment-button" aria-describedby="payment-description payment-error">
                    Pay ₹{{ number_format($order->total_paise / 100, 2) }} securely <span aria-hidden="true">→</span>
                </button>
                <p class="payment-methods">Available payment methods are shown in Razorpay.</p>
                <p id="payment-error" class="payment-error" role="alert"></p>
                <noscript><p class="payment-error">Enable JavaScript to open secure payment. You can still view your order details below.</p></noscript>
                <a class="payment-details" href="{{ route('orders.show', $order) }}">View order details <span aria-hidden="true">→</span></a>
            </section>
        </div>
    </main>

    <footer class="payment-footer">
        <div class="payment-footer-inner">
            <a class="payment-brand" href="{{ route('home') }}">JANSEN JEANS</a>
            @php($supportEmail = filter_var($store->support_email, FILTER_VALIDATE_EMAIL))
            @php($whatsapp = preg_match('/^[0-9]{7,15}$/', (string) $store->whatsapp) ? $store->whatsapp : null)
            @if($supportEmail)
                <a href="mailto:{{ rawurlencode($supportEmail) }}">Need help? Contact us →</a>
            @elseif($whatsapp)
                <a href="https://wa.me/{{ $whatsapp }}" target="_blank" rel="noopener noreferrer">Need help? Contact us →</a>
            @elseif($store->support_phone)
                <span>Need help? {{ $store->support_phone }}</span>
            @endif
            <small>© {{ date('Y') }} Jansen Jeans</small>
        </div>
    </footer>

    <form id="payment-form" action="{{ route('payments.verify', $order) }}" method="post">
        @csrf
        <input type="hidden" name="razorpay_order_id">
        <input type="hidden" name="razorpay_payment_id">
        <input type="hidden" name="razorpay_signature">
    </form>
    <script src="https://checkout.razorpay.com/v1/checkout.js" defer></script>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            document.querySelector('#pay-button').addEventListener('click', () => {
                if (typeof Razorpay === 'undefined') {
                    document.querySelector('#payment-error').textContent = 'Payment service could not load. Please try again.';
                    return;
                }
                new Razorpay({
                    key: @json(config('services.razorpay.key')),
                    amount: @json($order->total_paise),
                    currency: 'INR',
                    name: 'Jansen Jeans',
                    order_id: @json($order->gateway_order_id),
                    handler(response) {
                        const form = document.querySelector('#payment-form');
                        for (const key of ['razorpay_order_id', 'razorpay_payment_id', 'razorpay_signature']) {
                            form.elements[key].value = response[key];
                        }
                        form.submit();
                    }
                }).open();
            });
        });
    </script>
</body>
</html>
