# Admin workspace deployment and acceptance

This change replaces the all-in-one dashboard with individual admin pages. It preserves the storefront, checkout routes, order prices and server-managed Razorpay secrets. The homepage management migration from PR #5 is also required if it has not been deployed.

## Required migration and assets

Back up production database, .env, views, CSS/JS and current Git commit outside public_html. Use /opt/alt/php83/usr/bin/php. Keep the private application in dkcollection; retain public_html/index.php and the storage symlink. During maintenance, fast-forward to the reviewed commit and run artisan migrate --force. Copy public/css/. and public/js/. to public_html/css/ and public_html/js/. Clear caches, rebuild configuration/views and bring the app up. Never run tests or migrate:fresh against production. Do not drop new tables for rollback: they may contain audit, stock and return records.

## Access and security

Existing is_admin=true accounts retain owner access. Public registration cannot set admin roles or MFA flags. Owner can grant catalog, orders or support access to an existing account after recent password confirmation. Access changes revoke database sessions; a version check also invalidates established admin sessions with another driver. Support can read customers/orders and moderate reviews; it cannot fulfil orders, access payments, export reports or grant roles.

Email two-step verification is opt-in and needs a working production mail transport. Confirm password, send a code, then verify to enable it. Codes are hashed, expire after five minutes, have a five-attempt limit and are single use. Verified admin sessions expire after eight hours. Configure SMTP and enable this for each staff account before assigning sensitive access. This is email verification, not authenticator-app TOTP.

Passwords, OTPs, payment keys and customer input are excluded from audit payloads. Admin responses use private/no-store. Mutations remain CSRF protected and rate limited. High-impact actions require password confirmation from the same account within 15 minutes. Keep APP_DEBUG=false, HTTPS and secure cookies. No software can guarantee that unauthorized access is impossible.

## Acceptance before real orders

1. Owner sees each page; customer gets 403. Direct staff URLs and old mutation endpoints enforce the same permissions.
2. Create a draft product with real photos, codes and exact size/colour variants; publish; check mobile/desktop product, gallery and cart. The stock CSV has a JavaScript row editor and textarea fallback.
3. Adjust stock with a reason. Stale adjustments and product snapshots reject edits made before a sale changed stock.
4. Test COD and online orders. Unpaid online orders cannot be fulfilled. Pack, enter tracking, dispatch, then confirm delivery. Record COD collection only after actual receipt.
5. Unshipped COD cancellation restores stock once. For a paid unshipped online order, queue cancellation first to block fulfilment. Verify its full processed gateway refund to complete cancellation and restore inventory once. Unpaid gateway orders remain pending until reconciliation; do not alter database records to bypass this.
6. Record delivered-order return, approve/reject, physically receive and inspect. Select restock only when ALL returned items are saleable. Whole-order returns only.
7. Issue full Razorpay refunds in its dashboard, then enter the ID in admin. The server verifies payment ID, exact full amount and processed status. Admin does not initiate gateway refunds. For collected COD returns, owner can record a completed full manual refund using a receipt/reference and explicit confirmation. This is labelled manual, not gateway verified.
8. Reports count paid online orders and recorded COD receipts, less processed full gateway refunds and explicitly recorded manual COD refunds. Date filters select order creation dates, not settlement dates. Top item amounts are gross before discounts/shipping.
9. Delivery page manages pincode coverage; save rates/payment switches together in Store settings. Razorpay connection check reads one gateway order; verify webhook delivery separately in Razorpay.
10. Configure email, enable two-step verification and test a fresh session/recovery before assigning staff access. Lost-mailbox recovery requires trusted server access; no public bypass exists.
11. Review rejection preserves history. Audit and stock history begin with this release.

## Differences from conceptual mockups

Existing accounts are used instead of invitation emails. Packing/shipping lives in Order Details. This release does not include partial refunds, automatic gateway refund initiation, secret editing, courier integrations, settlement reconciliation, tax invoices or authenticator-app MFA. Order print is an order summary, not a tax invoice. These must not be advertised as working.
