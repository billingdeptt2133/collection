(() => {
    const reduced = window.matchMedia(
        '(prefers-reduced-motion: reduce)'
    );

    document.querySelectorAll('.dk-visual').forEach((root) => {
        const items = Array.from(
            root.querySelectorAll(
                '.dk-category-slide, .dk-product-slide'
            )
        );

        if (!items.length) return;

        const button = root.querySelector('.dk-motion-toggle');
        const mobile = root.classList.contains('dk-categories');
        const seconds = Number(root.dataset.interval || 5);
        const interval = Math.min(15, Math.max(2, Number.isFinite(seconds) ? seconds : 5)) * 1000;

        let index = 0;
        let timer = null;
        let paused = false;
        let focused = false;

        const show = (nextIndex) => {
            // Remove the old slide before displaying the next one.
            items.forEach((item) => {
                item.hidden = true;
                item.classList.remove('dk-current');
                item.setAttribute('aria-hidden', 'true');
                item.inert = true;
            });

            index = nextIndex;

            const current = items[index];

            current.hidden = false;
            current.classList.add('dk-current');
            current.setAttribute('aria-hidden', 'false');
            current.inert = false;
        };

        const visible = () => {
            const banner = root.closest('.slide');

            return (
                !document.hidden &&
                root.getClientRects().length > 0 &&
                (!banner || banner.classList.contains('active'))
            );
        };

        const stop = () => {
            clearTimeout(timer);
            timer = null;
        };

        const schedule = () => {
            stop();

            if (
                paused ||
                focused ||
                reduced.matches ||
                items.length < 2 ||
                !visible()
            ) {
                return;
            }

            timer = setTimeout(() => {
                if (visible()) {
                    show((index + 1) % items.length);
                }

                schedule();
            }, interval);
        };

        show(0);

        if (button) {
            button.hidden = items.length < 2;

            button.addEventListener('click', () => {
                paused = !paused;

                button.textContent = paused ? 'Play' : 'Pause';
                button.setAttribute('aria-pressed', String(paused));
                button.setAttribute(
                    'aria-label',
                    paused ? 'Play image slideshow' : 'Pause image slideshow'
                );

                schedule();
            });
        }

        // Keep a focused category stable for keyboard navigation.
        root.addEventListener('focusin', () => {
            focused = true;
            schedule();
        });

        root.addEventListener('focusout', (event) => {
            focused = root.contains(event.relatedTarget);
            schedule();
        });

        document.addEventListener('visibilitychange', schedule);
        window.addEventListener('resize', schedule);
        reduced.addEventListener('change', schedule);

        const banner = root.closest('.slide');

        if (banner) {
            new MutationObserver(schedule).observe(banner, {
                attributes: true,
                attributeFilter: ['class', 'aria-hidden']
            });
        }

        schedule();
    });
})();
