// Touch uses native scrolling. Mouse dragging and keyboard arrows are manual only.
document.querySelectorAll('[data-partner-track]').forEach(track => {
    let drag = null;
    track.addEventListener('pointerdown', event => {
        if (event.pointerType !== 'mouse' || event.button !== 0 || track.scrollWidth <= track.clientWidth) return;
        drag = {id: event.pointerId, x: event.clientX, scroll: track.scrollLeft};
        track.setPointerCapture(event.pointerId);
        track.classList.add('is-dragging');
        track.focus({preventScroll: true});
        event.preventDefault();
    });
    track.addEventListener('pointermove', event => {
        if (drag?.id === event.pointerId) track.scrollLeft = drag.scroll - (event.clientX - drag.x);
    });
    const stop = () => { drag = null; track.classList.remove('is-dragging'); };
    track.addEventListener('pointerup', stop);
    track.addEventListener('pointercancel', stop);
    track.addEventListener('lostpointercapture', stop);
    track.addEventListener('keydown', event => {
        if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) return;
        event.preventDefault();
        if (event.key === 'Home') track.scrollLeft = 0;
        else if (event.key === 'End') track.scrollLeft = track.scrollWidth;
        else track.scrollLeft += (event.key === 'ArrowRight' ? 1 : -1) * track.clientWidth * .7;
    });
});

const footerMobile = matchMedia('(max-width:800px)');
document.querySelectorAll('[data-footer-group]').forEach(group => {
    const sync = () => { group.open = !footerMobile.matches; };
    group.querySelector('summary').addEventListener('click', event => {
        if (!footerMobile.matches) event.preventDefault();
    });
    footerMobile.addEventListener('change', sync);
    sync();
});
