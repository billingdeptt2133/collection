(function (root) {
    const api = {
        variant(variants, size, color) {
            return variants.find(v => String(v.size) === String(size) && v.color === color && Number(v.stock) > 0) || null;
        },
        sizeAvailable(variants, size, color) {
            return variants.some(v => String(v.size) === String(size) && (!color || v.color === color) && Number(v.stock) > 0);
        },
        limit(variant) { return variant ? Math.max(0, Math.min(10, Number(variant.stock))) : 0; },
        gallery(data, color) {
            const mapped = data.photos.filter(p => p.color === color);
            if (mapped.length) return [...new Set(mapped.map(p => p.src))];
            const colors = new Set(data.variants.map(v => v.color));
            if (data.photos.some(p => p.color) || colors.size > 1) return [];
            return [...new Set([data.defaultImage, ...data.photos.map(p => p.src)].filter(Boolean))];
        }
    };
    if (typeof module === 'object' && module.exports) module.exports = api;
    else root.DKProductVariants = api;
})(typeof window !== 'undefined' ? window : globalThis);
