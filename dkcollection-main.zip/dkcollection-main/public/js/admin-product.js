(() => {
 const editor=document.querySelector('[data-colour-editor]'); if(!editor)return;
 const form=document.querySelector('[data-product-editor]');
 const panels=editor.querySelector('[data-colour-panels]');
 const message=editor.querySelector('[data-colour-message]');
 const sizes=['28','30','32','34','36','38','40'];
 const previewUrls=new Map();
 function field(labelText,name,value,type='text') {
  const label=document.createElement('label');label.textContent=labelText;
  const input=document.createElement('input');input.name=name;input.type=type;input.value=value;
  if(type==='number'){input.min='0';input.max='100000';input.step='1'}
  if(type!=='hidden')input.required=true;
  label.append(input);return label;
 }
 function sizeCell(index,sizeIndex,size){
  const cell=document.createElement('div');cell.className='size-stock-cell is-zero';
  cell.append(field('Size '+size,`colours[${index}][sizes][${sizeIndex}][stock]`,'0','number'));
  const input=document.createElement('input');input.type='hidden';input.name=`colours[${index}][sizes][${sizeIndex}][size]`;input.value=size;cell.append(input);return cell;
 }
 function readiness(){
  if(!form)return;
  const checks={title:!!form.elements.title.value.trim(),price:Number(form.elements.price_rupees.value)>0,
   colours:[...panels.querySelectorAll('[data-colour-name]')].every(input=>input.value.trim()),
   photos:[...panels.children].every(panel=>Number(panel.querySelector('[data-saved-photos]')?.dataset.photoCount)>0||panel.querySelector('[data-colour-upload]')?.files.length>0),
   stock:[...panels.querySelectorAll('input[type=number]')].some(input=>Number(input.value)>0)};
  Object.entries(checks).forEach(([key,ready])=>form.querySelector(`[data-ready-${key}]`)?.classList.toggle('is-ready',!!ready));
  panels.querySelectorAll('input[type=number]').forEach(input=>input.closest('.size-stock-cell').classList.toggle('is-zero',Number(input.value)===0));
 }
 function preview(input,container,isCover=false){
  (previewUrls.get(input)||[]).forEach(URL.revokeObjectURL);previewUrls.set(input,[]);container.replaceChildren();
  const files=[...input.files];input.setCustomValidity('');
  if(files.length>(isCover?1:5)||files.some(file=>!['image/jpeg','image/png','image/webp'].includes(file.type)||file.size>4096*1024)){
   input.setCustomValidity('Choose up to 5 JPG, PNG or WebP photos, each at most 4 MB.');input.reportValidity();return;
  }
  files.forEach((file,index)=>{
   const url=URL.createObjectURL(file);previewUrls.get(input).push(url);
   const image=document.createElement('img');image.src=url;image.alt=file.name;
   const figure=document.createElement('figure');figure.append(image);
   if(!isCover&&index===0&&!Number(input.closest('[data-colour-panel]').querySelector('[data-saved-photos]')?.dataset.photoCount)){
    const caption=document.createElement('figcaption');caption.textContent='Main on save';figure.append(caption);
   }
   container.append(figure);
  });
 }
 editor.querySelector('[data-add-colour]').addEventListener('click',()=>{
  const index=panels.children.length;if(index>=6){message.textContent='Maximum 6 colours per product.';return}
  const panel=document.createElement('section');panel.className='colour-panel';panel.dataset.colourPanel='';
  const name=field('Colour name',`colours[${index}][name]`,'');name.querySelector('input').maxLength=50;name.querySelector('input').dataset.colourName='';panel.append(name);
  const saved=document.createElement('div');saved.className='colour-photos';saved.dataset.savedPhotos='';saved.dataset.photoCount='0';panel.append(saved);
  const label=document.createElement('label');label.textContent='+ Upload colour photos';const upload=document.createElement('input');upload.type='file';upload.multiple=true;upload.name=`colours[${index}][photos][]`;upload.accept='image/jpeg,image/png,image/webp';upload.dataset.colourUpload='';label.append(upload);panel.append(label);
  const previews=document.createElement('div');previews.className='colour-photos';previews.dataset.uploadPreviews='';panel.append(previews);
  const grid=document.createElement('div');grid.className='size-stock-grid';sizes.forEach((size,i)=>grid.append(sizeCell(index,i,size)));panel.append(grid);
  const helper=document.createElement('small');helper.textContent='0 = Out of stock';panel.append(helper,document.createElement('br'));
  const extra=document.createElement('button');extra.type='button';extra.dataset.addSize='';extra.textContent='+ Add extra size';panel.append(extra);
  panels.append(panel);name.querySelector('input').focus();readiness();
 });
 editor.addEventListener('click',event=>{
  if(!event.target.matches('[data-add-size]'))return;
  const panel=event.target.closest('[data-colour-panel]');const grid=panel.querySelector('.size-stock-grid');
  if(grid.children.length>=20){message.textContent='Maximum 20 sizes per colour.';return}
  const size=prompt('Extra size (for example 29 or XL):')?.trim();if(!size)return;
  if(!/^[\p{L}\p{N} .-]{1,20}$/u.test(size)){message.textContent='Enter a valid size.';return}
  if([...grid.querySelectorAll('input[type=hidden]')].some(input=>input.name.endsWith('[size]')&&input.value===size)){message.textContent='Size already exists.';return}
  grid.append(sizeCell([...panels.children].indexOf(panel),grid.children.length,size));readiness();
 });
 form?.addEventListener('input',()=>{readiness();form.querySelector('[data-save-status]').textContent='Unsaved changes'});
 form?.addEventListener('change',event=>{
  const input=event.target;
  if(input.matches('[data-colour-upload]'))preview(input,input.closest('[data-colour-panel]').querySelector('[data-upload-previews]'));
  if(input.matches('[data-cover-upload]'))preview(input,form.querySelector('[data-cover-preview]'),true);
  readiness();form.querySelector('[data-save-status]').textContent='Unsaved changes';
 });
 form?.addEventListener('submit',()=>{form.querySelector('[data-save-status]').textContent='Saving…'});
 window.addEventListener('pagehide',()=>{previewUrls.forEach(urls=>urls.forEach(URL.revokeObjectURL));previewUrls.clear()});
 document.querySelector('[data-trash-product]')?.addEventListener('submit',event=>{if(!confirm('Move this product and all its colours to Recycle Bin? You can restore it later.'))event.preventDefault()});
 document.querySelector('[data-delete-product]')?.addEventListener('submit',event=>{if(!confirm('Permanently delete this product? This cannot be undone.'))event.preventDefault()});
 document.querySelectorAll('[data-confirm-remove-photo]').forEach(button=>button.closest('form').addEventListener('submit',event=>{if(!confirm('Remove this saved photo?'))event.preventDefault()}));
 readiness();
})();
