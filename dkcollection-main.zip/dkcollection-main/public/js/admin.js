document.querySelectorAll('textarea[data-stock-editor]').forEach(textarea=>{
    const editor=document.createElement('div');
    editor.className='stock-editor';
    const rows=document.createElement('div');
    const add=document.createElement('button');
    add.type='button';add.textContent='+ Add size / shade';add.className='stock-add';
    editor.append(rows,add);textarea.closest('label').after(editor);
    const fields=['Size','Colour','Quantity','Shade code','Barcode'];
    function addRow(values=[]){
        if(rows.children.length>=50)return;
        const row=document.createElement('div');row.className='stock-row';
        fields.forEach((field,index)=>{
            const label=document.createElement('label');label.textContent=field;
            const input=document.createElement('input');input.value=values[index]||'';
            input.placeholder=['32','Indigo','10','IBST','6732'][index];
            if(index===2){input.type='number';input.min='0';input.max='100000'}
            else{input.maxLength=[20,50,0,30,64][index];input.pattern=index===4?'[A-Za-z0-9-]*':'[^,]*'}
            input.required=index<3;label.append(input);row.append(label);
        });
        const remove=document.createElement('button');remove.type='button';remove.textContent='Remove';remove.setAttribute('aria-label','Remove stock row');
        remove.addEventListener('click',()=>{if(rows.children.length>1)row.remove();sync()});row.append(remove);
        row.addEventListener('input',sync);rows.append(row);sync();
    }
    function sync(){textarea.value=[...rows.children].map(row=>[...row.querySelectorAll('input')].map(input=>input.value.trim()).join(',')).join('\n')}
    (textarea.value.trim().split(/\r?\n/).filter(Boolean).map(line=>line.split(',').map(value=>value.trim()))).forEach(addRow);
    if(!rows.children.length)addRow();
    add.addEventListener('click',()=>addRow());
    textarea.required=false;textarea.hidden=true;
    textarea.form.addEventListener('submit',sync);
});

