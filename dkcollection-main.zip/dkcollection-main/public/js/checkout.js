(() => {
    document.querySelectorAll('[data-password-toggle]').forEach(button => {
        const input = document.getElementById(button.getAttribute('aria-controls'));
        if (!input) return;
        button.addEventListener('click', () => {
            const show = input.type === 'password';
            input.type = show ? 'text' : 'password';
            button.textContent = show ? 'Hide' : 'Show';
            button.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
            button.setAttribute('aria-pressed', String(show));
        });
    });
    const money = value => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR' }).format(value / 100);
    const fetchQuote = async (url, params, signal) => {
        const endpoint = new URL(url, location.origin);
        Object.entries(params).forEach(([key, value]) => endpoint.searchParams.set(key, value));
        const response = await fetch(endpoint, { headers: { Accept: 'application/json' }, cache: 'no-store', signal });
        const result = await response.json();
        if (!response.ok) throw new Error(Object.values(result.errors || {}).flat()[0] || 'Unable to check delivery. Please retry.');
        return result;
    };
    const details = document.querySelector('[data-checkout-details]');
    if (details) {
        const form = details.querySelector('#checkout-details-form');
        const pincode = form.elements.pincode;
        const check = form.querySelector('[data-check-delivery]');
        const status = form.querySelector('[data-delivery-status]');
        const shipping = details.querySelector('[data-shipping-preview]');
        let request;
        const login = details.querySelector('[data-login-form]');
        const contact = form.querySelector('[data-contact-section]');
        const notice = details.querySelector('[data-account-status]');
        const create = form.querySelector('[data-create-account]');
        const continueButton = form.querySelector('button[type="submit"]');
        let busy = false;
        const message = text => { notice.textContent = text; notice.hidden = !text; };
        const toggle = showLogin => {
            if (busy || !login) return;
            login.hidden = !showLogin; contact.hidden = showLogin;
            continueButton.disabled = showLogin;
            message('');
            if (showLogin) {
                login.elements.email.value = form.elements.email.value;
                login.elements.email.focus();
            }
        };
        document.querySelector('[data-open-login]')?.addEventListener('click', event => { event.preventDefault(); toggle(true); });
        details.querySelector('[data-open-register]')?.addEventListener('click', () => toggle(false));
        if (create) create.hidden = false;
        const post = async (url, data) => {
            const response = await fetch(url, { method: 'POST', body: data, credentials: 'same-origin',
                headers: { Accept: 'application/json', 'X-CSRF-TOKEN': form.elements._token.value }, cache: 'no-store' });
            let result;
            try { result = await response.json(); } catch { throw new Error('Unable to complete this request. Please retry.'); }
            if (!response.ok) {
                if (response.status === 419) throw new Error('Your session expired. Please reload this page before continuing.');
                const field = Object.keys(result.errors || {})[0];
                const input = (!login?.hidden ? login : form)?.elements[field];
                input?.focus();
                throw new Error(Object.values(result.errors || {}).flat()[0] || 'Unable to continue. Please retry.');
            }
            return result;
        };
        const lock = value => {
            busy = value;
            continueButton.disabled = value || Boolean(login && !login.hidden);
            if (create) create.disabled = value;
            if (login) login.querySelector('button[type="submit"]').disabled = value;
        };
        const authenticate = async (data) => {
            if (busy) return;
            lock(true); message('Signing you in…');
            try {
                const result = await post(details.dataset.accountUrl, data);
                if (request) request.abort(); request = null; check.disabled = false;
                details.querySelectorAll('[name="_token"]').forEach(input => { input.value = result.csrf_token; });
                details.querySelectorAll('[name="checkout_token"]').forEach(input => { input.value = result.checkout_token; });
                const identity = document.querySelector('[data-account-identity]');
                identity.querySelector('[data-account-name]').textContent = `Signed in as ${result.user.name}`;
                identity.querySelector('[data-account-email]').textContent = result.user.email;
                identity.hidden = false;
                document.querySelector('[data-account-prompt]').hidden = true;
                login.hidden = true; contact.hidden = false;
                contact.querySelector('[data-contact-heading]').textContent = 'Contact details';
                form.querySelectorAll('[data-registration-field]').forEach(group => {
                    group.hidden = true;
                    group.querySelectorAll('input').forEach(input => { input.disabled = true; if (input.name === 'password') input.value = ''; });
                });
                login.elements.password.value = '';
                create.hidden = true;
                if (!form.elements.name.value) form.elements.name.value = result.user.name;
                message('Signed in. Complete your shipping address to continue.');
            } catch (error) { message(error.message); }
            finally { lock(false); }
        };
        login?.addEventListener('submit', event => { event.preventDefault(); if (login.reportValidity()) authenticate(new FormData(login)); });
        create?.addEventListener('click', () => {
            for (const name of ['name', 'email', 'password']) if (!form.elements[name].reportValidity()) return;
            const data = new FormData();
            for (const name of ['name', 'email', 'password', 'checkout_token']) data.set(name, form.elements[name].value);
            data.set('mode', 'register');
            authenticate(data);
        });
        form.addEventListener('submit', async event => {
            // Preserve the existing no-JavaScript login fallback when appropriate.
            if (event.submitter?.hasAttribute('data-open-login')) { event.preventDefault(); toggle(true); return; }
            event.preventDefault();
            if (busy || (login && !login.hidden) || !form.reportValidity()) return;
            lock(true); message('Preparing your payment step…');
            try {
                const result = await post(form.action, new FormData(form));
                const target = new URL(result.redirect_url, location.origin);
                if (target.origin !== location.origin) throw new Error('Unable to open the payment step. Please retry.');
                window.location.assign(target.href);
            } catch (error) { message(error.message); lock(false); }
        });
        pincode.addEventListener('input', () => {
            if (request) request.abort();
            request = null;
            check.disabled = false;
            shipping.textContent = 'Enter pincode';
            status.textContent = 'Enter your pincode to calculate delivery.';
        });
        check.addEventListener('click', async () => {
            if (!/^[0-9]{6}$/.test(pincode.value)) { status.textContent = 'Enter a valid 6-digit pincode.'; pincode.focus(); return; }
            if (request) request.abort();
            const current = new AbortController(); request = current;
            check.disabled = true; status.textContent = 'Checking delivery…';
            try {
                const quote = await fetchQuote(details.dataset.quoteUrl, { pincode: pincode.value, checkout_token: form.elements.checkout_token.value }, current.signal);
                if (request !== current) return;
                shipping.textContent = money(quote.shipping_paise);
                status.textContent = `Delivery available${quote.delivery_estimate ? ` · Estimated: ${quote.delivery_estimate}` : ''}. Shipping: ${money(quote.shipping_paise)}. Payment fees are shown in the next step.`;
            } catch (error) {
                if (error.name !== 'AbortError' && request === current) { status.textContent = error.message; shipping.textContent = 'Check pincode'; }
            } finally { if (request === current) check.disabled = false; }
        });
    }
    const payment = document.querySelector('[data-checkout-payment]');
    if (payment) {
        const preview = payment.querySelector('[data-payment-preview]');
        const order = payment.querySelector('[data-order-form]');
        const submit = order.querySelector('[data-place-order]');
        const status = preview.querySelector('[data-payment-status]');
        let request;
        const update = async () => {
            if (!preview.reportValidity()) return;
            if (request) request.abort();
            const current = new AbortController(); request = current;
            submit.disabled = true; status.textContent = 'Updating your total…';
            try {
                const quote = await fetchQuote(payment.dataset.quoteUrl, { pincode: payment.dataset.pincode, checkout_token: payment.dataset.checkoutToken,
                    payment_method: preview.elements.payment_method.value, coupon: preview.elements.coupon.value }, current.signal);
                if (request !== current) return;
                const fields = { subtotal: 'subtotal_paise', discount: 'discount_paise', shipping: 'shipping_paise', cod: 'cod_fee_paise', total: 'total_paise' };
                Object.entries(fields).forEach(([selector, field]) => { payment.querySelector(`[data-quote-${selector}]`).textContent = `${selector === 'discount' ? '−' : ''}${money(quote[field])}`; });
                order.elements.payment_method.value = quote.payment_method;
                order.elements.coupon.value = preview.elements.coupon.value;
                order.elements.expected_total_paise.value = String(quote.total_paise);
                payment.querySelector('[data-order-total]').textContent = money(quote.total_paise);
                payment.querySelector('[data-order-label]').textContent = quote.payment_method === 'cod' ? 'Place COD Order' : 'Continue to Pay';
                payment.querySelector('[data-payment-note]').textContent = quote.payment_method === 'cod' ? 'This confirms your cash-on-delivery order.' : 'Your order is paid only after payment is verified.';
                status.textContent = 'Total updated. Review the amount before placing your order.';
                submit.disabled = false;
            } catch (error) { if (error.name !== 'AbortError' && request === current) status.textContent = error.message; }
        };
        preview.addEventListener('submit', event => { event.preventDefault(); update(); });
        preview.querySelectorAll('[name="payment_method"]').forEach(input => input.addEventListener('change', update));
        preview.elements.coupon.addEventListener('input', () => {
            if (request) request.abort();
            request = null;
            submit.disabled = true;
            status.textContent = 'Select Update total to apply or remove your coupon.';
        });
        order.addEventListener('submit', event => {
            if (submit.disabled) { event.preventDefault(); return; }
            submit.disabled = true;
            status.textContent = 'Submitting your order…';
        });
        window.addEventListener('pageshow', event => { if (event.persisted) update(); });
    }
})();
