document.querySelectorAll('[data-bin-delete]').forEach(form=>form.addEventListener('submit',event=>{
    if(!confirm('Permanently delete this product and its photos? This cannot be undone.'))event.preventDefault();
}));
