(() => {
    document.querySelectorAll('[data-bag-quantity]').forEach(form => {
        const input = form.querySelector('[name="quantity"]');
        form.querySelectorAll('[data-qty-step]').forEach(button => {
            button.addEventListener('click', () => {
                const value = Number(input.value) + Number(button.dataset.qtyStep);
                if (!Number.isInteger(value) || value < Number(input.min) || value > Number(input.max)) return;
                input.value = String(value);
                if (form.reportValidity()) {
                    form.requestSubmit();
                    form.querySelectorAll('button').forEach(control => { control.disabled = true; });
                }
            });
        });
    });
})();
