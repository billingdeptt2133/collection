(() => {
    const root = document.querySelector('[data-product-detail]');
    const api = window.DKProductVariants;
    if (!root || !api) return;
    const data = JSON.parse(root.dataset.presentation);
    let variants = data.variants;
    const select = root.querySelector('[name="variant_id"]');
    const quantity = root.querySelector('[name="quantity"]');
    const add = root.querySelector('[data-add-cart]');
    const buy = root.querySelector('[data-buy-now]');
    const status = root.querySelector('[data-stock-status]');
    const colorButtons = [...root.querySelectorAll('[data-color]')];
    const sizeButtons = [...root.querySelectorAll('[data-size]')];
    const restored = variants.find(v => String(v.id) === select.value);
    let color = restored?.color || data.initialColor || variants.find(v => Number(v.stock) > 0)?.color || variants[0]?.color || '';
    let size = restored?.size || '';
    const track = root.querySelector('[data-gallery-track]');
    const thumbnails = root.querySelector('[data-gallery-thumbnails]');
    const count = root.querySelector('[data-gallery-count]');
    const empty = root.querySelector('[data-gallery-empty]');
    const previous = root.querySelector('[data-gallery-prev]');
    const next = root.querySelector('[data-gallery-next]');
    let sources = [], photoIndex = 0, scrollFrame = null, refreshing = false;
    const reduceMotion = matchMedia('(prefers-reduced-motion: reduce)');

    const updatePhoto = index => {
        photoIndex = Math.max(0, Math.min(index, sources.length - 1));
        count.textContent = `${photoIndex + 1} / ${sources.length}`;
        [...thumbnails.children].forEach((button, i) => {
            button.classList.toggle('is-selected', i === photoIndex);
            button.setAttribute('aria-pressed', String(i === photoIndex));
        });
        const active = thumbnails.children[photoIndex];
        if (active) {
            const left = active.offsetLeft - thumbnails.offsetLeft;
            if (left < thumbnails.scrollLeft || left + active.offsetWidth > thumbnails.scrollLeft + thumbnails.clientWidth)
                thumbnails.scrollTo({ left: Math.max(0, left - 10), behavior: reduceMotion.matches ? 'instant' : 'smooth' });
        }
        previous.disabled = photoIndex === 0;
        next.disabled = photoIndex === sources.length - 1;
    };
    const goToPhoto = index => {
        if (!sources.length) return;
        index = Math.max(0, Math.min(index, sources.length - 1));
        track.scrollTo({ left: index * track.clientWidth, behavior: reduceMotion.matches ? 'instant' : 'smooth' });
    };
    const renderGallery = () => {
        sources = api.gallery({ ...data, variants }, color);
        track.replaceChildren(); thumbnails.replaceChildren();
        sources.forEach((src, i) => {
            const frame = document.createElement('div'); frame.className = 'pdp-photo';
            const image = document.createElement('img');
            image.src = src; image.alt = `${root.dataset.productTitle} — ${color}, view ${i + 1}`;
            image.loading = i === 0 ? 'eager' : 'lazy'; image.decoding = 'async';
            frame.append(image); track.append(frame);
            const button = document.createElement('button'); button.type = 'button';
            button.setAttribute('aria-label', `View photograph ${i + 1}`);
            const thumb = image.cloneNode(); thumb.alt = ''; thumb.loading = 'lazy';
            button.append(thumb); button.addEventListener('click', () => goToPhoto(i)); thumbnails.append(button);
        });
        empty.hidden = sources.length > 0; count.hidden = !sources.length;
        previous.hidden = next.hidden = sources.length < 2;
        track.scrollLeft = 0; updatePhoto(0);
    };
    track.addEventListener('scroll', () => {
        cancelAnimationFrame(scrollFrame);
        scrollFrame = requestAnimationFrame(() => { if (track.clientWidth && sources.length) updatePhoto(Math.round(track.scrollLeft / track.clientWidth)); });
    });
    track.addEventListener('keydown', event => {
        if (event.key === 'ArrowRight' || event.key === 'ArrowLeft') {
            event.preventDefault(); goToPhoto(photoIndex + (event.key === 'ArrowRight' ? 1 : -1));
        }
    });
    previous.addEventListener('click', () => goToPhoto(photoIndex - 1));
    next.addEventListener('click', () => goToPhoto(photoIndex + 1));
    new ResizeObserver(() => { if (track.clientWidth) track.scrollLeft = photoIndex * track.clientWidth; }).observe(track);

    const renderSelection = () => {
        const variant = api.variant(variants, size, color);
        if (!variant) size = '';
        select.value = variant ? String(variant.id) : '';
        const heading = root.querySelector('[data-product-heading]');
        if (heading) heading.textContent = `${color ? color + ' ' : ''}${root.dataset.productTitle}`;
        root.querySelector('[data-color-name]').textContent = color || 'Choose a colour';
        sizeButtons.forEach(button => {
            const available = api.sizeAvailable(variants, button.dataset.size, color);
            button.disabled = !available;
            button.classList.toggle('is-sold-out', !available);
            button.classList.toggle('is-selected', String(size) === button.dataset.size);
            button.setAttribute('aria-pressed', String(String(size) === button.dataset.size));
            button.setAttribute('aria-label', `Size ${button.dataset.size}${available ? '' : ' — sold out for this colour'}`);
        });
        colorButtons.forEach(button => {
            // Allow colour selection even if that colour is entirely sold out.
            button.classList.toggle('is-selected', button.dataset.color === color);
            button.setAttribute('aria-pressed', String(button.dataset.color === color));
        });
        const limit = api.limit(variant);
        quantity.max = String(limit || 10);
        if (limit) quantity.value = String(Math.max(1, Math.min(limit, Number(quantity.value) || 1)));
        add.disabled = !variant;
        if (buy) buy.disabled = !variant;
        add.textContent = variants.some(v => Number(v.stock) > 0) ? 'Add to Cart' : 'Sold out';
        status.textContent = variant ? `${variant.stock} available in ${variant.size} / ${variant.color}` :
            variants.some(v => v.color === color && Number(v.stock) > 0) ? 'Choose your size.' : 'This colour is sold out.';
    };
    sizeButtons.forEach(button => button.addEventListener('click', () => { size = button.dataset.size; renderSelection(); }));
    const swatches = { indigo: '#283d58', black: '#242424', blue: '#507299', 'light blue': '#99b0c9', 'washed blue': '#7697b6', charcoal: '#50535a', white: '#f4f1e9', beige: '#cdbba0', brown: '#87654f', grey: '#949494', gray: '#949494', green: '#486552', red: '#ad4343' };
    colorButtons.forEach(button => {
        const swatch = button.querySelector('.pdp-swatch');
        const paint = swatches[button.dataset.color.toLowerCase()];
        if (paint) swatch.style.backgroundColor = paint; else swatch.hidden = true;
        button.addEventListener('click', () => { color = button.dataset.color; renderSelection(); renderGallery(); });
    });
    root.querySelector('[data-variant-fallback]').hidden = true;
    select.required = false; select.tabIndex = -1;
    root.querySelector('[data-variant-controls]').hidden = false;
    root.querySelector('[data-quantity-minus]').addEventListener('click', () => { quantity.value = String(Math.max(1, (Number(quantity.value) || 1) - 1)); });
    root.querySelector('[data-quantity-plus]').addEventListener('click', () => { quantity.value = String(Math.min(Number(quantity.max), (Number(quantity.value) || 1) + 1)); });
    quantity.addEventListener('change', () => { quantity.value = String(Math.max(1, Math.min(Number(quantity.max), Number(quantity.value) || 1))); });
    root.querySelector('[data-cart-form]').addEventListener('submit', event => {
        const variant = api.variant(variants, size, color);
        if (!variant || Number(quantity.value) < 1 || Number(quantity.value) > api.limit(variant)) {
            event.preventDefault(); renderSelection(); status.textContent = 'Choose an available size and colour with a valid quantity.';
        }
    });
    const refreshStock = async () => {
        if (document.hidden || refreshing) return;
        refreshing = true;
        try {
            const response = await fetch(root.dataset.availabilityUrl, { headers: { Accept: 'application/json' }, cache: 'no-store', signal: AbortSignal.timeout(8000) });
            if (response.status === 404) { variants = variants.map(v => ({ ...v, stock: 0 })); renderSelection(); status.textContent = 'This product is no longer available.'; return; }
            if (!response.ok) return;
            const result = await response.json();
            if (Array.isArray(result.variants)) { variants = result.variants; renderSelection(); }
        } catch (_) { /* Existing server checks still validate cart and checkout stock. */ }
        finally { refreshing = false; }
    };
    renderSelection(); renderGallery();
    setInterval(refreshStock, 20000);
    document.addEventListener('visibilitychange', refreshStock);
    window.addEventListener('pageshow', refreshStock);
})();
