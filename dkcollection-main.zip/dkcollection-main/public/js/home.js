document.querySelectorAll('.hero-product-slider').forEach(slider => {
    const images = [...slider.querySelectorAll('.hero-product-slide')];
    if (images.length < 2) return;

    const count = slider.querySelector('[data-product-count]');
    const pause = slider.querySelector('[data-product-pause]');
    const desktop = matchMedia('(min-width:801px)');
    const reducedMotion = matchMedia('(prefers-reduced-motion:reduce)');
    let index = 0;
    let paused = false;
    let timer;

    const show = next => {
        index = (next + images.length) % images.length;
        images.forEach((image, position) => image.hidden = position !== index);
        count.textContent = `${index + 1} / ${images.length}`;
    };

    const stop = () => clearInterval(timer);
    const start = () => {
        stop();
        if (paused || !desktop.matches || reducedMotion.matches || document.hidden) return;
        timer = setInterval(() => {
            if (slider.closest('.slide')?.classList.contains('active')) show(index + 1);
        }, 5000);
    };

    slider.querySelector('[data-product-prev]').addEventListener('click', () => {
        show(index - 1);
        start();
    });
    slider.querySelector('[data-product-next]').addEventListener('click', () => {
        show(index + 1);
        start();
    });
    pause.addEventListener('click', () => {
        paused = !paused;
        pause.textContent = paused ? 'Play' : 'Pause';
        pause.setAttribute('aria-pressed', String(paused));
        start();
    });

    slider.addEventListener('mouseenter', stop);
    slider.addEventListener('mouseleave', start);
    slider.addEventListener('focusin', stop);
    slider.addEventListener('focusout', event => {
        if (!slider.contains(event.relatedTarget)) start();
    });
    desktop.addEventListener('change', start);
    reducedMotion.addEventListener('change', start);
    document.addEventListener('visibilitychange', start);
    start();
});
document.querySelectorAll('.hero-category-slider').forEach(slider => {
    const cards = [...slider.querySelectorAll('.hero-category-slide')];
    const pause = slider.querySelector('[data-category-pause]');
    if (cards.length < 2 || !pause) return;

    const mobile = matchMedia('(max-width:800px)');
    const reducedMotion = matchMedia('(prefers-reduced-motion:reduce)');
    let index = 0;
    let paused = false;
    let timer;

    const stop = () => clearInterval(timer);
    const start = () => {
        stop();
        if (paused || !mobile.matches || reducedMotion.matches || document.hidden ||
            slider.contains(document.activeElement)) return;

        timer = setInterval(() => {
            if (!slider.closest('.slide')?.classList.contains('active')) return;
            index = (index + 1) % cards.length;
            cards.forEach((card, position) => card.hidden = position !== index);
        }, 2000);
    };

    pause.addEventListener('click', () => {
        paused = !paused;
        pause.querySelector('span').textContent = paused ? '▶' : 'Ⅱ';
        pause.setAttribute('aria-pressed', String(paused));
        pause.setAttribute('aria-label', paused ? 'Play category slideshow' : 'Pause category slideshow');
        start();
    });

    slider.addEventListener('mouseenter', stop);
    slider.addEventListener('mouseleave', start);
    slider.addEventListener('focusin', stop);
    slider.addEventListener('focusout', event => {
        if (!slider.contains(event.relatedTarget)) start();
    });
    mobile.addEventListener('change', start);
    reducedMotion.addEventListener('change', start);
    document.addEventListener('visibilitychange', start);
    start();
});

// Append only same-origin server-rendered product cards. Product data remains server-owned.
const more=document.querySelector('.show-more');
more?.addEventListener('click',async()=>{
    if(!more.dataset.next||more.disabled)return;
    const label=more.textContent;
    more.disabled=true;
    more.setAttribute('aria-busy','true');
    more.textContent='Loading…';
    try{
        const next=new URL(more.dataset.next,window.location.href);
        if(next.origin!==window.location.origin||next.pathname!==window.location.pathname)throw new Error('Invalid page URL');
        const response=await fetch(next.href,{credentials:'same-origin',headers:{Accept:'text/html','X-Requested-With':'XMLHttpRequest'}});
        if(!response.ok)throw new Error('Product list could not be loaded');
        const page=new DOMParser().parseFromString(await response.text(),'text/html');
        const cards=[...page.querySelectorAll('#new-arrivals .product-card')];
        if(!cards.length)throw new Error('No product cards returned');
        document.querySelector('#new-arrivals .product-grid').append(...cards);
        more.dataset.next=page.querySelector('.show-more')?.dataset.next||'';
        more.hidden=!more.dataset.next;
        more.textContent='Show more products';
    }catch{
        more.textContent='Try again';
        more.dataset.retryLabel=label;
    }finally{
        more.disabled=false;
        more.removeAttribute('aria-busy');
    }
});
