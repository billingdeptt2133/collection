// All commerce actions use the existing server routes. No simulated cart or wishlist state.
const drawer = document.querySelector('[data-menu-drawer]');
if (drawer) {
    const trigger = drawer.querySelector('summary');
    const panel = drawer.querySelector('.drawer-panel');
    const sync = () => {
        document.body.classList.toggle('menu-open', drawer.open);
        trigger.setAttribute('aria-expanded', String(drawer.open));
        trigger.setAttribute('aria-label', drawer.open ? 'Close navigation' : 'Open navigation');
    };
    const close = () => { drawer.open = false; sync(); trigger.focus(); };
    drawer.addEventListener('toggle', sync);
    drawer.querySelectorAll('[data-menu-close]').forEach(button => button.addEventListener('click', close));
    panel.querySelectorAll('a').forEach(link => link.addEventListener('click', () => { drawer.open = false; sync(); }));
    document.addEventListener('keydown', event => {
        if (!drawer.open) return;
        if (event.key === 'Escape') { event.preventDefault(); close(); }
        if (event.key !== 'Tab') return;
        const targets = [trigger, ...panel.querySelectorAll('a[href],button:not(:disabled)')];
        const first = targets[0], last = targets[targets.length - 1];
        if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
        else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
    });
    matchMedia('(min-width:801px)').addEventListener('change', event => { if (event.matches) { drawer.open = false; sync(); } });
    sync();
}
const search = document.querySelector('[data-search-panel]');
search?.addEventListener('toggle', () => { if (search.open) search.querySelector('input').focus(); });
document.addEventListener('keydown', event => { if (event.key === 'Escape' && search?.open) { search.open = false; search.querySelector('summary').focus(); } });

// One handler appends server-rendered colour cards; preserve the existing 20 + 12 pagination.
const more = document.querySelector('.show-more');
more?.addEventListener('click', async () => {
    if (!more.dataset.next || more.disabled) return;
    more.disabled = true; more.setAttribute('aria-busy', 'true'); more.textContent = 'Loading…';
    try {
        const next = new URL(more.dataset.next, location.href);
        if (next.origin !== location.origin || next.pathname !== location.pathname) throw new Error('Invalid page');
        const response = await fetch(next.href, {credentials: 'same-origin', headers: {Accept: 'text/html', 'X-Requested-With': 'XMLHttpRequest'}});
        if (!response.ok) throw new Error('Load failed');
        const page = new DOMParser().parseFromString(await response.text(), 'text/html');
        const cards = [...page.querySelectorAll('#new-arrivals .product-card')];
        if (!cards.length) throw new Error('No products returned');
        document.querySelector('#new-arrivals .product-grid').append(...cards);
        more.dataset.next = page.querySelector('.show-more')?.dataset.next || '';
        more.hidden = !more.dataset.next; more.textContent = 'Show more products';
    } catch { more.textContent = 'Try again'; }
    finally { more.disabled = false; more.removeAttribute('aria-busy'); }
});

// Configured partner logos remain manually scrollable, never autoplaying.
document.querySelectorAll('[data-partner-track]').forEach(track => {
    let drag = null;
    track.addEventListener('pointerdown', event => {
        if (event.pointerType !== 'mouse' || event.button !== 0 || track.scrollWidth <= track.clientWidth) return;
        drag = {id: event.pointerId, x: event.clientX, scroll: track.scrollLeft};
        track.setPointerCapture(event.pointerId); track.classList.add('is-dragging');
        track.focus({preventScroll: true}); event.preventDefault();
    });
    track.addEventListener('pointermove', event => { if (drag?.id === event.pointerId) track.scrollLeft = drag.scroll - (event.clientX - drag.x); });
    const stop = () => { drag = null; track.classList.remove('is-dragging'); };
    ['pointerup', 'pointercancel', 'lostpointercapture'].forEach(type => track.addEventListener(type, stop));
    track.addEventListener('keydown', event => {
        if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) return;
        event.preventDefault();
        if (event.key === 'Home') track.scrollLeft = 0;
        else if (event.key === 'End') track.scrollLeft = track.scrollWidth;
        else track.scrollLeft += (event.key === 'ArrowRight' ? 1 : -1) * track.clientWidth * .7;
    });
});

// Reveal each section once, without hiding content or delaying shopping actions.
const motionPreference = matchMedia('(prefers-reduced-motion: reduce)');
if (!motionPreference.matches && 'IntersectionObserver' in window) {
    const sections = document.querySelectorAll('main > section, main > .jj-partners, .editorial-footer');
    const observer = new IntersectionObserver(entries => {
        entries.forEach(entry => {
            if (!entry.isIntersecting) return;
            entry.target.classList.add('home-revealed');
            observer.unobserve(entry.target);
        });
    }, {threshold: 0, rootMargin: '0px 0px -24px 0px'});
    sections.forEach(section => observer.observe(section));
    motionPreference.addEventListener('change', event => {
        if (event.matches) {
            observer.disconnect();
            sections.forEach(section => section.classList.remove('home-revealed'));
        }
    });
}
