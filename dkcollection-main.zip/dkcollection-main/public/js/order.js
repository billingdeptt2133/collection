(() => {
    'use strict';
    document.querySelectorAll('[data-print-order]').forEach(button => {
        button.addEventListener('click', () => window.print());
    });
})();
