# Customer order page design

The customer order detail page now uses the approved cream/forest-green desktop and mobile layout. It shows purchase-time prices and quantities, store-entered manual courier/milestones or saved verified Shiprocket tracking, shipping address, payment state, support and a printable order summary.

No database migration or Composer change is introduced by this design. Product thumbnails use current admin gallery images matching the purchased colour; a deleted variant or ambiguous unmapped multi-colour product gets a placeholder. Photos are not an immutable purchase-time snapshot. Financial/order item text remains the existing purchase-time snapshot.

Order ownership is checked before related records are loaded; even an admin uses the separate admin route for customer orders. The customer response is private/no-store and noindex/nofollow. Blade escapes content. Tracking links require HTTPS without credentials, custom ports, IPs or local hostnames; opening a link does not initiate server-side requests. Internal notes, provider IDs, label URLs and credentials are not rendered. Print is a local browser action, not a tax invoice.

After backing up Hostinger files, fetch reviewed main and fast-forward with a clean working tree. Copy `public/css/order.css` and `public/js/order.js` to the sibling public_html css/js folders. Clear/rebuild Blade caches using PHP 8.3. Retain the existing private app location, front controller, .env and storage link. If deploying alongside the shipping workspace, also follow SHIPROCKET_DEPLOYMENT.md for its additive migration and assets.

Check mobile/desktop order rendering, manual processing/dispatched/delivered orders, unpaid online payment, cancelled/RTO states, printing, configured support and another customer's denied order URL before enabling normal use. This page never calls the carrier API itself or mutates payment, inventory or fulfilment.
