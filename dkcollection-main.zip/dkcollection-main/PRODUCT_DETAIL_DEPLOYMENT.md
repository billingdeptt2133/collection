# Product detail deployment

After deploying these files, run `php artisan migrate --force`, followed by `php artisan optimize:clear`.

Admin Products: upload each colour's gallery separately using “Colour for uploaded gallery photos”. The colour must exactly match a variant colour. Existing gallery photos can be assigned with their colour dropdown. Photos from another colour are never substituted. Multi-colour products without mapped photos display a missing-photo message until mapping is complete. Single-colour legacy products retain their existing gallery.

Select size, then colour; changing colour clears an unavailable selected size. Sold-out sizes for the selected colour show a diagonal line. Quantity is limited by stock and the existing maximum of ten. Availability refreshes every 20 seconds in visible tabs and when returning to the page. Cart and checkout continue to validate stock on the server. Checkout's existing transaction and row locks remain unchanged.

Wishlist is in the main image's top-right corner; guests sign in, signed-in shoppers use the existing CSRF-protected wishlist endpoint. Reviews and delivery use existing backend rules.

Validation: `node --test tests/js/product-variants.test.cjs`; `php artisan test`. Check gallery swiping and thumbnails, two colours with different photos, final-unit checkout, sold-out sizes, wishlist, pincode checks, and review eligibility on a staging installation before domain deployment.
