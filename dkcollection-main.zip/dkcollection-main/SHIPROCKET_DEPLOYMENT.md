# Shipping workspace rollout

Default: Manual. Existing orders remain Manual. An additive migration saves the provider/pickup/parcel estimate on each new order. Switching modes does not change existing shipments or fees.

## Before production deployment
- Back up the database, private `.env`, changed views and public assets. Keep the app outside `public_html` and retain the current front controller/storage link.
- Fetch reviewed main, check for local changes, fast-forward only. Use PHP 8.3. No Composer dependency changes.
- During maintenance run `php artisan migrate --force`, copy changed public assets to the sibling public_html, clear/rebuild config and Blade caches, then bring the app up. Do not run fresh migrations or seeders.
- Verify manual checkout, order packing, owner settings access and staff restrictions before activation. Keep `APP_DEBUG=false` and existing APP_KEY/session security settings.

## Later Shiprocket activation — no source edits needed
Create a dedicated API user with required order, courier, pickup and tracking access in Shiprocket; customer details access must permit fulfilment. Configure these values in the private server environment (never in Git, browser JS or customer forms):

```
SHIPROCKET_API_EMAIL=
SHIPROCKET_API_PASSWORD=
SHIPROCKET_WEBHOOK_SECRET=
SHIPROCKET_DOCUMENT_HOSTS=shiprocket.s3.amazonaws.com
```

Generate a random webhook secret of at least 32 characters. Configure the same security token in Shiprocket and callback `https://newzhub.fun/webhooks/delivery-updates` (`x-api-key`). Run config cache after editing the environment. No token/password is displayed in admin. Cached bearer tokens are encrypted using the existing application key.

Owner: confirm password → Shipping & logistics → Settings → Test connection → use the exact returned pickup name and pincode → verify parcel defaults → enable Shiprocket. Configure the existing customer shipping fee/free-shipping threshold in Delivery; carrier freight is an independent merchant cost. Manual fallback is off by default and must be deliberately enabled.

Hostinger cron must invoke Laravel's scheduler every minute with PHP 8.3, for example:

```
/opt/alt/php83/usr/bin/php /home/u956251287/domains/newzhub.fun/dkcollection/artisan schedule:run
```

The scheduled command verifies at most 30 oldest pending shipments per five-minute run. Configure cron before enabling live tracking; use `shipping:sync` or Refresh tracking for a manual check. The webhook only requests a sync: untrusted callback contents never set Delivered, collect COD or restore inventory.

## Fulfilment
Pack the order after verified payment (or COD). Confirm actual parcel dimensions/weight, compare couriers, confirm password and approve booking. AWB assignment does not mark Shipped. Generate a label and request pickup; verified tracking moves the order to Shipped/Delivered. A document URL must have an exact allowed HTTPS host; if the account returns another host, verify it before adding that exact host to the private environment.

Booking, AWB and pickup requests are never blindly retried. A timeout persists an uncertain operation and prevents duplicate creation. Owner reconciliation takes a provider order ID and verifies store reference, destination and amount before reconnecting an existing shipment. Pickup reconciliation requires a provider pickup confirmation. If no provider order exists or the remote result cannot be verified, leave the booking blocked and investigate; there is intentionally no unsafe reset button.

Delivery issues/RTO are shown in a dedicated queue. Carrier cancellation and NDR actions currently remain in the Shiprocket panel; booked orders are blocked from local cancellation to prevent stock restoration while a parcel still exists. RTO stock is never automatically restored. Verified RTO shipments can enter the existing return queue; admin approval and physically confirmed receipt/inspection control restocking, exactly once. Receipt closes the local order; prepaid refunds still need gateway reconciliation. Automatic bank-statement import is not part of this release.

COD settlements are a separate owner ledger of manually verified net bank credits, not gateway verification or automatic remittance. Delivered never marks COD paid or remitted.

## Pilot acceptance (required before normal shipping)
The automated suite uses API fakes. Real credentials/account permissions, wallet charges, the provider's exact subtotal/discount/COD total interpretation, actual label host, pickup scheduling, callback delivery and cron must be verified with one low-value prepaid and one COD pilot. Compare provider totals to the local order before dispatch. Do not claim live carrier validation from fake tests. Switch new orders to Manual if activation checks fail; existing Shiprocket shipments continue tracking.

Contract reference: https://apidocs.shiprocket.in/ and Shiprocket's official Postman collection.
