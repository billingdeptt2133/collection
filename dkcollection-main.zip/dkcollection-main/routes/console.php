<?php

use Illuminate\Foundation\Inspiring;
use Illuminate\Support\Facades\Artisan;

Artisan::command('inspire', function () {
    $this->comment(Inspiring::quote());
})->purpose('Display an inspiring quote');

Artisan::command('shipping:sync', function () {
    if (! app(\App\Services\Shiprocket::class)->configured()) { $this->info('Shiprocket is not configured.'); return; }
    \Illuminate\Support\Facades\Cache::lock('logistics.sync', 900)->get(function () {
        \App\Models\Shipment::whereNotNull('awb')->whereNotNull('provider_shipment_id')
            ->whereNotIn('state',['delivered','rto_received'])->where(fn($q)=>$q->whereNull('synced_at')->orWhere('synced_at','<',now()->subMinutes(15))->orWhereNotNull('sync_requested_at'))
            ->orderBy('updated_at')->limit(30)->get()->each(function($shipment) {
                try { app(\App\Services\ShipmentWorkflow::class)->sync($shipment); }
                catch (\Throwable) { $shipment->touch(); $this->warn('Tracking unavailable for shipment #'.$shipment->id); }
            });
    });
})->purpose('Verify carrier tracking without booking or changing payment/stock');
\Illuminate\Support\Facades\Schedule::command('shipping:sync')->everyFiveMinutes()->withoutOverlapping();

\Illuminate\Support\Facades\Schedule::command('payments:expire-pending-razorpay')->everyMinute()->withoutOverlapping();
