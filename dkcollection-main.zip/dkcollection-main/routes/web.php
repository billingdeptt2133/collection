<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\CartController;
use App\Http\Controllers\CheckoutController;
use App\Http\Controllers\CheckoutDetailsController;
use App\Http\Controllers\DeliveryController;
use App\Http\Controllers\ReviewController;
use App\Http\Controllers\PaymentController;
use App\Http\Controllers\PasswordController;
use App\Http\Controllers\StorefrontController;
use App\Http\Controllers\SeoController;
use App\Http\Controllers\WishlistController;
use App\Http\Middleware\Admin;
use Illuminate\Support\Facades\Route;

Route::get('/policies/{policy}', function(string $policy){$titles=['shipping'=>'Shipping policy','returns'=>'Return policy','privacy'=>'Privacy policy','terms'=>'Terms of service'];$fields=['shipping'=>'shipping_policy','returns'=>'return_policy','privacy'=>'privacy_policy','terms'=>'terms_policy'];abort_unless(isset($fields[$policy]),404);$store=\App\Models\StoreSetting::first();abort_unless($store&&filled($store->{$fields[$policy]}),404);return view('policy',['policyTitle'=>$titles[$policy],'policyText'=>$store->{$fields[$policy]},'store'=>$store]);})->whereIn('policy',['shipping','returns','privacy','terms'])->name('policy');
Route::get('/pages/{page}', [\App\Http\Controllers\StorePageController::class, 'show'])->whereIn('page', ['about', 'faqs', 'contact', 'sustainability', 'size-guide'])->name('store.page');
Route::get('/sitemap.xml', [SeoController::class, 'sitemap'])->name('sitemap');
Route::get('/robots.txt', [SeoController::class, 'robots'])->name('robots');
Route::get('/', [StorefrontController::class, 'index'])->name('home');
Route::get('/products/{slug}/availability', [StorefrontController::class, 'availability'])->middleware('throttle:30,1')->name('products.availability');
Route::get('/products/{slug}', [StorefrontController::class, 'product'])->name('products.show');
Route::get('/delivery/check', [DeliveryController::class, 'check'])->middleware('throttle:30,1')->name('delivery.check');
Route::get('/cart', [CartController::class, 'index'])->name('cart');
Route::post('/cart', [CartController::class, 'add'])->middleware('throttle:30,1')->name('cart.add');
Route::post('/buy-now', [CartController::class, 'buyNow'])->middleware('throttle:30,1')->name('buy-now');
Route::patch('/cart/{variant}', [CartController::class, 'update'])->name('cart.update');
Route::get('/checkout', [CheckoutController::class, 'form'])->middleware('cache.headers:no_store;private')->name('checkout');
Route::post('/checkout/details', [CheckoutDetailsController::class, 'prepare'])->middleware('throttle:5,1')->name('checkout.details');
Route::post('/checkout/account', [CheckoutDetailsController::class, 'account'])->middleware('throttle:5,1')->name('checkout.account');
Route::post('/checkout/login', [CheckoutDetailsController::class, 'login'])->middleware('throttle:10,1')->name('checkout.login');
Route::get('/checkout/quote', [CheckoutDetailsController::class, 'quote'])->middleware('throttle:30,1')->name('checkout.quote');
Route::middleware('guest')->group(function () {
    Route::get('/account', [AuthController::class, 'form'])->name('login');
    Route::post('/login', [AuthController::class, 'login'])->middleware('throttle:5,1')->name('login.submit');
    Route::post('/register', [AuthController::class, 'register'])->middleware('throttle:5,1')->name('register');
    Route::get('/forgot-password', [PasswordController::class, 'requestForm'])->name('password.request');
    Route::post('/forgot-password', [PasswordController::class, 'email'])->middleware('throttle:3,1')->name('password.email');
    Route::get('/reset-password/{token}', [PasswordController::class, 'resetForm'])->name('password.reset');
    Route::post('/reset-password', [PasswordController::class, 'reset'])->middleware('throttle:5,1')->name('password.update');
});
Route::post('/logout', [AuthController::class, 'logout'])->middleware('auth')->name('logout');
Route::middleware('auth')->group(function () {
    Route::get('/checkout/payment', [CheckoutDetailsController::class, 'payment'])->middleware('cache.headers:no_store;private')->name('checkout.payment');
    Route::post('/checkout', [CheckoutController::class, 'place'])->middleware('throttle:5,1')->name('checkout.place');
    Route::get('/orders/{order}/pay', [PaymentController::class, 'show'])->name('payments.show');
    Route::post('/orders/{order}/pay', [PaymentController::class, 'verify'])->middleware('throttle:10,1')->name('payments.verify');
    Route::get('/orders', [CheckoutController::class, 'index'])->name('orders');
    Route::get('/orders/{order}', [CheckoutController::class, 'show'])->middleware('cache.headers:no_store;private')->name('orders.show');
    Route::get('/wishlist', [WishlistController::class, 'index'])->name('wishlist');
    Route::post('/wishlist/{product}', [WishlistController::class, 'toggle'])->name('wishlist.toggle');
    Route::post('/products/{product}/reviews', [ReviewController::class, 'store'])->middleware('throttle:5,1')->name('reviews.store');
});

Route::middleware(['auth', Admin::class, 'throttle:admin-workspace'])->prefix('admin')->name('admin.')->group(function () {
    Route::get('/shipping', [\App\Http\Controllers\Admin\ShippingController::class, 'index'])->name('shipping');
    Route::post('/shipping/settings', [\App\Http\Controllers\Admin\ShippingController::class, 'settings'])->name('shipping.settings');
    Route::post('/shipping/test', [\App\Http\Controllers\Admin\ShippingController::class, 'test'])->middleware('throttle:3,1')->name('shipping.test');
    Route::post('/shipping/{order}/rates', [\App\Http\Controllers\Admin\ShippingController::class, 'rates'])->middleware('throttle:10,1')->name('shipping.rates');
    Route::post('/shipping/{order}/action', [\App\Http\Controllers\Admin\ShippingController::class, 'action'])->middleware('throttle:10,1')->name('shipping.action');
    Route::get('/homepage', [\App\Http\Controllers\Admin\HomepageController::class, 'index'])->middleware('cache.headers:no_store;private')->name('homepage');
    Route::post('/homepage/banners/{slot}', [\App\Http\Controllers\Admin\HomepageController::class, 'saveBanner'])->whereIn('slot', ['main', 'promotional'])->name('homepage.banners.save');
    Route::get('/', [\App\Http\Controllers\Admin\WorkspaceController::class, 'dashboard'])->name('dashboard');
    foreach (['products','categories','coupons','orders','customers','reviews','settings','delivery','payments','stock','returns','reports','access','activity'] as $section) {
        Route::get('/'.$section, [\App\Http\Controllers\Admin\WorkspaceController::class, 'page'])->defaults('section',$section)->name($section);
    }
    Route::get('/products/recycle-bin', [\App\Http\Controllers\Admin\ProductRecycleBinController::class, 'index'])->name('products.recycle-bin');
    Route::patch('/products/{product}/restore', [\App\Http\Controllers\Admin\ProductRecycleBinController::class, 'restore'])->withTrashed()->name('products.restore');
    Route::delete('/products/{product}/permanent', [\App\Http\Controllers\Admin\ProductRecycleBinController::class, 'destroy'])->withTrashed()->name('products.force-delete');
    Route::get('/products/new', [\App\Http\Controllers\Admin\WorkspaceController::class, 'productForm'])->name('products.create');
    Route::get('/products/{product}/edit', [\App\Http\Controllers\Admin\WorkspaceController::class, 'productForm'])->name('products.edit');
    Route::post('/payments/test', [\App\Http\Controllers\Admin\OperationsController::class, 'testGateway'])->middleware('throttle:3,1')->name('payments.test');
    Route::post('/stock/{variant}', [\App\Http\Controllers\Admin\OperationsController::class, 'stock'])->name('stock.update');
    Route::post('/shipping/{order}', [\App\Http\Controllers\Admin\OperationsController::class, 'shipping'])->name('shipping.update');
    Route::post('/orders/{order}/cancel-online', [\App\Http\Controllers\Admin\OperationsController::class, 'cancelOnline'])->name('orders.cancel-online');
    Route::post('/returns/{id}/cod-refund', [\App\Http\Controllers\Admin\OperationsController::class, 'codRefund'])->whereNumber('id')->name('returns.cod-refund');
    Route::post('/orders/{order}/cod', [\App\Http\Controllers\Admin\OperationsController::class, 'cod'])->name('orders.cod');
    Route::post('/returns', [\App\Http\Controllers\Admin\OperationsController::class, 'returnRequest'])->name('returns.store');
    Route::post('/returns/{id}', [\App\Http\Controllers\Admin\OperationsController::class, 'returnUpdate'])->whereNumber('id')->name('returns.update');
    Route::post('/returns/{id}/refund', [\App\Http\Controllers\Admin\OperationsController::class, 'refund'])->whereNumber('id')->name('returns.refund');
    Route::get('/reports/export', [\App\Http\Controllers\Admin\WorkspaceController::class, 'export'])->name('reports.export');
    Route::get('/security', [\App\Http\Controllers\Admin\SecurityController::class, 'index'])->name('security');
    Route::post('/security/confirm', [\App\Http\Controllers\Admin\SecurityController::class, 'confirm'])->middleware('throttle:admin-confirm')->name('security.confirm');
    Route::post('/security/send', [\App\Http\Controllers\Admin\SecurityController::class, 'send'])->middleware('throttle:admin-code-send')->name('security.send');
    Route::post('/security/verify', [\App\Http\Controllers\Admin\SecurityController::class, 'verify'])->middleware('throttle:admin-code-verify')->name('security.verify');
    Route::post('/access', [\App\Http\Controllers\Admin\SecurityController::class, 'access'])->name('access.update');
    Route::post('/access/{user}/revoke', [\App\Http\Controllers\Admin\SecurityController::class, 'revoke'])->name('access.revoke');
    Route::post('/customers/{user}/reset', [\App\Http\Controllers\Admin\SecurityController::class, 'reset'])->middleware('throttle:3,1')->name('customers.reset');
    Route::post('/settings', [\App\Http\Controllers\Admin\SettingsController::class, 'update'])->name('settings.update');
    Route::post('/pincodes', [\App\Http\Controllers\Admin\SettingsController::class, 'pincode'])->name('pincodes.store');
    Route::patch('/pincodes/{pincode}', [\App\Http\Controllers\Admin\SettingsController::class, 'toggle'])->name('pincodes.toggle');
    Route::post('/products', [\App\Http\Controllers\Admin\DashboardController::class, 'product'])->name('products.store');
    Route::post('/products/archive-demos', [\App\Http\Controllers\Admin\DashboardController::class, 'archiveDemos'])->name('products.archive-demos');
    Route::post('/products/{product}', [\App\Http\Controllers\Admin\DashboardController::class, 'product'])->name('products.update');
    Route::patch('/images/{image}/color', [\App\Http\Controllers\Admin\DashboardController::class, 'updateImageColor'])->name('images.color');
    Route::delete('/images/{image}', [\App\Http\Controllers\Admin\DashboardController::class, 'deleteImage'])->name('images.delete');
    Route::delete('/products/{product}', [\App\Http\Controllers\Admin\ProductRecycleBinController::class, 'trash'])->name('products.delete');
    Route::patch('/products/{product}/archive', [\App\Http\Controllers\Admin\DashboardController::class, 'archiveProduct'])->name('products.archive');
    Route::patch('/categories/{category}', [\App\Http\Controllers\Admin\DashboardController::class, 'updateCategory'])->name('categories.update');
    Route::post('/coupons/{coupon}', [\App\Http\Controllers\Admin\CouponController::class, 'update'])->name('coupons.update');
    Route::patch('/coupons/{coupon}', [\App\Http\Controllers\Admin\DashboardController::class, 'toggleCoupon'])->name('coupons.toggle');
    Route::post('/categories', [\App\Http\Controllers\Admin\DashboardController::class, 'category'])->name('categories.store');
    Route::post('/coupons', [\App\Http\Controllers\Admin\DashboardController::class, 'coupon'])->name('coupons.store');
    Route::patch('/orders/{order}', [\App\Http\Controllers\Admin\DashboardController::class, 'order'])->name('orders.update');
    Route::get('/orders/{order}', [\App\Http\Controllers\Admin\DashboardController::class, 'showOrder'])->name('orders.show');
    Route::get('/customers/{user}', [\App\Http\Controllers\Admin\DashboardController::class, 'customer'])->name('customers.show');
    Route::delete('/reviews/{review}', [\App\Http\Controllers\Admin\DashboardController::class, 'rejectReview'])->name('reviews.reject');
    Route::patch('/reviews/{review}', [\App\Http\Controllers\Admin\DashboardController::class, 'review'])->name('reviews.approve');
});

Route::post('/webhooks/razorpay', [PaymentController::class, 'webhook'])->middleware('throttle:120,1')->name('webhooks.razorpay');



Route::post('/webhooks/delivery-updates', \App\Http\Controllers\ShippingWebhookController::class)->middleware('throttle:120,1')->name('webhooks.delivery');
