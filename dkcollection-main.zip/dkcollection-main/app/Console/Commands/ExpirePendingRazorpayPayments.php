<?php

namespace App\Console\Commands;

use App\Models\Order;
use App\Services\RazorpayPaymentLifecycle;
use Illuminate\Console\Command;
use Throwable;

class ExpirePendingRazorpayPayments extends Command
{
    protected $signature = 'payments:expire-pending-razorpay {--limit=100}';
    protected $description = 'Reconcile expired Razorpay orders and release only confirmed failed reservations';
    public function handle(RazorpayPaymentLifecycle $lifecycle): int
    {
        $limit = max(1, min(500, (int) $this->option('limit')));
        Order::query()->where('payment_method', 'razorpay')->where('payment_status', 'pending')->where('status', 'pending')
            ->whereNull('stock_released_at')->where('payment_expires_at', '<=', now()->subMinutes(5))
            ->where(fn ($q) => $q->whereNull('gateway_reconcile_after')->orWhere('gateway_reconcile_after', '<=', now()))
            ->orderBy('id')->limit($limit)->get()->each(function (Order $order) use ($lifecycle): void {
                try { $lifecycle->reconcileExpired($order); } catch (Throwable $e) { report($e); }
            });
        return self::SUCCESS;
    }
}
