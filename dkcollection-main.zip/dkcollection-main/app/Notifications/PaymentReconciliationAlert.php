<?php

namespace App\Notifications;

use App\Models\PaymentReconciliation;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class PaymentReconciliationAlert extends Notification
{
    public function __construct(public PaymentReconciliation $issue) {}
    public function via(object $notifiable): array { return ['mail']; }
    public function toMail(object $notifiable): MailMessage
    {
        return (new MailMessage)->subject('Jansen Jeans payment needs reconciliation')
            ->greeting('Payment review required')->line('Issue: '.$this->issue->kind)
            ->line('Local order: '.($this->issue->order_id ? '#'.$this->issue->order_id : 'unmatched'))
            ->line('Razorpay order: '.($this->issue->gateway_order_id ?: 'unknown'))
            ->line('Payment ID: '.($this->issue->payment_id ?: 'unknown'))
            ->action('Review admin dashboard', route('admin.dashboard'))
            ->line('Check the payment_reconciliations record before fulfilment or refund.');
    }
}
