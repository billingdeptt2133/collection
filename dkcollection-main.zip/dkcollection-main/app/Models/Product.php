<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Product extends Model
{
    use \Illuminate\Database\Eloquent\SoftDeletes;
    protected $fillable = ['category_id', 'title', 'slug', 'description', 'seo_title', 'seo_description', 'product_code', 'article_code', 'pattern', 'price_paise', 'mrp_paise', 'image_path', 'is_active', 'is_demo', 'sort_order'];

    protected function casts(): array
    {
        return ['is_active' => 'boolean', 'is_demo' => 'boolean', 'price_paise' => 'integer', 'mrp_paise' => 'integer'];
    }

    public function displayImage(): ?string
    {
        if ($this->image_path) return asset('storage/'.$this->image_path);
        return $this->is_demo ? asset('images/demo/'.$this->slug.'.svg') : null;
    }

    public function images(): \Illuminate\Database\Eloquent\Relations\HasMany
    {
        return $this->hasMany(ProductImage::class);
    }

    public function variants(): \Illuminate\Database\Eloquent\Relations\HasMany
    {
        return $this->hasMany(Variant::class);
    }

    public function approvedReviews(): \Illuminate\Database\Eloquent\Relations\HasMany
    {
        return $this->hasMany(Review::class)->where('is_approved', true);
    }

    public function category(): BelongsTo
    {
        return $this->belongsTo(Category::class);
    }
}

