<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ShippingPincode extends Model
{
    protected $fillable = ['pincode', 'is_active', 'cod_available'];

    protected function casts(): array
    {
        return ['is_active' => 'boolean', 'cod_available' => 'boolean'];
    }
}
