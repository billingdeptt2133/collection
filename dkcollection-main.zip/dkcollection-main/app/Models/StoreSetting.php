<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class StoreSetting extends Model
{
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['homepage' => 'array', 'checkout_enabled' => 'boolean', 'cod_enabled' => 'boolean', 'online_enabled' => 'boolean'];
    }
}

