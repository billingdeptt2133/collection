<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Variant extends Model
{
    protected $fillable = ['size', 'color', 'stock', 'shade_code', 'barcode'];

    public function product(): BelongsTo
    {
        return $this->belongsTo(Product::class);
    }
}
