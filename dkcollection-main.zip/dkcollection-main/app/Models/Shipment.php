<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Shipment extends Model {
 protected $guarded=['id'];
 protected function casts():array {return ['parcel'=>'array','tracking_events'=>'array','synced_at'=>'datetime','sync_requested_at'=>'datetime','pickup_requested_at'=>'datetime','settled_at'=>'datetime'];}
 public function order(){return $this->belongsTo(Order::class);}
}
