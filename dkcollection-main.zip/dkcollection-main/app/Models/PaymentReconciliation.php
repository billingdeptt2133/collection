<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PaymentReconciliation extends Model
{
    protected $guarded = ['id'];
    protected function casts(): array
    {
        return ['details' => 'array', 'alerted_at' => 'datetime', 'resolved_at' => 'datetime'];
    }
}
