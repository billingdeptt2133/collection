<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Order extends Model
{
    protected $guarded = ['id'];

    protected $casts = [
        'payment_expires_at' => 'datetime',
        'stock_released_at' => 'datetime',
        'gateway_reconcile_after' => 'datetime',
    ];

    public function shipment() { return $this->hasOne(Shipment::class); }

    public function items(): HasMany
    {
        return $this->hasMany(OrderItem::class);
    }
}
