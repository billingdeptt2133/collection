<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Coupon extends Model
{
    protected $guarded = ['id'];

    public function discount(int $subtotal): int
    {
        $amount = $this->discount_type === 'percent' ? intdiv($subtotal * (int) $this->percentage, 100) : (int) $this->discount_paise;
        if ($this->maximum_paise !== null) $amount = min($amount, (int) $this->maximum_paise);
        return min($subtotal, $amount);
    }

    protected function casts(): array
    {
        return ['is_active' => 'boolean', 'expires_at' => 'datetime', 'starts_at' => 'datetime'];
    }
}
