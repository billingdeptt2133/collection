<?php

namespace App\Support;

use App\Http\Controllers\CartController;
use App\Models\Coupon;
use App\Models\StoreSetting;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;

class CheckoutQuote
{
    public static function calculate(Request $request, string $pincode, ?string $method = null, ?string $code = null): array
    {
        $context = $request->session()->get('checkout_context') === 'buy_now' ? 'buy_now' : 'cart';
        $cart = $request->session()->get($context, []);
        $lines = CartController::lines($request, $context);
        if (! is_array($cart) || ! $cart || count($cart) !== $lines->count()
            || $lines->contains(fn ($line) => $line->quantity !== (int) ($cart[$line->variant->id] ?? 0))) {
            throw ValidationException::withMessages(['cart' => 'Your bag has changed or an item is unavailable. Please review your bag.']);
        }
        $settings = StoreSetting::first() ?? new StoreSetting;
        $available = Shipping::availability($pincode, $settings, (int)$lines->sum('quantity'), (int)$lines->sum(fn($line)=>$line->variant->product->price_paise*$line->quantity));
        if (! $available['available']) {
            throw ValidationException::withMessages(['pincode' => 'Delivery is unavailable for this pincode or checkout is temporarily disabled.']);
        }
        $subtotal = (int) $lines->sum(fn ($line) => $line->variant->product->price_paise * $line->quantity);
        $coupon = null;
        if (filled($code)) {
            $coupon = Coupon::where('code', strtoupper(trim($code)))->first();
            if (! $coupon?->is_active || ($coupon->expires_at && $coupon->expires_at->isPast()) || ($coupon->starts_at && $coupon->starts_at->isFuture())
                || $subtotal < $coupon->minimum_paise || ($coupon->usage_limit !== null && $coupon->used_count >= $coupon->usage_limit)) {
                throw ValidationException::withMessages(['coupon' => 'Coupon is invalid or unavailable.']);
            }
        }
        $discount = $coupon?->discount($subtotal) ?? 0;
        $online = (bool) ($settings->online_enabled && config('services.razorpay.key') && config('services.razorpay.secret'));
        $onlineFees = Delivery::fees($subtotal - $discount, 'razorpay', $settings);
        $online = $online && ($available['prepaid'] ?? true) && $subtotal - $discount + array_sum($onlineFees) >= 100;
        $cod = (bool) $available['cod'];
        $method ??= $online ? 'razorpay' : ($cod ? 'cod' : null);
        if (! $method || ($method === 'cod' && ! $cod) || ($method === 'razorpay' && ! $online)) {
            throw ValidationException::withMessages(['payment_method' => 'No selected payment option is available for this address.']);
        }
        $fees = Delivery::fees($subtotal - $discount, $method, $settings);

        return ['subtotal_paise' => $subtotal, 'discount_paise' => $discount, ...$fees,
            'total_paise' => $subtotal - $discount + array_sum($fees),
            'shipping_provider' => $available['provider'], 'delivery_estimate' => $available['estimate'] ?? null, 'payment_method' => $method, 'cod_available' => $cod, 'online_available' => $online];
    }
}
