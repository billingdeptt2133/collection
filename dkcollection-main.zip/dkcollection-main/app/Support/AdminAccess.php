<?php

namespace App\Support;
use App\Models\User;
class AdminAccess {
    public static function allows(?User $user,string $section): bool {
        if(!$user?->is_admin)return false;
        $role=$user->admin_role??'owner';
        if($role==='owner')return true;
        return in_array($section,match($role) {
            'catalog'=>['dashboard','products','stock','categories','homepage','banners','images','reviews'],'orders'=>['dashboard','orders','shipping','returns','customers'],'support'=>['dashboard','customers','orders','reviews'],default=>[]
        },true);
    }
    public static function section(string $route): string {
        return explode('.',str_replace('admin.','',$route))[0];
    }
}
