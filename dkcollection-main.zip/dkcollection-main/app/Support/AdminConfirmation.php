<?php

namespace App\Support;
use Illuminate\Http\Request;
class AdminConfirmation {
    public static function require(Request $r):void {
        abort_unless($r->session()->get('admin_confirmed_user')===$r->user()->id&&time()-(int)$r->session()->get('admin_confirmed',0)<900,423,'Confirm your password in Admin security first (valid for 15 minutes).');
    }
}
