<?php

namespace App\Support;

use App\Models\ShippingPincode;
use App\Models\StoreSetting;

class Delivery
{
    public static function availability(string $pincode, StoreSetting $settings): array
    {
        return Shipping::availability($pincode, $settings);
    }

    public static function manualAvailability(string $pincode, StoreSetting $settings): array
    {
        if (! preg_match('/^[0-9]{6}$/', $pincode) || ! $settings->checkout_enabled)
            return ['available' => false, 'cod' => false];
        if ($settings->delivery_mode === 'all') return ['available' => true, 'cod' => $settings->cod_enabled];
        $zone = ShippingPincode::where('pincode', $pincode)->where('is_active', true)->first();

        return ['available' => (bool) $zone, 'cod' => (bool) $zone?->cod_available && $settings->cod_enabled];
    }

    public static function fees(int $afterDiscount, string $paymentMethod, StoreSetting $settings): array
    {
        $free = $settings->free_shipping_above_paise;
        return [
            'shipping_paise' => $free !== null && $afterDiscount >= $free ? 0 : $settings->flat_shipping_paise,
            'cod_fee_paise' => $paymentMethod === 'cod' ? $settings->cod_fee_paise : 0,
        ];
    }
}
