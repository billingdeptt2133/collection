<?php

namespace App\Support;

use App\Models\Product;

class ProductPresentation
{
    public static function cards(Product $product): array
    {
        $colors = $product->variants->pluck('color')->unique()->values();
        if ($colors->isEmpty()) return [];
        return $colors->map(function ($color) use ($product, $colors) {
            $photo = $product->images->first(fn($image) => $image->color === $color);
            $image = $photo ? asset('storage/'.$photo->path) : ($colors->count() === 1 ? $product->displayImage() : null);
            return [
                'color' => $color, 'title' => $color.' '.$product->title,
                'image' => $image, 'url' => route('products.show', ['slug'=>$product->slug, 'color'=>$color]),
                'soldOut' => !$product->variants->contains(fn($v) => $v->color === $color && $v->stock > 0),
            ];
        })->all();
    }

    public static function data(Product $product): array
    {
        $variants = $product->variants->map(fn ($variant) => [
            'id' => $variant->id,
            'size' => $variant->size,
            'color' => $variant->color,
            'stock' => (int) $variant->stock,
        ])->values();

        $photos = $product->images->map(fn ($image) => [
            'src' => asset('storage/'.$image->path),
            'color' => $image->color,
        ])->values();

        return [
            'variants' => $variants->all(),
            'photos' => $photos->all(),
            'defaultImage' => $product->displayImage(),
        ];
    }
}
