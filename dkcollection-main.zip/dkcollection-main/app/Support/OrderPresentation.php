<?php

namespace App\Support;

use App\Models\Order;
use App\Models\OrderItem;

class OrderPresentation
{
    public static function data(Order $order): array
    {
        $shipment = $order->shipment;
        $returned = in_array($shipment?->state, ['rto', 'rto_received'], true);
        $cancelled = $order->status === 'cancelled';
        $needsPayment = ! $cancelled && $order->payment_method === 'razorpay'
            && $order->payment_status === 'pending' && $order->status === 'pending';
        $stage = match ($order->status) {
            'processing' => 1, 'shipped' => 2, 'delivered' => 3, default => 0,
        };
        $heading = match (true) {
            $shipment?->state === 'rto_received' => 'Your parcel was returned',
            $returned => 'Your parcel is returning to us',
            $cancelled => 'This order was cancelled',
            $shipment?->state === 'delivery_issue' => 'Delivery needs attention',
            $needsPayment => 'Complete your payment',
            $order->status === 'delivered' => 'Your order has arrived',
            $order->status === 'shipped' => 'Your order is on its way',
            $order->status === 'processing' => 'Your order is being prepared',
            default => 'Your order has been placed',
        };
        $message = match (true) {
            $returned => 'Contact our store for help with the returned parcel and any applicable refund.',
            $cancelled => 'Contact our store if you need help with this order. Refunds are confirmed separately.',
            $shipment?->state === 'delivery_issue' => 'Please contact our store for help with the courier update below.',
            $needsPayment => 'Your online payment is awaiting verification. Complete payment to confirm this order.',
            $order->status === 'delivered' => 'Thank you for shopping with us. We hope you love your new denim.',
            $order->status === 'shipped' => 'Your parcel has been dispatched. Follow the delivery updates below.',
            default => 'Thank you for shopping with us. We’re getting your denim ready.',
        };
        return compact('heading', 'message', 'stage', 'needsPayment', 'cancelled', 'returned') + [
            'courier' => $order->courier ?: $shipment?->courier,
            'trackingNumber' => $order->tracking_number ?: $shipment?->awb,
            'trackingUrl' => self::trackingUrl($order->tracking_url),
            'events' => array_slice(is_array($shipment?->tracking_events) ? $shipment->tracking_events : [], 0, 50),
        ];
    }

    public static function trackingUrl(?string $url): ?string
    {
        if (! $url || strlen($url) > 500 || ! filter_var($url, FILTER_VALIDATE_URL)) return null;
        $parts = parse_url($url);
        if (($parts['scheme'] ?? '') !== 'https' || isset($parts['user']) || isset($parts['pass']) || isset($parts['port'])) return null;
        $host = $parts['host'] ?? '';
        if (! preg_match('/^(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z]{2,63}$/i', $host)) return null;
        return $url;
    }

    public static function image(OrderItem $item): ?string
    {
        $product = $item->variant?->product;
        if (! $product) return null;
        $photo = $product->images->first(fn ($image) => $image->color === $item->color);
        $path = $photo?->path;
        // A generic product photo is used only when its sole colour matches this order.
        if (! $path && $product->variants->pluck('color')->unique()->values()->all() === [$item->color]) {
            $path = $product->image_path;
            if (! $path && $product->is_demo && preg_match('/^[a-z0-9-]+$/', $product->slug)) {
                return asset('images/demo/'.$product->slug.'.svg');
            }
        }
        if (! is_string($path) || ! preg_match('~^(?:[a-zA-Z0-9_-]+/)*[a-zA-Z0-9_-][a-zA-Z0-9_.-]*\.(?:jpe?g|png|webp)$~i', $path)) return null;
        return asset('storage/'.$path);
    }
}
