<?php
namespace App\Support;
use App\Models\StoreSetting;
use App\Services\Shiprocket;
use Illuminate\Support\Facades\Cache;
class Shipping {
 public static function parcel(StoreSetting $s,int $units=1):array {return ['weight'=>max(0.1,(int)($s->shipping_unit_grams??700)*max(1,$units)/1000),'length'=>(int)($s->shipping_length_cm??30),'breadth'=>(int)($s->shipping_breadth_cm??25),'height'=>(int)($s->shipping_height_cm??5)*max(1,$units)];}
 public static function snapshot(StoreSetting $s,int $units=1):array {return ['provider'=>$s->shipping_provider??'manual','fallback'=>(bool)$s->shipping_manual_fallback,'pickup_name'=>$s->shipping_pickup_name,'pickup_pincode'=>$s->shipping_pickup_pincode,'parcel'=>self::parcel($s,$units)];}
 public static function availability(string $pin,StoreSetting $s,int $units=1,int $value=0):array {
  $manual=Delivery::manualAvailability($pin,$s);if(($s->shipping_provider??'manual')!=='shiprocket'||!$s->checkout_enabled||!preg_match('/^[0-9]{6}$/',$pin))return [...$manual,'provider'=>'manual','estimate'=>null];
  $snapshot=self::snapshot($s,$units);
  try {
   if(!preg_match('/^[0-9]{6}$/',(string)$s->shipping_pickup_pincode)||!filled($s->shipping_pickup_name))throw new \RuntimeException('Pickup not configured');
   $client=app(Shiprocket::class);$key='logistics.availability.'.hash('sha256',json_encode([$snapshot,$pin,$value,config('services.shiprocket.email')]));
   $data=Cache::remember($key,now()->addSeconds(60),function()use($client,$pin,$s,$snapshot,$value){$online=$client->rates($s->shipping_pickup_pincode,$pin,$snapshot['parcel'],false,$value);$cod=$s->cod_enabled?$client->rates($s->shipping_pickup_pincode,$pin,$snapshot['parcel'],true,$value):[];return ['available'=>count($online)>0||count($cod)>0,'cod'=>count($cod)>0,'prepaid'=>count($online)>0,'estimate'=>($online[0]??$cod[0])['estimate']??null];});
   return [...$data,'provider'=>'shiprocket'];
  } catch(\Throwable) {return $s->shipping_manual_fallback?[...$manual,'provider'=>'manual','estimate'=>null,'fallback'=>true]:['available'=>false,'cod'=>false,'prepaid'=>false,'provider'=>'shiprocket','estimate'=>null];}
 }
}
