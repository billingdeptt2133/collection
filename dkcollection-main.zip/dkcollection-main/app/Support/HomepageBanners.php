<?php

namespace App\Support;

use App\Models\{Banner, Category, StoreSetting};

class HomepageBanners
{
    public const SLOTS = ['main', 'promotional'];

    /** Store local destinations as paths so they survive a domain move. */
    public static function destination(?string $value): ?string
    {
        $value = trim($value ?? '');
        if ($value === '' || strlen($value) > 2048) return null;
        $decoded = rawurldecode($value);
        if (preg_match('/[\x00-\x20\x7f\\\\]/', $value) || preg_match('/[\x00-\x1f\x7f\\\\]/', $decoded)) return null;
        if (str_starts_with($value, '/')) {
            return str_starts_with($decoded, '//') ? null : $value;
        }
        $parts = parse_url($value);
        $app = parse_url(config('app.url'));
        if (! is_array($parts) || ! is_array($app)
            || ! in_array(strtolower($parts['scheme'] ?? ''), ['http', 'https'], true)
            || strtolower($parts['host'] ?? '') !== strtolower($app['host'] ?? '')
            || isset($parts['user']) || isset($parts['pass'])
            || ($parts['port'] ?? null) !== ($app['port'] ?? null)) return null;
        $path = $parts['path'] ?? '/';
        if (str_starts_with(rawurldecode($path), '//')) return null;

        return $path.(isset($parts['query']) ? '?'.$parts['query'] : '').(isset($parts['fragment']) ? '#'.$parts['fragment'] : '');
    }

    public static function imagePath(mixed $value): ?string
    {
        return is_string($value) && preg_match('~^(?:banners|homepage/(?:banners|editorial|image-banners))/(?:main/|promotional/)?[A-Za-z0-9_-]+\.(?:jpe?g|png|webp)$~i', $value) ? $value : null;
    }

    /** Read legacy images until each slot is saved; never expose legacy banner copy. */
    public static function forStore(StoreSetting $store): array
    {
        $homepage = $store->homepage ?? [];
        $saved = $homepage['image_banners'] ?? [];
        $legacyMain = array_key_exists('main', $saved) ? null : Banner::where('is_active', true)->orderBy('sort_order')->orderBy('id')->first();
        $design = $homepage['design'] ?? [];
        $category = ! array_key_exists('promotional', $saved) && ! empty($design['promo_category_id'])
            ? Category::whereKey($design['promo_category_id'])->where('is_active', true)->first() : null;
        $legacy = [
            'main' => ['desktop_image' => $legacyMain?->image_path, 'mobile_image' => $legacyMain?->mobile_image_path, 'destination_url' => $legacyMain?->link_url],
            'promotional' => [
                'desktop_image' => ($design['promo_visible'] ?? true) ? ($design['promo_image'] ?? null) : null,
                'mobile_image' => $design['promo_mobile_image'] ?? null,
                'destination_url' => $category ? '/?category='.$category->slug.'#new-arrivals' : '/#new-arrivals',
            ],
        ];
        $result = [];
        foreach (self::SLOTS as $slot) {
            $data = $saved[$slot] ?? $legacy[$slot];
            $result[$slot] = [
                'desktop_image' => self::imagePath($data['desktop_image'] ?? null),
                'mobile_image' => self::imagePath($data['mobile_image'] ?? null),
                'destination_url' => self::destination($data['destination_url'] ?? null) ?? '/#new-arrivals',
            ];
        }

        return $result;
    }
}
