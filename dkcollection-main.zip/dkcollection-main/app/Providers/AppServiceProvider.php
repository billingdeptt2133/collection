<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\View;
use App\Models\StoreSetting;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        \Illuminate\Support\Facades\RateLimiter::for('admin-workspace', fn (\Illuminate\Http\Request $r) => \Illuminate\Cache\RateLimiting\Limit::perMinute(120)->by('admin:'.$r->user()?->id));
        \Illuminate\Support\Facades\RateLimiter::for('admin-confirm', fn (\Illuminate\Http\Request $r) => \Illuminate\Cache\RateLimiting\Limit::perMinute(5)->by('confirm:'.$r->user()?->id.'|'.$r->ip()));
        \Illuminate\Support\Facades\RateLimiter::for('admin-code-send', fn (\Illuminate\Http\Request $r) => \Illuminate\Cache\RateLimiting\Limit::perMinute(2)->by('send:'.$r->user()?->id));
        \Illuminate\Support\Facades\RateLimiter::for('admin-code-verify', fn (\Illuminate\Http\Request $r) => \Illuminate\Cache\RateLimiting\Limit::perMinute(5)->by('verify:'.$r->user()?->id));
        View::composer('layout', fn ($view) => $view->with('store', StoreSetting::first() ?? new StoreSetting));
    }
}

