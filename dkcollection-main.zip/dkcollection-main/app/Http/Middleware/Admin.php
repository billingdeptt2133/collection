<?php

namespace App\Http\Middleware;
use App\Support\AdminAccess;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Symfony\Component\HttpFoundation\Response;
class Admin {
    public function handle(Request $request,Closure $next):Response {
        $user=$request->user();
        abort_unless($user?->is_admin,403);
        $route=$request->route()->getName();
        $security=in_array($route,['admin.security','admin.security.confirm','admin.security.send','admin.security.verify'],true);
        if(!$security) {
            abort_unless(AdminAccess::allows($user,AdminAccess::section($route)),403);
            // Support staff can read orders, but cannot fulfil, cancel or collect payment.
            if($user->admin_role==='support'&&!$request->isMethod('GET')&&str_starts_with($route,'admin.orders.'))abort(403);
            $version=(int)$user->admin_session_version;
            if(($request->session()->has('admin_version')&&(int)$request->session()->get('admin_version')!==$version)||(!$request->session()->has('admin_version')&&$version>0)) {
                $request->session()->forget(['admin_confirmed','admin_mfa_verified']);
                $request->session()->put('admin_version',-1);
                return redirect()->route('admin.security');
            } $request->session()->put('admin_version',$version);
            if($user->admin_mfa_enabled&&($request->session()->get('admin_mfa_user')!==$user->id||time()-(int)$request->session()->get('admin_mfa_verified',0)>28800))return redirect()->route('admin.security');
        } $response=$next($request);
        if(!$request->isMethod('GET')&&$response->getStatusCode()<400&&!$request->session()->has('errors')) {
            $ids=$request->attributes->get('admin_audit',[]);
            foreach($request->route()->parameters() as $key=>$value) {
                if($value instanceof \Illuminate\Database\Eloquent\Model)$ids[$key]=$value->getKey();elseif(is_numeric($value))$ids[$key]=(int)$value;
            }
            DB::table('admin_audits')->insert(['user_id'=>$user->id,'action'=>$route,'context'=>json_encode($ids),'created_at'=>now(),'updated_at'=>now()]);
        } $response->headers->set('Cache-Control','no-store, private');
        return $response;
    }
}
