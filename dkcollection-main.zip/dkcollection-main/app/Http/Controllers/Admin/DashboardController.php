<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Banner;
use App\Models\Category;
use App\Models\Coupon;
use App\Models\Order;
use App\Models\Product;
use App\Models\ProductImage;
use App\Models\Review;
use App\Models\StoreSetting;
use App\Models\ShippingPincode;
use App\Models\User;
use App\Models\Variant;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Arr;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;
use Illuminate\View\View;

class DashboardController extends Controller
{
    public function index(): View
    {
        return view('admin.dashboard', [
            'store' => StoreSetting::first() ?? new StoreSetting,
            'pincodes' => ShippingPincode::orderBy('pincode')->paginate(30, ['*'], 'zones'),
            'customers' => User::latest()->paginate(20, ['*'], 'customers'),
            'products' => Product::with(['variants', 'images'])->latest()->paginate(20),
            'categories' => Category::orderBy('sort_order')->get(),
            'banners' => Banner::orderBy('sort_order')->get(),
            'coupons' => Coupon::latest()->get(),
            'orders' => Order::latest()->paginate(20, ['*'], 'orders'),
            'reviews' => Review::where('is_approved', false)->latest()->paginate(20, ['*'], 'reviews'),
        ]);
    }

    public function showOrder(Order $order): View
    {
        return view('admin.order', ['order' => $order->load('items')]);
    }

    public function customer(User $user): View
    {
        abort_if($user->is_admin,403);
        return view('admin.customer', ['customer' => $user, 'orders' => Order::where('user_id', $user->id)->latest()->paginate(20)]);
    }

    public function product(Request $request, ?Product $product = null): RedirectResponse
    {
        foreach (['price', 'mrp'] as $field) {
            if (! $request->exists($field.'_rupees')) continue;
            $value = trim((string) $request->input($field.'_rupees'));
            if ($value === '' && $field === 'mrp') { $request->merge(['mrp_paise' => null]); continue; }
            if (! preg_match('/^\d{1,7}(?:\.\d{1,2})?$/', $value))
                throw ValidationException::withMessages([$field.'_rupees' => 'Enter a valid rupee amount with up to two decimals.']);
            [$rupees, $paise] = array_pad(explode('.', $value, 2), 2, '');
            $request->merge([$field.'_paise' => (int) $rupees * 100 + (int) str_pad($paise, 2, '0')]);
        }
        if ($request->has('colours')) {
            if ($product) $request->validate(['stock_snapshot' => ['required', 'string', 'size:64']]);
            $grid = $request->validate([
                'colours' => ['required', 'array', 'min:1', 'max:6'],
                'colours.*' => ['array:name,sizes,photos'],
                'colours.*.name' => ['required', 'string', 'regex:/^[\pL\pN .-]{1,50}$/u'],
                'colours.*.sizes' => ['required', 'array', 'min:1', 'max:20'],
                'colours.*.sizes.*' => ['array:size,stock,shade_code,barcode'],
                'colours.*.sizes.*.size' => ['required', 'string', 'regex:/^[\pL\pN .-]{1,20}$/u'],
                'colours.*.sizes.*.stock' => ['required', 'integer', 'between:0,100000'],
                'colours.*.sizes.*.shade_code' => ['nullable', 'string', 'max:30', 'regex:/^[^,\r\n]*$/'],
                'colours.*.sizes.*.barcode' => ['nullable', 'string', 'regex:/^[A-Za-z0-9-]{1,64}$/'],
                'colours.*.photos' => ['nullable', 'array', 'max:5'],
                'colours.*.photos.*' => ['image', 'mimes:jpg,jpeg,png,webp', 'max:4096', 'dimensions:max_width=4096,max_height=4096'],
            ]);
            $names = collect($grid['colours'])->map(fn($c) => mb_strtolower(trim($c['name'])));
            if ($names->unique()->count() !== $names->count())
                throw ValidationException::withMessages(['colours' => 'Colour names must be unique.']);
            $lines = [];
            foreach ($grid['colours'] as $colour) foreach ($colour['sizes'] as $size) {
                $lines[] = implode(',', [trim($size['size']), trim($colour['name']), $size['stock'], $size['shade_code'] ?? '', $size['barcode'] ?? '']);
            }
            $request->merge(['variants' => implode("\n", $lines)]);
        }
        $data = $request->validate([
            'title' => ['required', 'string', 'max:180'], 'category_id' => ['nullable', 'exists:categories,id'],
            'description' => ['nullable', 'string', 'max:5000'],
            'product_code' => ['nullable', 'string', 'max:64'], 'article_code' => ['nullable', 'string', 'max:64'],
            'pattern' => ['nullable', 'string', 'max:64'],
            'seo_title' => ['nullable', 'string', 'max:70'], 'seo_description' => ['nullable', 'string', 'max:160'], 'price_paise' => ['required', 'integer', 'between:1,100000000'],
            'mrp_paise' => ['nullable', 'integer', 'gte:price_paise'], 'image' => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:4096', 'dimensions:max_width=4096,max_height=4096'],
            'gallery_color' => ['nullable', 'string', 'max:50'],
            'stock_snapshot' => ['nullable','string','size:64'], 'variants' => ['required', 'string', 'max:16000'], 'images' => ['nullable', 'array', 'max:5'],
            'images.*' => ['image', 'mimes:jpg,jpeg,png,webp', 'max:4096', 'dimensions:max_width=4096,max_height=4096'], 'is_active' => ['sometimes', 'boolean'],
        ]);
        $variants = collect(preg_split('/\r?\n/', trim($data['variants'])))->map(function ($line) {
            $parts = array_map('trim', explode(',', $line));
            if (! in_array(count($parts), [3, 5], true) || ! preg_match('/^[\pL\pN .-]{1,20}$/u', $parts[0]) ||
                ! preg_match('/^[\pL\pN .-]{1,50}$/u', $parts[1]) || ! ctype_digit($parts[2]) || (int) $parts[2] > 100000)
                throw ValidationException::withMessages(['variants' => 'Use Size,Color,Stock,Shade,Barcode per line (last two optional).']);
            if (count($parts) === 5 && (mb_strlen($parts[3]) > 30 || ($parts[4] !== '' && ! preg_match('/^[A-Za-z0-9-]{1,64}$/', $parts[4]))))
                throw ValidationException::withMessages(['variants' => 'Shade must be at most 30 characters; barcode must be letters, numbers or hyphens.']);
            return ['size' => $parts[0], 'color' => $parts[1], 'stock' => (int) $parts[2],
                'shade_code' => ($parts[3] ?? '') === '' ? null : $parts[3],
                'barcode' => ($parts[4] ?? '') === '' ? null : $parts[4]];
        });
        if ($variants->count() > 120 || $variants->unique(fn ($v) => $v['size'].'|'.$v['color'])->count() !== $variants->count())
            throw ValidationException::withMessages(['variants' => 'Maximum 120 unique variants.']);
        $barcodes = $variants->pluck('barcode')->filter(fn ($barcode) => $barcode !== null);
        if ($barcodes->unique()->count() !== $barcodes->count())
            throw ValidationException::withMessages(['variants' => 'Each barcode must be unique.']);
        foreach ($variants as $variant) {
            if ($variant['barcode'] === null) continue;
            $existing = Variant::where('barcode', $variant['barcode'])->first();
            if ($existing && (! $product || $existing->product_id !== $product->id || $existing->size !== $variant['size'] || $existing->color !== $variant['color']))
                throw ValidationException::withMessages(['variants' => 'A barcode is already assigned to another size or product.']);
        }
        $galleryColor = trim((string) ($data['gallery_color'] ?? ''));
        if ($galleryColor !== '' && ! $variants->contains(fn ($variant) => $variant['color'] === $galleryColor))
            throw ValidationException::withMessages(['gallery_color' => 'Choose a colour listed in this product’s variants.']);
        $data['gallery_color'] = $galleryColor === '' ? null : $galleryColor;

        $uploaded = [];
        try { DB::transaction(function () use ($request, $data, $product, $variants, &$uploaded) {
            $record = $product ? Product::whereKey($product->id)->lockForUpdate()->firstOrFail() : new Product;
            $lockedVariants = $record->exists ? $record->variants()->orderBy('id')->lockForUpdate()->get() : collect();
            if ($product && isset($data['stock_snapshot'])) abort_unless(hash_equals(hash('sha256', $lockedVariants->map(fn($v)=>$v->id.':'.$v->stock)->implode('|')), $data['stock_snapshot']), 409, 'Stock changed while you edited. Reload the product.');
            $record->fill(collect($data)->except(['image', 'images', 'variants', 'gallery_color', 'stock_snapshot'])->all());
            if (! $product) $record->slug = Str::slug($data['title']).'-'.Str::lower(Str::random(6));
            if ($request->hasFile('image')) { $record->image_path = $request->file('image')->store('products', 'public'); $uploaded[] = $record->image_path; }
            $record->is_active = (bool) ($data['is_active'] ?? false);
            $record->save();
            $request->attributes->set('admin_audit',['product'=>$record->id]);
            if ($request->hasFile('images')) {
                if ($record->images()->count() + count($request->file('images')) > 30)
                    throw ValidationException::withMessages(['images' => 'Maximum 30 gallery images per product.']);
                foreach ($request->file('images') as $image) { $path = $image->store('products', 'public'); $uploaded[] = $path; $record->images()->create(['path'=>$path,'color'=>$data['gallery_color']]); }
            }
            $colourUploads = collect($request->file('colours', []))->sum(fn($c) => count($c['photos'] ?? []));
            if ($record->images()->count() + $colourUploads > 30)
                throw ValidationException::withMessages(['colours' => 'Maximum 30 gallery photos per product.']);
            foreach ($request->file('colours', []) as $index => $files) {
                $colour = trim($request->input("colours.$index.name"));
                foreach ($files['photos'] ?? [] as $photo) {
                    $path = $photo->store('products', 'public'); $uploaded[] = $path;
                    $record->images()->create(['path' => $path, 'color' => $colour]);
                }
            }
            foreach ($variants as $variant) {
                $old = $lockedVariants->first(fn($v)=>$v->size===$variant['size'] && $v->color===$variant['color']);
                $saved = $record->variants()->updateOrCreate(['size'=>$variant['size'],'color'=>$variant['color']], Arr::only($variant,['stock','shade_code','barcode']));
                $delta = (int)$saved->stock - (int)($old?->stock ?? 0);
                if ($delta) DB::table('stock_movements')->insert(['variant_id'=>$saved->id,'user_id'=>$request->user()->id,'change'=>$delta,'stock_after'=>$saved->stock,'reason'=>'Product editor','created_at'=>now(),'updated_at'=>now()]);
            }
            $keys = $variants->map(fn ($v) => $v['size'].'|'.$v['color'])->all();
            foreach ($record->variants as $variant)
                if (! in_array($variant->size.'|'.$variant->color, $keys, true) && $variant->stock > 0) {
                    DB::table('stock_movements')->insert(['variant_id'=>$variant->id,'user_id'=>$request->user()->id,'change'=>-$variant->stock,'stock_after'=>0,'reason'=>'Variant removed from product editor','created_at'=>now(),'updated_at'=>now()]);
                    $variant->update(['stock'=>0]);
                }
        }); } catch (\Throwable $e) { foreach ($uploaded as $path) Storage::disk('public')->delete($path); throw $e; }

        return redirect()->route('admin.products.edit', $request->attributes->get('admin_audit')['product'])->with('message', 'Product saved.');
    }

    public function category(Request $request): RedirectResponse
    {
        $data = $request->validate(['name' => ['required', 'string', 'max:100']]);
        Category::create(['name' => $data['name'], 'slug' => Str::slug($data['name']).'-'.Str::lower(Str::random(5)), 'is_active' => true]);

        return back()->with('message', 'Category added.');
    }

    public function banner(Request $request): RedirectResponse
    {
        $data = $request->validate(['title' => ['required', 'string', 'max:150'], 'subtitle' => ['nullable', 'string', 'max:250'],
            'image' => ['required', 'image', 'mimes:jpg,jpeg,png,webp', 'max:4096', 'dimensions:max_width=4096,max_height=4096'],
            'link_url' => ['nullable', 'regex:/^\/(?!\/)[a-zA-Z0-9\/_#?=&-]*$/'], 'is_active' => ['sometimes', 'boolean']]);
        Banner::create(['title' => $data['title'], 'subtitle' => $data['subtitle'] ?? null,
            'image_path' => $request->file('image')->store('banners', 'public'),
            'link_url' => $data['link_url'] ?? '/', 'is_active' => (bool) ($data['is_active'] ?? false)]);

        return back()->with('message', 'Banner added.');
    }

    public function updateCategory(Request $request, Category $category): RedirectResponse
    {
        $data = $request->validate(['name' => ['required', 'string', 'max:100'], 'is_active' => ['sometimes', 'boolean']]);
        $category->update(['name' => $data['name'], 'is_active' => (bool) ($data['is_active'] ?? false)]);

        return back()->with('message', 'Category updated.');
    }

    public function updateBanner(Request $request, Banner $banner): RedirectResponse
    {
        $data = $request->validate(['title' => ['required', 'string', 'max:150'], 'subtitle' => ['nullable', 'string', 'max:250'],
            'image' => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:4096', 'dimensions:max_width=4096,max_height=4096'],
            'link_url' => ['nullable', 'regex:/^\/(?!\/)[a-zA-Z0-9\/_#?=&-]*$/'], 'is_active' => ['sometimes', 'boolean']]);
        $banner->update(['title' => $data['title'], 'subtitle' => $data['subtitle'] ?? null,
            'link_url' => $data['link_url'] ?? '/', 'is_active' => (bool) ($data['is_active'] ?? false),
            'image_path' => $request->hasFile('image') ? $request->file('image')->store('banners', 'public') : $banner->image_path]);

        return back()->with('message', 'Banner updated.');
    }

    public function toggleCoupon(Coupon $coupon): RedirectResponse
    {
        $coupon->update(['is_active' => ! $coupon->is_active]);

        return back()->with('message', 'Coupon updated.');
    }

    public function updateImageColor(Request $request, ProductImage $image): RedirectResponse
    {
        $data = $request->validate(['color' => ['nullable', 'string', 'max:50']]);
        $color = trim((string) ($data['color'] ?? ''));
        if ($color !== '' && ! Variant::where('product_id', $image->product_id)->where('color', $color)->exists())
            throw ValidationException::withMessages(['color' => 'This colour does not belong to this product.']);
        $image->update(['color' => $color === '' ? null : $color]);

        return back()->with('message', 'Photo colour updated.');
    }

    public function deleteImage(ProductImage $image): RedirectResponse
    {
        $path = $image->path;
        $image->delete();
        Storage::disk('public')->delete($path);

        return back()->with('message', 'Gallery image removed.');
    }

    public function archiveDemos(): RedirectResponse
    {
        Product::where('is_demo', true)->update(['is_active' => false]);

        return back()->with('message', 'All demo products archived. Real products remain unchanged.');
    }

    public function archiveProduct(Product $product): RedirectResponse
    {
        $product->update(['is_active' => false]);

        return back()->with('message', 'Product archived.');
    }

    public function coupon(Request $request): RedirectResponse
    {
        $request->merge(['code' => strtoupper(trim((string) $request->input('code')))]);
        $data = $request->validate(['code' => ['required', 'alpha_dash', 'max:40', 'unique:coupons,code'], 'discount_type'=>['sometimes','in:fixed,percent'], 'percentage'=>['required_if:discount_type,percent','nullable','integer','between:1,100'], 'maximum_paise'=>['nullable','integer','between:1,100000000'], 'starts_at'=>['nullable','date'], 'discount_paise' => ['required', 'integer', 'between:0,100000000'],
            'minimum_paise' => ['required', 'integer', 'between:0,100000000'], 'usage_limit' => ['nullable', 'integer', 'min:1'], 'expires_at' => ['nullable', 'date', 'after:now']]);
        if (($data['discount_type'] ?? 'fixed') === 'fixed' && (int)$data['discount_paise'] < 1) throw ValidationException::withMessages(['discount_paise'=>'Fixed discount must be positive.']);
        if (!empty($data['starts_at']) && !empty($data['expires_at']) && strtotime($data['starts_at']) >= strtotime($data['expires_at'])) throw ValidationException::withMessages(['starts_at'=>'Start must precede expiry.']);
        Coupon::create([...$data, 'code' => strtoupper($data['code']), 'is_active' => true]);

        return back()->with('message', 'Coupon added.');
    }

    public function order(Request $request, Order $order): RedirectResponse
    {
        $data = $request->validate(['status' => ['required', Rule::in(['pending', 'processing', 'shipped', 'delivered', 'cancelled'])]]);
        DB::transaction(function () use ($order, $data) {
            $locked = Order::whereKey($order->id)->lockForUpdate()->firstOrFail();
            abort_if($locked->shipping_provider==='shiprocket'&&in_array($data['status'],['shipped','delivered'],true),409,'Carrier tracking controls this shipment status.');
            abort_if($data['status']==='cancelled'&&\App\Models\Shipment::where('order_id',$locked->id)->exists(),409,'Resolve the booked carrier shipment before cancellation.');
            if (in_array($locked->status, ['cancelled', 'delivered'], true)) abort(409, 'Order is final.');
            abort_if(DB::table('order_returns')->where('order_id',$locked->id)->where('kind','cancellation')->exists(),409,'Cancellation is queued; fulfilment is blocked.');
            if ($locked->payment_method === 'razorpay' && $locked->payment_status !== 'paid' && $data['status'] !== 'pending')
                abort(409, 'Capture and verify online payment before fulfilling this order.');
            if ($locked->status === 'shipped' && ! in_array($data['status'], ['shipped', 'delivered'], true))
                abort(409, 'A shipped order cannot return to an earlier status.');
            if ($data['status'] === 'cancelled') {
                if ($locked->payment_method === 'razorpay') abort(409, 'Reconcile online payment before cancellation.');
                if (! in_array($locked->status, ['pending', 'processing'], true)) abort(409, 'Shipped order cannot be cancelled here.');
                foreach ($locked->items()->orderBy('variant_id')->get() as $item)
                    if ($item->variant_id) {
                        $v=Variant::whereKey($item->variant_id)->lockForUpdate()->firstOrFail();$v->increment('stock',$item->quantity);
                        DB::table('stock_movements')->insert(['variant_id'=>$v->id,'user_id'=>auth()->id(),'change'=>$item->quantity,'stock_after'=>$v->stock,'reason'=>'Cancelled order #'.$locked->id,'created_at'=>now(),'updated_at'=>now()]);
                    }
                if ($locked->coupon_id) Coupon::whereKey($locked->coupon_id)->where('used_count', '>', 0)->decrement('used_count');
            }
            $locked->update($data);
        });

        return back()->with('message', 'Order updated.');
    }

    public function review(Review $review): RedirectResponse
    {
        $review->forceFill(['is_approved'=>true,'rejected_at'=>null])->save();

        return back()->with('message', 'Review approved.');
    }
    public function rejectReview(Review $review): RedirectResponse
    {
        $review->forceFill(['is_approved'=>false,'rejected_at'=>now()])->save();

        return back()->with('message', 'Review rejected.');
    }
}

