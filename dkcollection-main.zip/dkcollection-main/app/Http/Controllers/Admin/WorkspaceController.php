<?php

namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\Models\{
    Product,Category,Coupon,Order,Review,User,Variant,StoreSetting,ShippingPincode
};
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;
class WorkspaceController extends Controller {
    public function dashboard():View {
        $scope=\App\Support\AdminAccess::allows(auth()->user(),'reports');
        return view('admin.dashboard',['financial'=>$scope,'paid'=>$scope?(int)Order::where('payment_status','paid')->sum('total_paise'):0,'orders'=>\App\Support\AdminAccess::allows(auth()->user(),'orders')?Order::latest()->limit(8)->get():collect(),'pending'=>Order::where('status','pending')->count(),'low'=>\App\Support\AdminAccess::allows(auth()->user(),'stock')?Variant::with('product')->whereHas('product')->where('stock','<=',5)->orderBy('stock')->limit(8)->get():collect(),'productCount'=>Product::count(),'orderCount'=>Order::count()]);
    }
    public function page(Request $r,string $section):View {
        abort_unless(in_array($section,['products','categories','coupons','orders','customers','reviews','settings','delivery','payments','stock','returns','reports','access','activity'],true),404);
        abort_unless(\App\Support\AdminAccess::allows($r->user(),$section),403);
        $r->validate(['q'=>['nullable','string','max:100'],'status'=>['nullable','string','max:30'],'from'=>['nullable','date'],'to'=>['nullable','date','after_or_equal:from']]);
        $data=['section'=>$section];
        $q=trim((string)$r->query('q',''));
        switch($section) {
            case 'products':$query=Product::with(['category','variants','images'])->withSum('variants','stock');
            if($q!=='')$query->where(fn($b)=>$b->where('title','like','%'.$q.'%')->orWhere('article_code','like','%'.$q.'%')->orWhere('product_code','like','%'.$q.'%'));
            if(in_array($r->status,['live','draft'],true))$query->where('is_active',$r->status==='live');
            $data['products']=$query->latest()->paginate(20)->withQueryString();
            $data['categories']=Category::orderBy('sort_order')->get();
            break;
            case 'categories':$data['categories']=Category::orderBy('sort_order')->get();
            break;
            case 'coupons':$data['coupons']=Coupon::latest()->paginate(20);
            break;
            case 'orders':case 'payments':case 'reports':$query=Order::query();
            if($q!=='')$query->where(fn($b)=>$b->where('id',$q)->orWhere('name','like','%'.$q.'%')->orWhere('phone','like','%'.$q.'%'));
            if($r->filled('from'))$query->where('created_at','>=',$r->date('from')->startOfDay());
            if($r->filled('to'))$query->where('created_at','<=',$r->date('to')->endOfDay());
            if(in_array($r->status,['pending','processing','shipped','delivered','cancelled'],true))$query->where('status',$r->status);
            if(in_array($r->query('payment'),['paid','pending'],true))$query->where('payment_status',$r->query('payment'));
            $data['collected']=(int)(clone $query)->where('payment_status','paid')->sum('total_paise');
            $data['refunds']=(int)DB::table('order_returns')->whereIn('refund_status',['processed','manual'])->whereIn('order_id',(clone $query)->select('id'))->sum('refund_paise');
            if($section==='reports') {
                $data['topVariants']=DB::table('order_items')->join('orders','orders.id','=','order_items.order_id')->whereIn('orders.id',(clone $query)->select('id'))->where('orders.payment_status','paid')->whereNotExists(fn($b)=>$b->selectRaw('1')->from('order_returns')->whereColumn('order_returns.order_id','orders.id')->whereIn('refund_status',['processed','manual']))->select('order_items.title','order_items.size','order_items.color')->selectRaw('SUM(order_items.quantity) AS units, SUM(order_items.quantity * order_items.price_paise) AS gross_paise')->groupBy('order_items.title','order_items.size','order_items.color')->orderByDesc('units')->limit(10)->get();
            } $data['orders']=$query->latest()->paginate(20)->withQueryString();
            $data['store']=StoreSetting::first()??new StoreSetting;
            break;
            case 'customers':$query=User::where('is_admin',false);
            if($q!=='')$query->where(fn($b)=>$b->where('name','like','%'.$q.'%')->orWhere('email','like','%'.$q.'%'));
            $data['customers']=$query->latest()->paginate(20)->withQueryString();
            break;
            case 'reviews':$query=Review::with('user');
            if($r->status==='rejected')$query->whereNotNull('rejected_at');
            else $query->whereNull('rejected_at')->where('is_approved',$r->status==='approved');
            $data['reviews']=$query->latest()->paginate(20)->withQueryString();
            break;
            case 'settings':case 'delivery':$data['store']=StoreSetting::first()??new StoreSetting;
            $data['pincodes']=ShippingPincode::orderBy('pincode')->paginate(30);
            break;
            case 'stock':$query=Variant::with('product')->whereHas('product');
            if($q!=='')$query->whereHas('product',fn($b)=>$b->where('title','like','%'.$q.'%')->orWhere('article_code','like','%'.$q.'%'));
            $data['variants']=$query->orderBy('stock')->paginate(30)->withQueryString();
            $data['movements']=DB::table('stock_movements')->orderByDesc('id')->limit(30)->get();
            break;
            case 'returns':$data['returns']=DB::table('order_returns')->join('orders','orders.id','=','order_returns.order_id')->select('order_returns.*','orders.payment_method','orders.payment_status','orders.total_paise')->orderByDesc('order_returns.id')->paginate(20);
            break;
            case 'access':$data['staff']=User::where('is_admin',true)->orderBy('name')->get();
            break;
            case 'activity':$data['audits']=DB::table('admin_audits')->leftJoin('users','users.id','=','admin_audits.user_id')->select('admin_audits.*','users.name')->orderByDesc('admin_audits.id')->paginate(30);
            break;
        }
        return view('admin.'.$section,$data);
    }
    public function productForm(?Product $product=null):View {
        return view('admin.product-edit',['product'=>$product?->load(['variants','images'])??new Product,'categories'=>Category::orderBy('name')->get()]);
    }
    public function export(Request $r) {
        \App\Support\AdminConfirmation::require($r);
        $r->validate(['from'=>['required','date'],'to'=>['required','date','after_or_equal:from']]);
        $query=Order::whereBetween('created_at',[$r->date('from')->startOfDay(),$r->date('to')->endOfDay()])->orderBy('id');
        return response()->streamDownload(function() use ($query) {
            $f=fopen('php://output','w');
            fputcsv($f,['Order','Created','Fulfilment','Payment method','Payment status','Total INR']);
            $query->chunkById(200,function($rows) use ($f) {
                foreach($rows as $o)fputcsv($f,[$o->id,$o->created_at->toIso8601String(),$o->status,$o->payment_method,$o->payment_status,number_format($o->total_paise/100,2,'.','')]);
            });
            fclose($f);
        },'orders.csv',['Content-Type'=>'text/csv','Cache-Control'=>'no-store, private']);
    }
}
