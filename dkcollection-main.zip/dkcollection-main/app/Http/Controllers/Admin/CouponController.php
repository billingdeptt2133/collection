<?php

namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\Models\Coupon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;
class CouponController extends Controller {
    public function update(Request $request,Coupon $coupon) {
        $request->merge(['code'=>strtoupper(trim((string)$request->input('code')))]);
        $data=$request->validate(['code'=>['required','alpha_dash','max:40',Rule::unique('coupons','code')->ignore($coupon->id)],'discount_type'=>['required','in:fixed,percent'],'discount_paise'=>['required','integer','between:0,100000000'],'percentage'=>['required_if:discount_type,percent','nullable','integer','between:1,100'],'maximum_paise'=>['nullable','integer','between:1,100000000'],'minimum_paise'=>['required','integer','between:0,100000000'],'usage_limit'=>['nullable','integer','min:1'],'starts_at'=>['nullable','date'],'expires_at'=>['nullable','date'],'is_active'=>['sometimes','boolean']]);
        if($data['discount_type']==='fixed'&&(int)$data['discount_paise']<1)throw ValidationException::withMessages(['discount_paise'=>'Fixed discount must be positive.']);
        if(!empty($data['starts_at'])&&!empty($data['expires_at'])&&strtotime($data['starts_at'])>=strtotime($data['expires_at']))throw ValidationException::withMessages(['starts_at'=>'Start must precede expiry.']);
        DB::transaction(function() use ($data,$coupon) {
            $locked=Coupon::whereKey($coupon->id)->lockForUpdate()->firstOrFail();
            if(($data['usage_limit']??null)!==null&&(int)$data['usage_limit']<$locked->used_count)throw ValidationException::withMessages(['usage_limit'=>'Limit cannot be below usage already recorded.']);
            $locked->update([...$data,'is_active'=>(bool)($data['is_active']??false)]);
        });
        return back()->with('message','Coupon updated. Existing order discounts remain unchanged.');
    }
}
