<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\StoreSetting;
use App\Support\HomepageBanners;
use Illuminate\Http\{RedirectResponse, Request};
use Illuminate\Support\Facades\{DB, Storage};
use Illuminate\View\View;

class HomepageController extends Controller
{
    public function index(): View
    {
        $store = StoreSetting::first() ?? new StoreSetting;

        return view('admin.homepage', ['imageBanners' => HomepageBanners::forStore($store)]);
    }

    public function saveBanner(Request $request, string $slot): RedirectResponse
    {
        abort_unless(in_array($slot, HomepageBanners::SLOTS, true), 404);
        $current = HomepageBanners::forStore(StoreSetting::first() ?? new StoreSetting)[$slot];
        $imageRules = ['image', 'mimes:jpg,jpeg,png,webp', 'max:4096', 'dimensions:max_width=4096,max_height=4096'];
        $data = $request->validate([
            $slot => ['required', 'array:desktop_image,mobile_image,destination_url'],
            "$slot.desktop_image" => [$current['desktop_image'] ? 'nullable' : 'required', ...$imageRules],
            "$slot.mobile_image" => ['nullable', ...$imageRules],
            "$slot.destination_url" => ['required', 'string', 'max:2048', function ($attribute, $value, $fail) {
                if (HomepageBanners::destination($value) === null) $fail('Use a page path or a full URL belonging to this store.');
            }],
        ])[$slot];
        $uploads = [];
        try {
            foreach (['desktop_image', 'mobile_image'] as $field) {
                if ($request->hasFile("$slot.$field")) {
                    $path = $request->file("$slot.$field")->store('homepage/image-banners/'.$slot, 'public');
                    if (! $path) throw new \RuntimeException('Unable to save banner image.');
                    $uploads[$field] = $path;
                }
            }
            DB::transaction(function () use ($slot, $data, $uploads) {
                $store = StoreSetting::firstOrCreate(['id' => 1]);
                $store = StoreSetting::whereKey($store->id)->lockForUpdate()->firstOrFail();
                $homepage = $store->homepage ?? [];
                $current = HomepageBanners::forStore($store)[$slot];
                $homepage['image_banners'][$slot] = array_replace($current, $uploads, [
                    'destination_url' => HomepageBanners::destination($data['destination_url']),
                ]);
                $store->homepage = $homepage;
                $store->save();
            });
        } catch (\Throwable $error) {
            Storage::disk('public')->delete(array_values($uploads));
            throw $error;
        }
        // Replaced files remain available for rollback; failed uploads are cleaned above.
        return redirect()->route('admin.homepage')->with('message', ($slot === 'main' ? 'Main' : 'Promotional').' banner saved.');
    }
}
