<?php

namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\Models\{
    Order,Variant
};
use App\Support\AdminConfirmation;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\{
    DB,Http
};
class OperationsController extends Controller {
    public function cancelOnline(Request $r,Order $order) {
        abort_unless(($r->user()->admin_role??'owner')==='owner',403);
        AdminConfirmation::require($r);
        $d=$r->validate(['reason'=>['required','string','max:500']]);
        DB::transaction(function() use ($order,$d) {
            $o=Order::whereKey($order->id)->lockForUpdate()->firstOrFail();
            abort_unless($o->payment_method==='razorpay'&&$o->payment_status==='paid'&&in_array($o->status,['pending','processing'],true),409);
            abort_if(\App\Models\Shipment::where('order_id',$o->id)->exists(),409,'Resolve the booked carrier shipment before cancellation.');
            abort_if(DB::table('order_returns')->where('order_id',$o->id)->exists(),409);
            DB::table('order_returns')->insert(['order_id'=>$o->id,'status'=>'received','kind'=>'cancellation','reason'=>$d['reason'],'created_at'=>now(),'updated_at'=>now()]);
        });
        return redirect()->route('admin.returns')->with('message','Online cancellation queued. Fulfilment is now blocked. Issue the full refund in Razorpay and verify its ID here to complete cancellation and restore stock.');
    }
    public function codRefund(Request $r,int $id) {
        abort_unless(($r->user()->admin_role??'owner')==='owner',403);
        AdminConfirmation::require($r);
        $d=$r->validate(['reference'=>['required','string','max:100'],'confirmed'=>['required','accepted']]);
        DB::transaction(function() use ($r,$d,$id) {
            $candidate=DB::table('order_returns')->where('id',$id)->first();
            abort_unless($candidate,404);
            $o=Order::whereKey($candidate->order_id)->lockForUpdate()->firstOrFail();
            $ret=DB::table('order_returns')->where('id',$id)->lockForUpdate()->first();
            abort_unless($ret->status==='received'&&!$ret->refund_status&&$o->payment_method==='cod'&&$o->payment_status==='paid',409);
            DB::table('order_returns')->where('id',$id)->update(['status'=>'refunded','manual_refund_reference'=>$d['reference'],'refund_status'=>'manual','refund_paise'=>$o->total_paise,'updated_at'=>now()]);
        });
        return back()->with('message','Full COD refund recorded as manually confirmed; this is not gateway verification.');
    }
    public function testGateway(Request $r) {
        AdminConfirmation::require($r);
        abort_unless(config('services.razorpay.key')&&config('services.razorpay.secret'),409,'Configure API keys on the server first.');
        try {
            $response=Http::withBasicAuth(config('services.razorpay.key'),config('services.razorpay.secret'))->timeout(10)->get('https://api.razorpay.com/v1/orders',['count'=>1]);
            if(!$response->successful())return back()->withErrors(['gateway'=>'Razorpay connection could not be verified. Check server credentials.']);
        }
        catch(\Throwable $e) {
            return back()->withErrors(['gateway'=>'Razorpay could not be reached. Try later.']);
        }
        return back()->with('message','Razorpay API credentials verified. Check webhook delivery separately in Razorpay.');
    }
    public function stock(Request $r,Variant $variant) {
        $d=$r->validate(['stock'=>['required','integer','between:0,100000'],'expected_stock'=>['required','integer','min:0'],'reason'=>['required','string','max:250']]);
        DB::transaction(function() use ($d,$variant,$r) {
            $v=Variant::whereKey($variant->id)->lockForUpdate()->firstOrFail();
            abort_unless($v->stock===$d['expected_stock']||(int)$v->stock===(int)$d['expected_stock'],409,'Stock changed. Reload before adjusting.');
            $delta=(int)$d['stock']-(int)$v->stock;
            $v->update(['stock'=>$d['stock']]);
            if($delta)DB::table('stock_movements')->insert(['variant_id'=>$v->id,'user_id'=>$r->user()->id,'change'=>$delta,'stock_after'=>$d['stock'],'reason'=>$d['reason'],'created_at'=>now(),'updated_at'=>now()]);
        });
        return back()->with('message','Stock adjusted.');
    }
    public function shipping(Request $r,Order $order) {
        $d=$r->validate(['action'=>['required','in:pack,ship,deliver,note'],'courier'=>['nullable','string','max:80'],'tracking_number'=>['nullable','string','max:100'],'tracking_url'=>['nullable','url:https','max:500'],'note'=>['nullable','string','max:2000']]);
        DB::transaction(function() use ($d,$order) {
            $o=Order::whereKey($order->id)->lockForUpdate()->firstOrFail();
            if($d['action']==='note') {
                $o->update(['admin_note'=>$d['note']??null]);
                return;
            }
            abort_if(DB::table('order_returns')->where('order_id',$o->id)->where('kind','cancellation')->exists(),409,'Cancellation is queued; fulfilment is blocked.');
            abort_if($o->payment_method==='razorpay'&&$o->payment_status!=='paid',409,'Online payment must be verified first.');
            abort_if($o->shipping_provider==='shiprocket'&&in_array($d['action'],['ship','deliver'],true),409,'Shiprocket status is updated through verified carrier tracking.');
            switch($d['action']) {
                case 'pack':abort_unless(in_array($o->status,['pending','processing'],true)&&!$o->packed_at,409);
                $o->update(['status'=>'processing','packed_at'=>now()]);
                break;
                case 'ship':abort_unless($o->status==='processing'&&$o->packed_at&&filled($d['courier']??null)&&filled($d['tracking_number']??null),409,'Pack first and enter courier and tracking number.');
                $o->update(['status'=>'shipped','shipped_at'=>now(),'courier'=>$d['courier'],'tracking_number'=>$d['tracking_number'],'tracking_url'=>$d['tracking_url']??null]);
                break;
                case 'deliver':abort_unless($o->status==='shipped',409);
                $o->update(['status'=>'delivered','delivered_at'=>now()]);
                break;
            }
        });
        return back()->with('message','Order fulfilment updated.');
    }
    public function cod(Request $r,Order $order) {
        AdminConfirmation::require($r);
        DB::transaction(function() use ($order) {
            $o=Order::whereKey($order->id)->lockForUpdate()->firstOrFail();
            abort_unless($o->payment_method==='cod'&&$o->status==='delivered'&&$o->payment_status==='pending',409);
            $o->update(['payment_status'=>'paid','cod_collected_at'=>now()]);
        });
        return back()->with('message','COD collection recorded.');
    }
    public function returnRequest(Request $r) {
        $d=$r->validate(['order_id'=>['required','integer','exists:orders,id'],'reason'=>['required','string','max:500']]);
        DB::transaction(function() use ($d) {
            $o=Order::whereKey($d['order_id'])->lockForUpdate()->firstOrFail();
            abort_unless($o->status==='delivered'||$o->shipment?->state==='rto',409,'Only delivered orders or verified RTO shipments can enter the return workflow.');
            abort_if(DB::table('order_returns')->where('order_id',$o->id)->exists(),409);
            DB::table('order_returns')->insert([...$d,'status'=>'requested','created_at'=>now(),'updated_at'=>now()]);
        });
        return back()->with('message','Return request recorded.');
    }
    public function returnUpdate(Request $r,int $id) {
        $d=$r->validate(['action'=>['required','in:approve,reject,receive'],'restock'=>['sometimes','boolean']]);
        DB::transaction(function() use ($d,$id,$r) {
            $candidate=DB::table('order_returns')->where('id',$id)->first();
            abort_unless($candidate,404);
            $o=Order::whereKey($candidate->order_id)->lockForUpdate()->firstOrFail();
            $ret=DB::table('order_returns')->where('id',$id)->lockForUpdate()->first();
            $status=match($d['action']) {
                'approve'=>'approved','reject'=>'rejected','receive'=>'received'
            };
            abort_unless(($ret->status==='requested'&&in_array($d['action'],['approve','reject'],true))||($ret->status==='approved'&&$d['action']==='receive'),409);
            $restock=$d['action']==='receive'&&($d['restock']??false);
            if($restock&&!$ret->restocked) {
                foreach($o->items()->orderBy('variant_id')->get() as $item) {
                    if(!$item->variant_id)continue;
                    $v=Variant::whereKey($item->variant_id)->lockForUpdate()->firstOrFail();
                    $v->increment('stock',$item->quantity);
                    DB::table('stock_movements')->insert(['variant_id'=>$v->id,'user_id'=>$r->user()->id,'change'=>$item->quantity,'stock_after'=>$v->stock,'reason'=>'Inspected return #'.$ret->id,'created_at'=>now(),'updated_at'=>now()]);
                }
            }
            if($d['action']==='receive'&&$o->shipment?->state==='rto'){$o->shipment->update(['state'=>'rto_received']);$o->update(['status'=>'cancelled']);}
            DB::table('order_returns')->where('id',$id)->update(['status'=>$status,'restocked'=>$restock||$ret->restocked,'updated_at'=>now()]);
        });
        return back()->with('message','Return updated.');
    } // Refunds are issued in the gateway dashboard; this endpoint reconciles a verified full refund.
    public function refund(Request $r,int $id) {
        abort_unless(($r->user()->admin_role??'owner')==='owner',403);
        AdminConfirmation::require($r);
        $d=$r->validate(['refund_id'=>['required','regex:/^rfnd_[A-Za-z0-9]+$/','max:100']]);
        $ret=DB::table('order_returns')->where('id',$id)->first();
        abort_unless($ret&&$ret->status==='received',409);
        $o=Order::findOrFail($ret->order_id);
        abort_unless($o->payment_method==='razorpay'&&$o->payment_status==='paid'&&$o->gateway_payment_id,409);
        abort_unless(config('services.razorpay.key')&&config('services.razorpay.secret'),409);
        $refund=Http::withBasicAuth(config('services.razorpay.key'),config('services.razorpay.secret'))->timeout(10)->get('https://api.razorpay.com/v1/payments/'.$o->gateway_payment_id.'/refunds/'.$d['refund_id'])->throw()->json();
        abort_unless(($refund['id']??null)===$d['refund_id']&&($refund['payment_id']??null)===$o->gateway_payment_id&&($refund['amount']??null)===$o->total_paise&&($refund['status']??null)==='processed',409,'Gateway must confirm the full refund as processed.');
        DB::transaction(function() use ($ret,$d,$o,$r) {
            $locked=Order::whereKey($o->id)->lockForUpdate()->firstOrFail();
            $rr=DB::table('order_returns')->where('id',$ret->id)->lockForUpdate()->first();
            abort_unless($rr->status==='received'&&!$rr->refund_id,409);
            if($rr->kind==='cancellation') {
                abort_unless(in_array($locked->status,['pending','processing'],true),409);
                if(!$rr->restocked)foreach($locked->items()->orderBy('variant_id')->get() as $item) {
                    if(!$item->variant_id)continue;
                    $v=Variant::whereKey($item->variant_id)->lockForUpdate()->firstOrFail();
                    $v->increment('stock',$item->quantity);
                    DB::table('stock_movements')->insert(['variant_id'=>$v->id,'user_id'=>$r->user()->id,'change'=>$item->quantity,'stock_after'=>$v->stock,'reason'=>'Refunded cancellation #'.$locked->id,'created_at'=>now(),'updated_at'=>now()]);
                }
                if($locked->coupon_id)\App\Models\Coupon::whereKey($locked->coupon_id)->where('used_count','>',0)->decrement('used_count');
                $locked->update(['status'=>'cancelled']);
            }
            DB::table('order_returns')->where('id',$ret->id)->update(['restocked'=>$rr->restocked||$rr->kind==='cancellation','status'=>'refunded','refund_id'=>$d['refund_id'],'refund_status'=>'processed','refund_paise'=>$locked->total_paise,'updated_at'=>now()]);
        });
        return back()->with('message','Verified gateway refund recorded.');
    }
}
