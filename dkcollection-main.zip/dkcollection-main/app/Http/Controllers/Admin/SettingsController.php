<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\ShippingPincode;
use App\Models\StoreSetting;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;

class SettingsController extends Controller
{
    public function update(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'support_phone'=>['nullable','regex:/^[0-9+() -]{7,20}$/'], 'whatsapp'=>['nullable','regex:/^[0-9]{7,15}$/'], 'store_address'=>['nullable','string','max:500'], 'shipping_policy'=>['nullable','string','max:5000'], 'return_policy'=>['nullable','string','max:5000'], 'privacy_policy'=>['nullable','string','max:10000'], 'terms_policy'=>['nullable','string','max:10000'],
            'name' => ['required', 'string', 'max:100'], 'announcement' => ['nullable', 'string', 'max:160'],
            'support_email' => ['nullable', 'email', 'max:255'], 'logo' => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:2048'],
            'delivery_mode' => ['required', 'in:all,allowlist'], 'flat_shipping_paise' => ['required', 'integer', 'between:0,100000'],
            'free_shipping_above_paise' => ['nullable', 'integer', 'between:0,100000000'],
            'cod_fee_paise' => ['required', 'integer', 'between:0,100000'],
            'checkout_enabled' => ['sometimes', 'boolean'], 'cod_enabled' => ['sometimes', 'boolean'],
            'online_enabled' => ['sometimes', 'boolean'],
        ]);
        if (($data['checkout_enabled'] ?? false) && $data['delivery_mode'] === 'allowlist' && ! ShippingPincode::where('is_active', true)->exists())
            throw ValidationException::withMessages(['delivery_mode' => 'Add an active delivery pincode before enabling checkout.']);
        if (($data['online_enabled'] ?? false) && (! config('services.razorpay.key') || ! config('services.razorpay.secret') || ! config('services.razorpay.webhook_secret')))
            throw ValidationException::withMessages(['online_enabled' => 'Set Razorpay API and webhook secrets on the server first.']);
        if (($data['checkout_enabled'] ?? false) && ! ($data['cod_enabled'] ?? false) && ! ($data['online_enabled'] ?? false))
            throw ValidationException::withMessages(['checkout_enabled' => 'Enable at least one payment method.']);
        $settings = StoreSetting::firstOrCreate(['id' => 1]);
        $settings->fill(collect($data)->except('logo')->all());
        foreach (['checkout_enabled', 'cod_enabled', 'online_enabled'] as $field) $settings->$field = (bool) ($data[$field] ?? false);
        if ($request->hasFile('logo')) $settings->logo_path = $request->file('logo')->store('brand', 'public');
        $settings->save();

        return back()->with('message', 'Store settings saved.');
    }

    public function pincode(Request $request): RedirectResponse
    {
        $data = $request->validate(['pincode' => ['required', 'regex:/^[0-9]{6}$/'], 'cod_available' => ['sometimes', 'boolean']]);
        ShippingPincode::updateOrCreate(['pincode' => $data['pincode']], ['is_active' => true, 'cod_available' => (bool) ($data['cod_available'] ?? false)]);

        return back()->with('message', 'Delivery pincode saved.');
    }

    public function toggle(ShippingPincode $pincode): RedirectResponse
    {
        $pincode->update(['is_active' => ! $pincode->is_active]);

        return back()->with('message', 'Pincode updated.');
    }
}
