<?php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\{Product,ProductImage};
use App\Support\AdminConfirmation;
use Illuminate\Http\{Request,RedirectResponse};
use Illuminate\Support\Facades\{DB,Storage};
use Illuminate\Validation\ValidationException;
use Illuminate\View\View;

class ProductRecycleBinController extends Controller
{
    public function index(Request $request): View
    {
        $data=$request->validate(['q'=>['nullable','string','max:100']]);
        $query=Product::onlyTrashed()->with('category')->withCount('variants');
        if($q=trim($data['q']??'')) $query->where(fn($b)=>$b->where('title','like','%'.addcslashes($q,'%_\\').'%')->orWhere('article_code','like','%'.addcslashes($q,'%_\\').'%'));
        $products=$query->orderByDesc('deleted_at')->orderByDesc('id')->paginate(20)->withQueryString();
        $orderedIds=DB::table('variants')->join('order_items','order_items.variant_id','=','variants.id')
            ->whereIn('variants.product_id',$products->pluck('id'))->distinct()->pluck('variants.product_id')->all();
        return view('admin.product-bin',compact('products','orderedIds'));
    }
    public function trash(Request $request, Product $product): RedirectResponse
    {
        DB::transaction(function() use($request,$product){
            $record=Product::whereKey($product->id)->lockForUpdate()->firstOrFail();
            // Keep stock and variant IDs intact for pending orders, refunds and restoration.
            $record->variants()->orderBy('id')->lockForUpdate()->get();
            $record->is_active=false;$record->save();$record->delete();
            $request->attributes->set('admin_audit',['product'=>$record->id]);
        });
        return redirect()->route('admin.products.recycle-bin')->with('message','Product moved to Recycle Bin. All its colours are hidden from the store.');
    }
    public function restore(Request $request, Product $product): RedirectResponse
    {
        DB::transaction(function() use($request,$product){
            $record=Product::onlyTrashed()->whereKey($product->id)->lockForUpdate()->firstOrFail();
            $record->is_active=false;$record->restore();
            $request->attributes->set('admin_audit',['product'=>$record->id]);
        });
        return redirect()->route('admin.products.edit',$product->id)->with('message','Product restored as a draft. Check its photos and stock, then publish when ready.');
    }
    public function destroy(Request $request, Product $product): RedirectResponse
    {
        if($request->session()->get('admin_confirmed_user')!==$request->user()->id || time()-(int)$request->session()->get('admin_confirmed',0)>=900){
            return redirect()->route('admin.security')->withErrors(['confirmation'=>'Confirm your password first, then return to Recycle Bin. Nothing was deleted.']);
        }
        AdminConfirmation::require($request);
        $request->validate(['confirmation'=>['required','in:DELETE']]);
        $paths=DB::transaction(function() use($request,$product){
            $record=Product::withTrashed()->whereKey($product->id)->lockForUpdate()->firstOrFail();
            if(!$record->trashed()) throw ValidationException::withMessages(['product'=>'Move this product to Recycle Bin before permanently deleting it.']);
            $ids=$record->variants()->orderBy('id')->lockForUpdate()->pluck('id');
            if(DB::table('order_items')->whereIn('variant_id',$ids)->exists()){
                throw ValidationException::withMessages(['product'=>'This product is linked to an order and cannot be permanently deleted. Keep it in Recycle Bin or restore it. Order history is protected.']);
            }
            $paths=$record->images()->pluck('path')->push($record->image_path)->filter()->unique()->all();
            $request->attributes->set('admin_audit',['product'=>$record->id]);
            $record->forceDelete();return $paths;
        });
        foreach($paths as $path){
            if(!preg_match('~^products/[a-zA-Z0-9_-]+\.(?:jpe?g|png|webp)$~i',$path))continue;
            if(Product::withTrashed()->where('image_path',$path)->exists()||ProductImage::where('path',$path)->exists())continue;
            Storage::disk('public')->delete($path);
        }
        return redirect()->route('admin.products.recycle-bin')->with('message','Product permanently deleted from Recycle Bin.');
    }
}
