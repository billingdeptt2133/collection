<?php

namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\Models\User;
use App\Support\AdminConfirmation;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\{
    Cache,DB,Hash,Mail,Password
};
class SecurityController extends Controller {
    public function index() {
        return view('admin.security');
    }
    public function confirm(Request $r) {
        $r->validate(['password'=>['required','string']]);
        if(!Hash::check($r->password,$r->user()->password))return back()->withErrors(['password'=>'Invalid password.']);
        $r->session()->regenerate();
        $r->session()->put(['admin_confirmed'=>time(),'admin_confirmed_user'=>$r->user()->id,'admin_version'=>(int)$r->user()->admin_session_version]);
        return back()->with('message','Password confirmed for 15 minutes.');
    }
    public function send(Request $r) {
        AdminConfirmation::require($r);
        if(app()->isProduction()&&in_array(config('mail.default'),['log','array'],true))return back()->withErrors(['email'=>'Configure outgoing email on the server before enabling two-step verification.']);
        $code=(string)random_int(100000,999999);
        $nonce=bin2hex(random_bytes(24));
        $key='admin-otp:'.$nonce;
        Cache::put($key,['user'=>$r->user()->id,'hash'=>Hash::make($code),'attempts'=>0,'expires'=>time()+300],now()->addMinutes(5));
        try {
            Mail::raw('Your DK admin verification code is '.$code.'. It expires in 5 minutes. Do not share it.',fn($m)=>$m->to($r->user()->email)->subject('DK admin verification'));
        }
        catch(\Throwable $e) {
            Cache::forget($key);
            report($e);
            return back()->withErrors(['email'=>'Verification email could not be sent.']);
        }
        if($old=$r->session()->get('admin_otp'))Cache::forget('admin-otp:'.$old);
        $r->session()->put('admin_otp',$nonce);
        return back()->with('message','Verification code sent to your account email.');
    }
    public function verify(Request $r) {
        AdminConfirmation::require($r);
        $r->validate(['code'=>['required','digits:6']]);
        $key='admin-otp:'.$r->session()->get('admin_otp','');
        $ok=Cache::lock($key.':lock',5)->block(3,function() use ($r,$key) {
            $entry=Cache::get($key);
            if(!$entry||$entry['user']!==$r->user()->id||$entry['attempts']>=5||$entry['expires']<time())return false;
            if(!Hash::check($r->code,$entry['hash'])) {
                $entry['attempts']++;
                Cache::put($key,$entry,\Illuminate\Support\Carbon::createFromTimestamp($entry['expires']));
                return false;
            }
            Cache::forget($key);
            return true;
        });
        if(!$ok)return back()->withErrors(['code'=>'Invalid or expired code. Request a new code after five failed attempts.']);
        $r->user()->forceFill(['admin_mfa_enabled'=>true])->save();
        $r->session()->forget('admin_otp');
        $r->session()->regenerate();
        $r->session()->put(['admin_mfa_verified'=>time(),'admin_mfa_user'=>$r->user()->id]);
        return redirect()->route('admin.dashboard')->with('message','Email two-step verification enabled and verified.');
    }
    public function access(Request $r) {
        AdminConfirmation::require($r);
        $d=$r->validate(['email'=>['required','email','exists:users,email'],'role'=>['required','in:owner,catalog,orders,support,none']]);
        DB::transaction(function() use ($d,$r) {
            $staff=User::where('is_admin',true)->orderBy('id')->lockForUpdate()->get();
            $u=User::where('email',$d['email'])->lockForUpdate()->firstOrFail();
            abort_if($u->id===$r->user()->id,409,'You cannot change your own access here.');
            if($u->is_admin&&($u->admin_role??'owner')==='owner'&&$d['role']!=='owner')abort_unless($staff->filter(fn($v)=>($v->admin_role??'owner')==='owner')->count()>1,409,'Keep at least one owner.');
            $u->forceFill(['is_admin'=>$d['role']!=='none','admin_role'=>$d['role']==='none'?null:$d['role'],'admin_session_version'=>(int)$u->admin_session_version+1])->save();
            DB::table('sessions')->where('user_id',$u->id)->delete();
            $r->attributes->set('admin_audit',['user'=>$u->id,'role'=>$d['role']]);
        });
        return back()->with('message','Access updated and existing sessions revoked.');
    }
    public function revoke(Request $r,User $user) {
        AdminConfirmation::require($r);
        abort_unless($user->is_admin,404);
        DB::transaction(function() use ($user) {
            $locked=User::whereKey($user->id)->lockForUpdate()->firstOrFail();
            $locked->forceFill(['admin_session_version'=>(int)$locked->admin_session_version+1,'remember_token'=>null])->save();
            DB::table('sessions')->where('user_id',$locked->id)->delete();
        });
        return back()->with('message','Admin sessions revoked.');
    }
    public function reset(Request $r,User $user) {
        AdminConfirmation::require($r);
        abort_if($user->is_admin,403);
        if(app()->isProduction()&&in_array(config('mail.default'),['log','array'],true))return back()->withErrors(['email'=>'Configure email recovery on the server first.']);
        Password::sendResetLink(['email'=>$user->email]);
        return back()->with('message','Password reset link requested. Password is never shown to admin.');
    }
}
