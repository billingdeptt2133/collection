<?php

namespace App\Http\Controllers;

use App\Models\Coupon;
use App\Models\Order;
use App\Models\StoreSetting;
use App\Support\Delivery;
use App\Models\Variant;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Validation\ValidationException;
use Illuminate\View\View;

class CheckoutController extends Controller
{
    public function form(Request $request): View|RedirectResponse
    {
        $context = $request->query('mode') === 'buy-now' ? 'buy_now' : 'cart';
        $lines = CartController::lines($request, $context);
        if ($lines->isEmpty()) return redirect()->route('cart');

        if ($request->session()->get('checkout_context', 'cart') !== $context) {
            $request->session()->forget(['checkout_token', 'checkout_details', 'checkout_login_draft']);
        }
        $request->session()->put('checkout_context', $context);
        $request->session()->put('checkout_token', $request->session()->get('checkout_token') ?: (string) \Illuminate\Support\Str::uuid());

        $draft = $request->session()->get('checkout_details', $request->session()->get('checkout_login_draft', []));
        if (! is_array($draft) || (isset($draft['user_id']) && $draft['user_id'] !== $request->user()?->id)) $draft = [];

        return view('checkout', ['lines' => $lines, 'draft' => $draft, 'store' => StoreSetting::first() ?? new StoreSetting]);
    }

    public function place(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'name' => ['required', 'string', 'max:100'],
            'phone' => ['required', 'regex:/^[0-9+() -]{7,20}$/'],
            'address' => ['required', 'string', 'max:500'],
            'city' => ['required', 'string', 'max:100'],
            'state' => ['required', 'string', 'max:100'],
            'pincode' => ['required', 'regex:/^[0-9]{6}$/'],
            'coupon' => ['nullable', 'string', 'max:40'],
            'payment_method' => ['required', 'in:cod,razorpay'],
            'checkout_token' => ['required', 'uuid'],
            'expected_total_paise' => ['nullable', 'integer', 'min:0'],
        ]);
        if ($data['payment_method'] === 'razorpay' && (! config('services.razorpay.key') || ! config('services.razorpay.secret')))
            throw ValidationException::withMessages(['payment_method' => 'Online payment is unavailable.']);
        if (! hash_equals((string) $request->session()->get('checkout_token'), $data['checkout_token']))
            throw ValidationException::withMessages(['cart' => 'Checkout expired. Please retry.']);
        $details = $request->session()->get('checkout_details');
        if (is_array($details) && (($details['user_id'] ?? null) !== $request->user()->id
            || ($details['context'] ?? null) !== $request->session()->get('checkout_context', 'cart')
            || time() - ($details['prepared_at'] ?? 0) > 1800)) {
            throw ValidationException::withMessages(['cart' => 'Checkout details expired. Please review your address and retry.']);
        }
        // Carrier calls happen before inventory locks. Locked settings/cart are compared below.
        $shippingSettings = StoreSetting::first() ?? new StoreSetting;
        $shippingCart = $request->session()->get($request->session()->get('checkout_context') === 'buy_now' ? 'buy_now' : 'cart', []);
        $shippingValue = is_array($shippingCart) ? (int)Variant::with('product')->whereIn('id', array_keys($shippingCart))->get()->sum(fn($v)=>($v->product?->price_paise??0)*(int)$shippingCart[$v->id]) : 0;
        $shippingUnits = is_array($shippingCart) ? array_sum(array_map('intval', $shippingCart)) : 0;
        $shippingSnapshot = \App\Support\Shipping::snapshot($shippingSettings, $shippingUnits);
        $carrierAvailable = ($shippingSettings->shipping_provider ?? 'manual') === 'shiprocket'
            ? \App\Support\Shipping::availability($data['pincode'], $shippingSettings, $shippingUnits, $shippingValue) : null;
        if (($carrierAvailable['provider'] ?? 'manual') === 'shiprocket') {
            $phone = preg_replace('/\D/', '', $data['phone']);
            if (strlen($phone) === 12 && str_starts_with($phone, '91')) $phone = substr($phone, 2);
            if (! preg_match('/^[6-9][0-9]{9}$/', $phone)) throw ValidationException::withMessages(['phone'=>'Enter a valid Indian mobile number for courier delivery.']);
            $data['phone'] = $phone;
        }
        [$order, $created] = DB::transaction(function () use ($request, $data, $shippingSnapshot, $carrierAvailable, $shippingCart, $shippingValue) {
            \App\Models\User::whereKey($request->user()->id)->lockForUpdate()->firstOrFail();
            $existing = Order::where('checkout_token', $data['checkout_token'])->where('user_id', $request->user()->id)->first();
            if ($existing) return [$existing, false];
            $cart = $request->session()->get($request->session()->get('checkout_context') === 'buy_now' ? 'buy_now' : 'cart', []);
            if (! is_array($cart) || ! $cart) throw ValidationException::withMessages(['cart' => 'Your cart is empty.']);
            $variants = Variant::with('product')->whereIn('id', array_keys($cart))->orderBy('id')->lockForUpdate()->get();
            if ($variants->count() !== count($cart)) throw ValidationException::withMessages(['cart' => 'Your cart has changed. Please review it.']);
            $subtotal = 0;
            foreach ($variants as $variant) {
                $quantity = (int) $cart[$variant->id];
                if (! $variant->product?->is_active || $quantity < 1 || $quantity > 10 || $variant->stock < $quantity)
                    throw ValidationException::withMessages(['cart' => 'An item is unavailable or out of stock. Please review your cart.']);
                $subtotal += $variant->product->price_paise * $quantity;
            }
            $coupon = null;
            if (filled($data['coupon'] ?? null)) {
                $coupon = Coupon::where('code', strtoupper(trim($data['coupon'])))->lockForUpdate()->first();
                if (! $coupon?->is_active || ($coupon->expires_at && $coupon->expires_at->isPast()) || ($coupon->starts_at && $coupon->starts_at->isFuture()) ||
                    $subtotal < $coupon->minimum_paise || ($coupon->usage_limit !== null && $coupon->used_count >= $coupon->usage_limit))
                    throw ValidationException::withMessages(['coupon' => 'Coupon is invalid or unavailable.']);
            }
            if ($carrierAvailable !== null && ($cart !== $shippingCart || $subtotal !== $shippingValue)) throw ValidationException::withMessages(['cart'=>'Your bag changed while checking delivery. Please review checkout.']);
            $discount = $coupon?->discount($subtotal) ?? 0;
            $settings = StoreSetting::lockForUpdate()->first() ?? new StoreSetting;
            if ($data['payment_method'] === 'razorpay' && ! $settings->online_enabled)
                throw ValidationException::withMessages(['payment_method' => 'Online payment is disabled.']);
            $currentSnapshot = \App\Support\Shipping::snapshot($settings, array_sum(array_map('intval', $cart)));
            if ($shippingSnapshot !== $currentSnapshot) throw ValidationException::withMessages(['cart'=>'Shipping settings changed. Review checkout again.']);
            $available = $carrierAvailable ?? Delivery::manualAvailability($data['pincode'], $settings);
            if ($data['payment_method'] === 'razorpay' && !($available['prepaid'] ?? true)) throw ValidationException::withMessages(['pincode'=>'Prepaid delivery is unavailable.']);
            if (! $available['available'] || ($data['payment_method'] === 'cod' && ! $available['cod']))
                throw ValidationException::withMessages(['pincode' => 'Delivery or selected payment is unavailable for this pincode.']);
            $fees = Delivery::fees($subtotal - $discount, $data['payment_method'], $settings);
            if ($data['payment_method'] === 'razorpay' && $subtotal - $discount + array_sum($fees) < 100)
                throw ValidationException::withMessages(['payment_method' => 'Choose COD for an order below ₹1.']);
            if (isset($data['expected_total_paise']) && (int) $data['expected_total_paise'] !== $subtotal - $discount + array_sum($fees)) {
                throw ValidationException::withMessages(['cart' => 'The total has changed. Please review the updated amount before ordering.']);
            }
            $order = Order::create([...\Illuminate\Support\Arr::only($data, ['name', 'phone', 'address', 'city', 'state', 'pincode', 'payment_method']), 'user_id' => $request->user()->id, 'checkout_token' => $data['checkout_token'], 'subtotal_paise' => $subtotal,
                'shipping_provider' => $available['provider'] ?? 'manual', 'shipping_snapshot' => json_encode([...$currentSnapshot, 'provider'=>$available['provider']??'manual']), 'discount_paise' => $discount, ...$fees, 'total_paise' => $subtotal - $discount + array_sum($fees), 'coupon_id' => $coupon?->id]);
            foreach ($variants as $variant) {
                $order->items()->create(['variant_id' => $variant->id, 'title' => $variant->product->title,
                    'size' => $variant->size, 'color' => $variant->color, 'price_paise' => $variant->product->price_paise,
                    'quantity' => $cart[$variant->id]]);
                $variant->decrement('stock', $cart[$variant->id]);
                DB::table('stock_movements')->insert(['variant_id'=>$variant->id,'user_id'=>null,'change'=>-(int)$cart[$variant->id],'stock_after'=>$variant->stock,'reason'=>'Reserved by order #'.$order->id,'created_at'=>now(),'updated_at'=>now()]);
            }
            if ($coupon) $coupon->increment('used_count');

            return [$order, true];
        }, 3);
        if (! $created) return redirect()->route('orders.show', $order);
        if ($order->payment_method === 'razorpay') {
            $order->update([
                'gateway_receipt' => $order->gateway_receipt ?: 'dk-'.$order->id,
                'gateway_order_state' => 'creating',
                'payment_expires_at' => now()->addMinutes((int) config('services.razorpay.reservation_minutes', 30)),
            ]);
            app(\App\Services\RazorpayPaymentLifecycle::class)->createGatewayOrder($order->id);
            $order->refresh();
        }
        $context = $request->session()->get('checkout_context') === 'buy_now' ? 'buy_now' : 'cart';
        $request->session()->forget([$context, 'checkout_token', 'checkout_context', 'checkout_details', 'checkout_login_draft']);

        return redirect()->route($order->payment_method === 'razorpay' && $order->gateway_order_id ? 'payments.show' : 'orders.show', $order)->with('message', $order->payment_method === 'cod' ? 'Order placed successfully.' : ($order->gateway_order_id ? 'Complete your payment to confirm the order.' : 'Your payment request is being verified. Please do not place the order again.'));
    }

    public function index(Request $request): View
    {
        return view('orders', ['orders' => Order::where('user_id', $request->user()->id)->latest()->paginate(15)]);
    }

    public function show(Request $request, Order $order): View
    {
        abort_unless($order->user_id === $request->user()->id, 404);

        $order->load(['items.variant.product.images', 'items.variant.product.variants', 'shipment']);
        return view('order', ['order' => $order, 'presentation' => \App\Support\OrderPresentation::data($order), 'store' => StoreSetting::first() ?? new StoreSetting]);
    }
}

