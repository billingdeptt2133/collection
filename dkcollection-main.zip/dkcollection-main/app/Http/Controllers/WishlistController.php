<?php

namespace App\Http\Controllers;

use App\Models\Product;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;

class WishlistController extends Controller
{
    public function index(Request $request): View
    {
        return view('wishlist', ['products' => Product::whereIn('id', DB::table('wishlists')->where('user_id', $request->user()->id)->select('product_id'))
            ->where('is_active', true)->paginate(20)]);
    }

    public function toggle(Request $request, Product $product): RedirectResponse
    {
        abort_unless($product->is_active, 404);
        $query = DB::table('wishlists')->where('user_id', $request->user()->id)->where('product_id', $product->id);
        if ($query->exists()) $query->delete();
        else DB::table('wishlists')->insertOrIgnore(['user_id' => $request->user()->id, 'product_id' => $product->id]);

        return back();
    }
}
