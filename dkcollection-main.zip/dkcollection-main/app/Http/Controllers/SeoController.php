<?php

namespace App\Http\Controllers;

use App\Models\Product;
use Illuminate\Http\Response;
use Symfony\Component\HttpFoundation\StreamedResponse;

class SeoController extends Controller
{
    public function sitemap(): StreamedResponse
    {
        return response()->stream(function () {
            echo '<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';
            $this->url(route('home'));
            Product::where('is_active', true)->where('is_demo', false)->select(['id', 'slug', 'updated_at'])->chunkById(500, function ($products) {
                foreach ($products as $product) $this->url(route('products.show', $product->slug), $product->updated_at?->toDateString());
            });
            echo '</urlset>';
        }, 200, ['Content-Type' => 'application/xml; charset=UTF-8', 'Cache-Control' => 'public, max-age=3600']);
    }

    private function url(string $link, ?string $modified = null): void
    {
        echo '<url><loc>'.htmlspecialchars($link, ENT_XML1, 'UTF-8').'</loc>';
        if ($modified) echo '<lastmod>'.$modified.'</lastmod>';
        echo '</url>';
    }

    public function robots(): Response
    {
        return response("User-agent: *\nDisallow: /admin\nDisallow: /cart\nDisallow: /checkout\nDisallow: /account\nDisallow: /login\nDisallow: /register\nDisallow: /orders\nDisallow: /wishlist\nSitemap: ".route('sitemap')."\n", 200, ['Content-Type' => 'text/plain; charset=UTF-8']);
    }
}
