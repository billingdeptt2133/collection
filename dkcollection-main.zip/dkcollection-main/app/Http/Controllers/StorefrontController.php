<?php

namespace App\Http\Controllers;

use App\Support\HomepageBanners;
use App\Models\Category;
use App\Models\Product;
use App\Models\Review;
use App\Models\StoreSetting;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Pagination\Paginator;

class StorefrontController extends Controller
{
    public function index(Request $request): View
    {
        $filters = $request->validate([
            'q' => ['nullable', 'string', 'max:80'],
            'category' => ['nullable', 'string', 'max:100'],
            'sort' => ['nullable', 'in:latest,price_asc,price_desc'],
            'page' => ['nullable', 'integer', 'min:1', 'max:10000'],
        ]);
        $store = StoreSetting::first() ?? new StoreSetting;
        $homepage = $store->homepage ?? [];
        $categories = Category::where('is_active', true)->orderBy('sort_order')->orderBy('id')->get();
        $selectedCategoryIds = $homepage['category_ids'] ?? [];
        $selectedCategories = is_array($selectedCategoryIds) ? array_slice(array_filter(array_map('intval', $selectedCategoryIds)), 0, 12) : [];
        $heroCategories = $selectedCategories ? $categories->whereIn('id', $selectedCategories) : $categories;
        $query = Product::query()->with(['variants', 'images'])->where('is_active', true)->whereHas('variants');
        if ($q = trim($filters['q'] ?? '')) $query->where('title', 'like', '%'.addcslashes($q, '%_\\').'%');
        if ($slug = $filters['category'] ?? null) $query->whereHas('category', fn ($q) => $q->where('slug', $slug)->where('is_active', true));
        if (! ($filters['q'] ?? null) && ! ($filters['category'] ?? null)) {
            $featuredValues = $homepage['featured_ids'] ?? [];
            $arrivalValues = $homepage['new_arrival_ids'] ?? [];
            $featuredIds = is_array($featuredValues) ? array_slice(array_values(array_filter(array_map('intval', $featuredValues))), 0, 24) : [];
            $newArrivalIds = is_array($arrivalValues) ? array_slice(array_values(array_filter(array_map('intval', $arrivalValues))), 0, 24) : [];
            if ($newArrivalIds) $query->whereIn('id', array_values(array_unique(array_merge($featuredIds, $newArrivalIds))));
            if ($featuredIds) $query->orderByRaw('CASE WHEN id IN ('.implode(',', array_fill(0, count($featuredIds), '?')).') THEN 0 ELSE 1 END', $featuredIds);
        }
        match ($filters['sort'] ?? 'latest') {
            'price_asc' => $query->orderBy('price_paise'),
            'price_desc' => $query->orderByDesc('price_paise'),
            default => $query->orderBy('sort_order')->orderByDesc('id'),
        };

        $videoReviews = collect($homepage['video_reviews'] ?? [])->filter(static function ($video) {
            return is_array($video)
                && isset($video['id'], $video['name'])
                && is_string($video['id']) && preg_match('/^[A-Za-z0-9_-]{11}$/', $video['id'])
                && is_string($video['name']) && mb_strlen($video['name']) <= 80;
        })->values();

        $page = (int) ($filters['page'] ?? 1);
        $perPage = $page === 1 ? 20 : 12;
        $offset = $page === 1 ? 0 : 20 + (($page - 2) * 12);
        $total = (clone $query)->count();
        $remainingPages = $total <= 20 ? 1 : 1 + (int) ceil(($total - 20) / 12);
        $paginationTotal = $page === 1 ? ($remainingPages > 1 ? 21 : $total) : 12 * $remainingPages;
        $pageProducts = (clone $query)->skip($offset)->take($perPage)->get();
        $products = new LengthAwarePaginator($pageProducts, $paginationTotal, $perPage, $page, [
            'path' => Paginator::resolveCurrentPath(),
            'query' => $request->query(),
        ]);

        $wishlistIds = $request->user()
            ? \Illuminate\Support\Facades\DB::table('wishlists')->where('user_id', $request->user()->id)->pluck('product_id')->map(fn ($id) => (int) $id)->all()
            : [];
        $cartCount = CartController::lines($request)->sum('quantity');

        return view('storefront', [
            'store' => $store, 'homepage' => $homepage, 'videoReviews' => $videoReviews, 'heroCategories' => $heroCategories,
            'imageBanners' => HomepageBanners::forStore($store),
            'categories' => $categories,
            'products' => $products, 'wishlistIds' => $wishlistIds, 'cartCount' => $cartCount,
            'reviews' => Review::with('user')->where('is_approved', true)->latest()->limit(3)->get(),
        ]);
    }

    public function product(Request $request, string $slug): View
    {
        $product = Product::where('slug', $slug)->where('is_active', true)
            ->with(['category', 'variants', 'images', 'approvedReviews'])->firstOrFail();

        $request->validate(['color'=>['nullable','string','max:50']]);
        $requestedColor = $request->query('color');
        $initialColor = $product->variants->contains(fn($v) => $v->color === $requestedColor)
            ? $requestedColor : ($product->variants->first(fn($v) => $v->stock > 0)?->color ?? $product->variants->first()?->color);
        $presentation = \App\Support\ProductPresentation::data($product);
        $presentation['initialColor'] = $initialColor;
        $wishlisted = auth()->check() && \Illuminate\Support\Facades\DB::table('wishlists')
            ->where('user_id', auth()->id())->where('product_id', $product->id)->exists();

        return view('product', compact('product', 'presentation', 'wishlisted', 'initialColor'));
    }
    public function availability(string $slug): \Illuminate\Http\JsonResponse
    {
        $product = Product::where('slug', $slug)->where('is_active', true)
            ->with('variants')->firstOrFail();

        return response()->json(['variants' => $product->variants->map(fn ($variant) => [
            'id' => $variant->id, 'size' => $variant->size,
            'color' => $variant->color, 'stock' => (int) $variant->stock,
        ])->values()])->header('Cache-Control', 'no-store, private');
    }

}
