<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Auth\Events\PasswordReset;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Password;
use Illuminate\Support\Str;
use Illuminate\Validation\Rules\Password as PasswordRule;
use Illuminate\View\View;

class PasswordController extends Controller
{
    public function requestForm(): View
    {
        return view('password.forgot');
    }

    public function email(Request $request): RedirectResponse
    {
        $data = $request->validate(['email' => ['required', 'email']]);
        if (app()->isProduction() && in_array(config('mail.default'), ['log', 'array'], true))
            return back()->withErrors(['email' => 'Email recovery is not configured yet. Contact store support.']);
        try { Password::sendResetLink($data); }
        catch (\Throwable $e) { report($e); return back()->withErrors(['email' => 'Email service is unavailable. Please try later.']); }

        return back()->with('message', 'If this account exists, a reset link has been sent.');
    }

    public function resetForm(Request $request, string $token): View
    {
        return view('password.reset', ['token' => $token, 'email' => $request->query('email')]);
    }

    public function reset(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'token' => ['required', 'string'], 'email' => ['required', 'email'],
            'password' => ['required', 'confirmed', PasswordRule::min(12)],
        ]);
        $status = Password::reset($data, function (User $user, string $password) {
            $user->forceFill(['password' => $password, 'remember_token' => Str::random(60)])->save();
            if ($user->is_admin) { User::whereKey($user->id)->increment('admin_session_version'); }
            \Illuminate\Support\Facades\DB::table('sessions')->where('user_id',$user->id)->delete();
            event(new PasswordReset($user));
        });
        if ($status !== Password::PasswordReset)
            return back()->withErrors(['email' => 'The reset link is invalid or has expired.']);

        return redirect()->route('login')->with('message', 'Password updated. You can log in now.');
    }
}
