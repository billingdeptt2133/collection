<?php

namespace App\Http\Controllers;

use App\Models\StoreSetting;
use Illuminate\View\View;

class StorePageController extends Controller
{
    public function show(string $page): View
    {
        $titles = ['about' => 'About Us', 'faqs' => 'FAQs', 'contact' => 'Contact Us', 'sustainability' => 'Sustainability', 'size-guide' => 'Size Guide'];
        abort_unless(isset($titles[$page]), 404);
        $store = StoreSetting::first() ?? new StoreSetting;
        $text = $store->homepage['footer'][$page] ?? '';
        if ($page !== 'contact') abort_unless(filled($text), 404);

        return view('store-page', ['store' => $store, 'page' => $page, 'pageTitle' => $titles[$page], 'pageText' => $text]);
    }
}
