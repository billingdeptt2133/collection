<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\StoreSetting;
use App\Support\CheckoutQuote;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Rules\Password;
use Illuminate\Validation\ValidationException;
use Illuminate\View\View;

class CheckoutDetailsController extends Controller
{
    private const FIELDS = ['name', 'phone', 'address', 'address2', 'city', 'state', 'pincode'];

    public function prepare(Request $request): RedirectResponse|JsonResponse
    {
        $rules = [
            'checkout_token' => ['required', 'uuid'],
            'name' => ['required', 'string', 'max:100'],
            'phone' => ['required', 'regex:/^[0-9+() -]{7,20}$/'],
            'address' => ['required', 'string', 'max:350'],
            'address2' => ['nullable', 'string', 'max:140'],
            'city' => ['required', 'string', 'max:100'],
            'state' => ['required', 'string', 'max:100'],
            'pincode' => ['required', 'regex:/^[0-9]{6}$/'],
        ];
        if (! $request->user()) {
            $rules['email'] = ['required', 'email', 'max:255', 'unique:users,email'];
            $rules['password'] = ['required', 'string', 'max:255', Password::min(12)];
        }
        $data = $request->validate($rules, ['email.unique' => 'Please log in to continue with an existing account.']);
        $this->checkToken($request, $data['checkout_token']);
        $quote = CheckoutQuote::calculate($request, $data['pincode']);
        if ($quote['shipping_provider'] === 'shiprocket') {
            $phone = preg_replace('/\\D/', '', $data['phone']);
            if (strlen($phone) === 12 && str_starts_with($phone, '91')) $phone = substr($phone, 2);
            if (! preg_match('/^[6-9][0-9]{9}$/', $phone)) throw ValidationException::withMessages(['phone'=>'Enter a valid Indian mobile number for courier delivery.']);
            $data['phone'] = $phone;
        }
        if (! $request->user()) {
            // The User model hashes the password; only account fields reach the users table.
            Auth::login(User::create(Arr::only($data, ['name', 'email', 'password'])));
            $request->session()->regenerate();
        }
        $request->session()->put('checkout_details', [...Arr::only($data, self::FIELDS),
            'user_id' => $request->user()->id, 'context' => $request->session()->get('checkout_context', 'cart'),
            'payment_method' => $quote['payment_method'], 'prepared_at' => time()]);
        $request->session()->forget('checkout_login_draft');
        $request->session()->put('checkout_token', (string) \Illuminate\Support\Str::uuid());

        if ($request->expectsJson()) {
            return response()->json(['redirect_url' => route('checkout.payment')])->header('Cache-Control', 'private, no-store');
        }
        return redirect()->route('checkout.payment');
    }

    public function account(Request $request): JsonResponse
    {
        $data = $request->validate([
            'checkout_token' => ['required', 'uuid'],
            'mode' => ['required', 'in:login,register'],
        ]);
        $this->checkToken($request, $data['checkout_token']);
        if (! (StoreSetting::first()?->checkout_enabled) || CartController::lines($request, $request->session()->get('checkout_context', 'cart'))->isEmpty()) {
            throw ValidationException::withMessages(['cart' => 'Checkout is unavailable. Please review your bag.']);
        }
        if (! $request->user()) {
            $rules = ['email' => ['required', 'email', 'max:255'], 'password' => ['required', 'string', 'max:255']];
            if ($data['mode'] === 'register') {
                $rules['name'] = ['required', 'string', 'max:100'];
                $rules['email'][] = 'unique:users,email';
                $rules['password'][] = Password::min(12);
            }
            $credentials = $request->validate($rules, ['email.unique' => 'This email already has an account. Please log in.']);
            if ($data['mode'] === 'register') {
                Auth::login(User::create(Arr::only($credentials, ['name', 'email', 'password'])));
            } elseif (! Auth::attempt(Arr::only($credentials, ['email', 'password']))) {
                throw ValidationException::withMessages(['email' => 'Email or password is incorrect.']);
            }
            $request->session()->regenerate();
            $request->session()->forget(['checkout_details', 'checkout_login_draft', 'url.intended']);
            $request->session()->put('checkout_token', (string) \Illuminate\Support\Str::uuid());
        }
        return response()->json([
            'user' => ['name' => $request->user()->name, 'email' => $request->user()->email],
            'csrf_token' => csrf_token(), 'checkout_token' => $request->session()->get('checkout_token'),
        ])->header('Cache-Control', 'private, no-store');
    }

    public function login(Request $request): RedirectResponse
    {
        $rules = array_fill_keys(self::FIELDS, ['nullable', 'string', 'max:500']);
        $rules['email'] = ['nullable', 'email', 'max:255'];
        $rules['checkout_token'] = ['required', 'uuid'];
        $data = $request->validate($rules);
        $this->checkToken($request, $data['checkout_token']);
        // Password is deliberately excluded from saved input and session state.
        $request->session()->put('checkout_login_draft', Arr::only($data, [...self::FIELDS, 'email']));
        $url = route('checkout', $request->session()->get('checkout_context') === 'buy_now' ? ['mode' => 'buy-now'] : []);
        if ($request->user()) return redirect()->to($url);
        $request->session()->put('url.intended', $url);

        return redirect()->route('login');
    }

    public function payment(Request $request): View|RedirectResponse
    {
        $details = $request->session()->get('checkout_details');
        $context = $request->session()->get('checkout_context', 'cart');
        if (! is_array($details) || ($details['user_id'] ?? null) !== $request->user()->id
            || ($details['context'] ?? null) !== $context || time() - ($details['prepared_at'] ?? 0) > 1800
            || ! $request->session()->get('checkout_token')) {
            return redirect()->route('checkout', $context === 'buy_now' ? ['mode' => 'buy-now'] : []);
        }
        $selection = $request->validate(['payment_method' => ['nullable', 'in:cod,razorpay'], 'coupon' => ['nullable', 'string', 'max:40']]);
        $couponCode = $selection['coupon'] ?? '';
        try {
            $quote = CheckoutQuote::calculate($request, $details['pincode'], $selection['payment_method'] ?? null, $couponCode);
        } catch (ValidationException $exception) {
            return redirect()->route('checkout', $context === 'buy_now' ? ['mode' => 'buy-now'] : [])->withErrors($exception->errors());
        }
        $lines = CartController::lines($request, $context);

        return view('checkout-payment', [...compact('lines', 'details', 'quote', 'couponCode'), 'store' => StoreSetting::first() ?? new StoreSetting]);
    }

    public function quote(Request $request): JsonResponse
    {
        $data = $request->validate([
            'pincode' => ['required', 'regex:/^[0-9]{6}$/'],
            'payment_method' => ['nullable', 'in:cod,razorpay'],
            'coupon' => ['nullable', 'string', 'max:40'],
            'checkout_token' => ['required', 'uuid'],
        ]);
        $this->checkToken($request, $data['checkout_token']);

        return response()->json(CheckoutQuote::calculate($request, $data['pincode'], $data['payment_method'] ?? null, $data['coupon'] ?? null))
            ->header('Cache-Control', 'private, no-store');
    }

    private function checkToken(Request $request, string $token): void
    {
        if (! hash_equals((string) $request->session()->get('checkout_token'), $token)) {
            throw ValidationException::withMessages(['cart' => 'Checkout expired. Please review your bag and retry.']);
        }
    }
}
