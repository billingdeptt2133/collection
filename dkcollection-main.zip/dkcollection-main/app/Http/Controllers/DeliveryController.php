<?php

namespace App\Http\Controllers;

use App\Models\StoreSetting;
use App\Support\Delivery;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class DeliveryController extends Controller
{
    public function check(Request $request): JsonResponse
    {
        $data = $request->validate(['pincode' => ['required', 'regex:/^[0-9]{6}$/']]);

        return response()->json(Delivery::availability($data['pincode'], StoreSetting::first() ?? new StoreSetting));
    }
}
