<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\StoreSetting;
use App\Services\RazorpayPaymentLifecycle;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Http;
use Illuminate\Validation\ValidationException;
use Illuminate\View\View;
use Throwable;

class PaymentController extends Controller
{
    public function show(Request $request, Order $order): View
    {
        abort_unless($order->user_id === $request->user()->id && $order->payment_method === 'razorpay'
            && $order->status === 'pending' && $order->payment_status === 'pending' && $order->gateway_order_id, 404);

        $order->load(['items.variant.product.images', 'items.variant.product.variants']);
        $store = StoreSetting::first() ?? new StoreSetting;

        return view('payment', compact('order', 'store'));
    }

    public function verify(Request $request, Order $order, RazorpayPaymentLifecycle $lifecycle): RedirectResponse
    {
        abort_unless($order->user_id === $request->user()->id && $order->payment_method === 'razorpay', 404);
        $data = $request->validate([
            'razorpay_payment_id' => ['required', 'string', 'regex:/^pay_[A-Za-z0-9]+$/', 'max:100'],
            'razorpay_order_id' => ['required', 'string', 'max:100'],
            'razorpay_signature' => ['required', 'regex:/^[a-f0-9]{64}$/i'],
        ]);
        $secret = (string) config('services.razorpay.secret');
        if (! $secret || ! hash_equals((string) $order->gateway_order_id, $data['razorpay_order_id']) ||
            ! hash_equals(hash_hmac('sha256', $order->gateway_order_id.'|'.$data['razorpay_payment_id'], $secret), $data['razorpay_signature'])) {
            throw ValidationException::withMessages(['payment' => 'Payment verification failed.']);
        }

        try {
            $payment = Http::withBasicAuth(config('services.razorpay.key'), $secret)
                ->timeout(10)->get('https://api.razorpay.com/v1/payments/'.$data['razorpay_payment_id'])->throw()->json();
        } catch (Throwable $e) {
            report($e);
            return redirect()->route('orders.show', $order)->with('message', 'Payment status is being verified. Please do not place the order again.');
        }

        if (($payment['status'] ?? '') !== 'captured') {
            return redirect()->route('orders.show', $order)->with('message', 'Payment is not confirmed yet. Your order is still being checked.');
        }

        $result = $lifecycle->settleCaptured($order, $payment);
        if (in_array($result, ['settled', 'already_settled'], true)) {
            return redirect()->route('orders.show', $order)->with('message', 'Payment verified.');
        }

        return redirect()->route('orders.show', $order)->with('message', 'Payment was received but needs order review. Support has been alerted.');
    }

    public function webhook(Request $request, RazorpayPaymentLifecycle $lifecycle): Response
    {
        $secret = (string) config('services.razorpay.webhook_secret');
        if (! $secret || ! hash_equals(hash_hmac('sha256', $request->getContent(), $secret), (string) $request->header('X-Razorpay-Signature'))) {
            abort(401);
        }

        $payload = $request->json()->all();
        $event = $payload['event'] ?? '';
        $payment = $payload['payload']['payment']['entity'] ?? [];
        $gatewayOrderId = $payment['order_id'] ?? null;
        $order = is_string($gatewayOrderId) ? Order::where('gateway_order_id', $gatewayOrderId)->first() : null;

        if ($event === 'payment.captured') {
            if ($order) {
                $lifecycle->settleCaptured($order, $payment);
            } else {
                $paymentId = is_string($payment['id'] ?? null) ? $payment['id'] : null;
                $lifecycle->raiseIssue(null, 'unmatched_captured_payment', $paymentId, is_string($gatewayOrderId) ? $gatewayOrderId : null);
            }
        } elseif ($order && in_array($event, ['payment.created', 'payment.authorized', 'payment.failed'], true)) {
            $lifecycle->observeNonCapturedPaymentEvent($order, $event, $payment);
        }

        return response('OK');
    }
}

