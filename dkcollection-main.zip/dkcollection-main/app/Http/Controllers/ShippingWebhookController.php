<?php
namespace App\Http\Controllers;
use App\Models\Shipment;
use Illuminate\Http\Request;
class ShippingWebhookController extends Controller {
 public function __invoke(Request $r){$secret=(string)config('services.shiprocket.webhook_secret');abort_unless(strlen($secret)>=32&&hash_equals($secret,(string)$r->header('x-api-key')),401);abort_unless(strlen($r->getContent())<=65536,413);$d=$r->validate(['awb'=>['required','string','max:100']]);
  // Notification only. A provider-authenticated GET verifies the actual status later.
  Shipment::where('awb',$d['awb'])->whereNotNull('provider_shipment_id')->where('state','!=','delivered')->update(['sync_requested_at'=>now()]);return response()->json(['received'=>true]);
 }
}
