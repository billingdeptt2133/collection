<?php

namespace App\Http\Controllers;

use App\Models\Variant;
use App\Models\Product;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Illuminate\View\View;

class CartController extends Controller
{
    public static function lines(Request $request, string $key = 'cart'): Collection
    {
        $cart = $request->session()->get($key, []);
        if (! is_array($cart)) return collect();
        return Variant::with(['product.images', 'product.variants'])->whereIn('id', array_keys($cart))->get()
            ->filter(fn ($variant) => $variant->product?->is_active && $variant->stock > 0)
            ->map(fn ($variant) => (object) [
                'variant' => $variant,
                'quantity' => min((int) ($cart[$variant->id] ?? 0), $variant->stock, 10),
            ])->filter(fn ($line) => $line->quantity > 0)->values();
    }

    public function index(Request $request): View
    {
        $lines = self::lines($request);
        $recommendations = Product::with(['images', 'variants'])->where('is_active', true)
            ->where('is_demo', false)->whereNotIn('id', $lines->pluck('variant.product.id'))
            ->whereHas('variants', fn ($query) => $query->where('stock', '>', 0))
            ->orderBy('sort_order')->orderBy('id')->limit(4)->get();

        return view('cart', compact('lines', 'recommendations'));
    }

    public function add(Request $request): RedirectResponse
    {
        $data = $request->validate(['variant_id' => ['required', 'integer', 'exists:variants,id'], 'quantity' => ['required', 'integer', 'between:1,10']]);
        $variant = Variant::with('product')->findOrFail($data['variant_id']);
        abort_unless($variant->product?->is_active && $variant->stock > 0, 404);
        $cart = $request->session()->get('cart', []);
        $cart[$variant->id] = min($variant->stock, 10, ($cart[$variant->id] ?? 0) + $data['quantity']);
        $request->session()->put('cart', $cart);
        $request->session()->forget(['checkout_token', 'checkout_context', 'checkout_details', 'checkout_login_draft']);

        return redirect()->route('cart')->with('message', 'Added to cart.');
    }

    public function buyNow(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'variant_id' => ['required', 'integer', 'exists:variants,id'],
            'quantity' => ['required', 'integer', 'between:1,10'],
        ]);
        $variant = Variant::with('product')->findOrFail($data['variant_id']);
        abort_unless($variant->product?->is_active && $variant->stock > 0, 404);
        if ($data['quantity'] > $variant->stock) {
            return back()->withErrors(['quantity' => 'The selected quantity is no longer available.'])->withInput();
        }
        $request->session()->put('buy_now', [$variant->id => $data['quantity']]);
        $request->session()->forget(['checkout_token', 'checkout_context', 'checkout_details', 'checkout_login_draft']);

        return redirect()->route('checkout', ['mode' => 'buy-now']);
    }

    public function update(Request $request, Variant $variant): RedirectResponse
    {
        $data = $request->validate([
            'quantity' => ['required', 'integer', 'between:0,10'],
            'variant_id' => ['nullable', 'integer', 'exists:variants,id'],
        ]);
        $cart = $request->session()->get('cart', []);
        if ($data['quantity'] === 0) {
            unset($cart[$variant->id]);
        } elseif (isset($cart[$variant->id])) {
            $target = isset($data['variant_id']) ? Variant::with('product')->findOrFail($data['variant_id']) : $variant->load('product');
            abort_unless($target->product_id === $variant->product_id && $target->product?->is_active, 404);
            if ($target->stock < $data['quantity']) {
                return back()->withErrors(['quantity' => 'The selected quantity is no longer available.']);
            }
            if ($target->id !== $variant->id) {
                $merged = (int) ($cart[$target->id] ?? 0) + $data['quantity'];
                if ($merged > min(10, $target->stock)) {
                    return back()->withErrors(['quantity' => 'This option is already in your bag. Reduce the quantity before merging.']);
                }
                unset($cart[$variant->id]);
                $cart[$target->id] = $merged;
            } else {
                $cart[$variant->id] = $data['quantity'];
            }
        }
        $request->session()->put('cart', $cart);
        $request->session()->forget(['checkout_token', 'checkout_context', 'checkout_details', 'checkout_login_draft']);

        return redirect()->route('cart');
    }
}
