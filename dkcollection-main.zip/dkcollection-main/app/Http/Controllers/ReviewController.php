<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\Product;
use App\Models\Review;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

class ReviewController extends Controller
{
    public function store(Request $request, Product $product): RedirectResponse
    {
        $data = $request->validate(['rating' => ['required', 'integer', 'between:1,5'], 'body' => ['nullable', 'string', 'max:2000']]);
        $purchased = Order::where('user_id', $request->user()->id)->where('status', 'delivered')
            ->whereHas('items', fn ($q) => $q->whereIn('variant_id', $product->variants()->select('id')))->exists();
        abort_unless($purchased, 403);
        Review::updateOrCreate(['user_id' => $request->user()->id, 'product_id' => $product->id], [...$data, 'is_approved' => false]);

        return back()->with('message', 'Review submitted for approval.');
    }
}
