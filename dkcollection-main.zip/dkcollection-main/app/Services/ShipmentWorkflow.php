<?php
namespace App\Services;
use App\Models\{Order,Shipment};
use Illuminate\Support\Facades\DB;
use RuntimeException;
class ShipmentWorkflow {
 public function __construct(private Shiprocket $api){}
 public function rates(Order $order,array $parcel):array {
  $snapshot=json_decode((string)$order->shipping_snapshot,true);abort_unless($order->shipping_provider==='shiprocket'&&is_array($snapshot),409);
  return $this->api->rates($snapshot['pickup_pincode'],$order->pincode,$parcel,$order->payment_method==='cod',$order->total_paise);
 }
 public function book(Order $order,array $parcel,int $courierId,?int $approvedCost=null):Shipment {
  $existing=Shipment::where('order_id',$order->id)->first();
  if($existing){abort_unless($existing->state==='created'&&!$existing->operation_state,409,'Booking already exists or needs reconciliation.');return $this->assign($existing,$courierId);}
  $rate=collect($this->rates($order,$parcel))->firstWhere('id',$courierId);abort_unless($rate,409,'Courier availability changed. Review rates again.');if($approvedCost!==null)abort_unless($rate['cost_paise']===$approvedCost,409,'Courier cost changed. Review rates again.');
  $s=DB::transaction(function()use($order,$parcel,$rate){$o=Order::whereKey($order->id)->lockForUpdate()->firstOrFail();
   abort_unless($o->shipping_provider==='shiprocket'&&$o->status==='processing'&&$o->packed_at&&($o->payment_method==='cod'||$o->payment_status==='paid'),409,'Pack and verify payment first.');
   abort_if(DB::table('order_returns')->where('order_id',$o->id)->where('kind','cancellation')->exists(),409,'Cancellation is queued.');
   abort_if(Shipment::where('order_id',$o->id)->exists(),409,'Booking already started.');
   return Shipment::create(['order_id'=>$o->id,'reference'=>'91001-'.$o->id,'parcel'=>$parcel,'courier_id'=>$rate['id'],'courier'=>$rate['name'],'quoted_cost_paise'=>$rate['cost_paise'],'state'=>'creating','operation'=>'create','operation_state'=>'pending']);
  });
  $o=$s->order->load('items');$snapshot=json_decode((string)$o->shipping_snapshot,true);
  $phone=preg_replace('/\D/','',$o->phone);if(strlen($phone)===12&&str_starts_with($phone,'91'))$phone=substr($phone,2);
  if(!preg_match('/^[6-9][0-9]{9}$/',$phone)){$s->update(['state'=>'needs_review','operation_state'=>'uncertain']);throw new RuntimeException('Use a valid Indian mobile number before booking.');}
  try {
   $r=$this->api->request('POST','orders/create/adhoc',['order_id'=>$s->reference,'order_date'=>$o->created_at->format('Y-m-d H:i'),'pickup_location'=>$snapshot['pickup_name'],'billing_customer_name'=>$o->name,'billing_last_name'=>'','billing_address'=>$o->address,'billing_city'=>$o->city,'billing_pincode'=>$o->pincode,'billing_state'=>$o->state,'billing_country'=>'India','billing_email'=>DB::table('users')->where('id',$o->user_id)->value('email'),'billing_phone'=>$phone,'shipping_is_billing'=>true,'order_items'=>$o->items->map(fn($i)=>['name'=>$i->title.' / '.$i->size.' / '.$i->color,'sku'=>'DK-'.($i->variant_id??$i->id),'units'=>$i->quantity,'selling_price'=>$i->price_paise/100])->all(),'payment_method'=>$o->payment_method==='cod'?'COD':'Prepaid','shipping_charges'=>$o->shipping_paise/100,'transaction_charges'=>$o->cod_fee_paise/100,'total_discount'=>$o->discount_paise/100,'sub_total'=>$o->subtotal_paise/100,...$parcel]);
   if(!is_numeric($r['order_id']??null)||!is_numeric($r['shipment_id']??null))throw new RuntimeException('Booking response needs verification.');
   $provider=$this->api->request('GET','orders/show/'.(int)$r['order_id'])['data']??[];
   if((string)($provider['channel_order_id']??'')!==$s->reference||abs((float)($provider['total']??-1)-$o->total_paise/100)>=0.01)throw new RuntimeException('Provider order total does not match.');
   $s->update(['provider_order_id'=>(int)$r['order_id'],'provider_shipment_id'=>(int)$r['shipment_id'],'state'=>'created','operation'=>null,'operation_state'=>null]);
  }catch(\Throwable){$s->update(['state'=>'needs_review','operation_state'=>'uncertain']);throw new RuntimeException('Booking needs reconciliation. Do not create another parcel; check Shiprocket for reference '.$s->reference.'.');}
  return $this->assign($s,$courierId);
 }
 private function begin(Shipment $s,string $operation):Shipment {return DB::transaction(function()use($s,$operation){$o=Order::whereKey($s->order_id)->lockForUpdate()->firstOrFail();abort_if(in_array($o->status,['cancelled','delivered'],true),409);$locked=Shipment::whereKey($s->id)->lockForUpdate()->firstOrFail();abort_if($locked->operation_state,409,'Previous operation must be verified before retrying.');abort_if(DB::table('order_returns')->where('order_id',$o->id)->where('kind','cancellation')->exists(),409);if($operation==='awb')abort_unless($locked->state==='created'&&!$locked->awb,409);if($operation==='pickup')abort_unless($locked->awb&&!$locked->pickup_requested_at&&$locked->state==='booked',409);$locked->update(['operation'=>$operation,'operation_state'=>'pending']);return $locked;});}
 public function assign(Shipment $s,int $courierId):Shipment {
  abort_unless($s->state==='created'&&!$s->awb&&(int)$s->courier_id===$courierId,409);$s=$this->begin($s,'awb');
  try{$r=$this->api->request('POST','courier/assign/awb',['shipment_id'=>$s->provider_shipment_id,'courier_id'=>$courierId]);$d=$r['response']['data']??[];if((int)($r['awb_assign_status']??0)!==1||(int)($d['shipment_id']??0)!==(int)$s->provider_shipment_id||!preg_match('/^[A-Za-z0-9-]{1,100}$/',(string)($d['awb_code']??'')))throw new RuntimeException();$s->update(['awb'=>(string)$d['awb_code'],'courier'=>mb_substr((string)($d['courier_name']??$s->courier),0,80),'state'=>'booked','operation'=>null,'operation_state'=>null]);$s->order->update(['courier'=>$s->courier,'tracking_number'=>$s->awb]);}
  catch(\Throwable){$s->update(['operation_state'=>'uncertain']);throw new RuntimeException('AWB assignment needs verification before retrying.');}return $s;
 }
 public function pickup(Shipment $s):void {
  abort_unless($s->awb&&!$s->pickup_requested_at,409);$s=$this->begin($s,'pickup');
  try{$r=$this->api->request('POST','courier/generate/pickup',['shipment_id'=>[$s->provider_shipment_id]]);if((int)($r['pickup_status']??0)!==1)throw new RuntimeException();$s->update(['pickup_requested_at'=>now(),'state'=>'pickup_requested','operation'=>null,'operation_state'=>null]);}
  catch(\Throwable){$s->update(['operation_state'=>'uncertain']);throw new RuntimeException('Pickup request needs verification in Shiprocket.');}
 }
 public function label(Shipment $s):void {
  abort_unless($s->awb,409);$r=$this->api->request('POST','courier/generate/label',['shipment_id'=>[$s->provider_shipment_id]]);$url=$r['label_url']??null;if(!Shiprocket::safeDocument($url))throw new RuntimeException('Document host is not approved. Verify it and configure the exact document host on the server.');$s->update(['label_url'=>$url]);
 }
 public function reconcile(Shipment $s,int $providerId):void {
  abort_if($s->operation_state==='pending'&&$s->updated_at->gt(now()->subMinutes(10)),409,'The carrier request may still be running. Wait before reconciling.');
  $r=$this->api->request('GET','orders/show/'.$providerId);$d=$r['data']??[];
  abort_unless((string)($d['channel_order_id']??'')===$s->reference,409,'Provider order reference does not match.');
  $remote=$d['shipments'][0]??null;abort_unless(is_array($remote)&&is_numeric($remote['id']??null),409,'No verified shipment.');
  // Verify order identity and amount before trusting a manually supplied provider ID.
  $o=$s->order;abort_unless((string)($d['customer_pincode']??'')===$o->pincode&&abs((float)($d['total']??-1)-$o->total_paise/100)<0.01,409,'Provider destination or amount does not match.');
  $awb=(string)($remote['awb']??'');abort_if($awb!==''&&!preg_match('/^[A-Za-z0-9-]{1,100}$/',$awb),409);
  if($s->operation==='pickup'){abort_unless(filled($remote['pickup_scheduled_date']??null),409,'Pickup confirmation is not available; keep the operation blocked.');$s->pickup_requested_at=now();}
  DB::transaction(function()use($s,$providerId,$remote,$awb){$o=Order::whereKey($s->order_id)->lockForUpdate()->firstOrFail();$locked=Shipment::whereKey($s->id)->lockForUpdate()->firstOrFail();abort_unless($locked->operation_state===$s->operation_state&&$locked->operation===$s->operation,409,'Operation changed. Reload before reconciliation.');
  $s->update(['provider_order_id'=>$providerId,'provider_shipment_id'=>(int)$remote['id'],'awb'=>$awb?:null,'state'=>$s->pickup_requested_at?'pickup_requested':($awb?'booked':'created'),'operation'=>null,'operation_state'=>null]);
  if($awb)$o->update(['courier'=>$s->courier,'tracking_number'=>$awb]);
  });
 }
 public function sync(Shipment $s):void {
  if(!$s->provider_shipment_id)return;
  $r=$this->api->request('GET','courier/track/shipment/'.$s->provider_shipment_id);$d=$r['tracking_data']??[];$track=$d['shipment_track'][0]??null;
  if(!is_array($track)||(int)($d['track_status']??0)!==1||(string)($track['awb_code']??'')!==(string)$s->awb)return;
  $status=mb_substr((string)($track['current_status']??''),0,100);$events=collect($d['shipment_track_activities']??[])->take(50)->filter(fn($x)=>is_array($x))->map(fn($x)=>['date'=>mb_substr((string)($x['date']??''),0,40),'activity'=>mb_substr((string)($x['activity']??''),0,200),'location'=>mb_substr((string)($x['location']??''),0,100)])->values()->all();
  DB::transaction(function()use($s,$status,$events){$o=Order::whereKey($s->order_id)->lockForUpdate()->firstOrFail();$locked=Shipment::whereKey($s->id)->lockForUpdate()->firstOrFail();$upper=strtoupper(trim($status));
   if($locked->state==='delivered'&&$upper!=='DELIVERED')return;if($locked->state==='rto'&&!str_contains($upper,'RTO'))return;
   $update=['tracking_status'=>$status,'tracking_events'=>$events,'synced_at'=>now(),'sync_requested_at'=>null];
   if($upper==='DELIVERED'){$update['state']='delivered';if(!in_array($o->status,['cancelled','delivered'],true))$o->update(['status'=>'delivered','delivered_at'=>now(),'shipped_at'=>$o->shipped_at??now()]);}
   elseif(str_contains($upper,'RTO'))$update['state']='rto';
   elseif(in_array($upper,['UNDELIVERED','UNDELIVERED - NDR','LOST','DAMAGED'],true))$update['state']='delivery_issue';
   elseif(in_array($upper,['PICKED UP','SHIPPED','IN TRANSIT','OUT FOR DELIVERY'],true)){ $update['state']='in_transit';if($o->status==='processing')$o->update(['status'=>'shipped','shipped_at'=>now()]);}
   $locked->update($update);
  });
 }
}
