<?php

namespace App\Services;

use App\Models\Coupon;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\PaymentReconciliation;
use App\Models\User;
use App\Models\Variant;
use App\Notifications\PaymentReconciliationAlert;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Notification;
use Throwable;

class RazorpayPaymentLifecycle
{
    private const API = 'https://api.razorpay.com/v1';

    public function createGatewayOrder(int $orderId): bool
    {
        $order = Order::findOrFail($orderId);
        try {
            $remote = $this->client()->post(self::API.'/orders', [
                'amount' => $order->total_paise, 'currency' => 'INR', 'receipt' => $order->gateway_receipt,
            ])->throw()->json();
            $gatewayId = $remote['id'] ?? null;
            if (! is_string($gatewayId) || ! preg_match('/^order_[A-Za-z0-9]+$/', $gatewayId) ||
                (isset($remote['amount']) && (int) $remote['amount'] !== (int) $order->total_paise) ||
                (isset($remote['currency']) && $remote['currency'] !== 'INR')) {
                throw new \UnexpectedValueException('Invalid Razorpay order response.');
            }
        } catch (Throwable $e) {
            report($e);
            DB::transaction(function () use ($orderId): void {
                $locked = Order::whereKey($orderId)->lockForUpdate()->firstOrFail();
                if (! $locked->gateway_order_id && $locked->status === 'pending' && $locked->payment_status === 'pending') {
                    $locked->update(['gateway_order_state' => 'unknown']);
                }
            }, 3);
            $this->raiseIssue(Order::find($orderId), 'gateway_order_creation_ambiguous', null, null, ['exception' => $e::class]);
            return false;
        }

        try {
            $attached = DB::transaction(function () use ($orderId, $gatewayId): bool {
                $locked = Order::whereKey($orderId)->lockForUpdate()->firstOrFail();
                if ($locked->status !== 'pending' || $locked->payment_status !== 'pending' || $locked->stock_released_at) return false;
                if ($locked->gateway_order_id && $locked->gateway_order_id !== $gatewayId) return false;
                $locked->update(['gateway_order_id' => $gatewayId, 'gateway_order_state' => 'created', 'gateway_reconcile_after' => null]);
                return true;
            }, 3);
        } catch (Throwable $e) {
            report($e);
            $this->raiseIssue(Order::find($orderId), 'gateway_order_persist_failed', null, $gatewayId, ['exception' => $e::class]);
            return false;
        }
        if (! $attached) {
            $this->raiseIssue(Order::find($orderId), 'gateway_order_attached_to_ineligible_order', null, $gatewayId);
            return false;
        }
        return true;
    }

    public function settleCaptured(Order $order, array $payment): string
    {
        $paymentId = is_string($payment['id'] ?? null) ? $payment['id'] : null;
        $gatewayOrderId = is_string($payment['order_id'] ?? null) ? $payment['order_id'] : $order->gateway_order_id;
        if (! $paymentId || ! preg_match('/^pay_[A-Za-z0-9]+$/', $paymentId) || ($payment['status'] ?? null) !== 'captured' ||
            $gatewayOrderId !== $order->gateway_order_id || (int) ($payment['amount'] ?? -1) !== (int) $order->total_paise ||
            ($payment['currency'] ?? null) !== 'INR') {
            $this->raiseIssue($order, 'captured_payment_mismatch', $paymentId, $gatewayOrderId);
            return 'reconciliation_required';
        }
        try {
            $result = DB::transaction(function () use ($order, $paymentId): string {
                $locked = Order::whereKey($order->id)->lockForUpdate()->firstOrFail();
                if ($locked->payment_status === 'paid') return $locked->gateway_payment_id === $paymentId ? 'already_settled' : 'duplicate_capture';
                if ($locked->stock_released_at || $locked->status !== 'pending' || $locked->payment_status !== 'pending' ||
                    $locked->payment_method !== 'razorpay') return 'captured_after_release_or_ineligible';
                if (Order::where('gateway_payment_id', $paymentId)->where('id', '!=', $locked->id)->exists()) return 'payment_id_used_by_another_order';
                $locked->update(['payment_status' => 'paid', 'gateway_payment_id' => $paymentId, 'status' => 'processing',
                    'gateway_order_state' => 'paid', 'payment_expires_at' => null, 'gateway_reconcile_after' => null]);
                return 'settled';
            }, 3);
        } catch (Throwable $e) {
            report($e);
            $this->raiseIssue(Order::find($order->id), 'captured_payment_transition_failed', $paymentId, $gatewayOrderId, ['exception' => $e::class]);
            return 'reconciliation_required';
        }
        if (! in_array($result, ['settled', 'already_settled'], true)) $this->raiseIssue(Order::find($order->id), $result, $paymentId, $gatewayOrderId);
        return $result;
    }

    public function observeNonCapturedPaymentEvent(Order $order, string $event, array $payment): void
    {
        $paymentId = is_string($payment['id'] ?? null) ? $payment['id'] : null;
        $gatewayOrderId = is_string($payment['order_id'] ?? null) ? $payment['order_id'] : null;
        if (! $paymentId || ! preg_match('/^pay_[A-Za-z0-9]+$/', $paymentId) ||
            $gatewayOrderId !== $order->gateway_order_id) {
            $this->raiseIssue($order, 'non_captured_payment_event_mismatch', $paymentId, $gatewayOrderId, ['event' => $event]);
            return;
        }

        // Failed/created/authorized are observations only. The expiry worker re-reads
        // gateway state before it can release inventory or coupon usage.
        Log::info('Razorpay non-captured payment event received; reservation remains held.', [
            'order_id' => $order->id,
            'gateway_order_id' => $gatewayOrderId,
            'payment_id' => $paymentId,
            'event' => $event,
            'payment_status' => $payment['status'] ?? null,
        ]);
    }

    public function reconcileExpired(Order $candidate): void
    {
        $order = Order::find($candidate->id);
        if (! $this->isDue($order)) return;
        try {
            if (! $order->gateway_order_id) {
                $collection = $this->client()->get(self::API.'/orders', ['receipt' => $order->gateway_receipt, 'count' => 100])->throw()->json();
                if (! is_array($collection['items'] ?? null)) throw new \UnexpectedValueException('Invalid Razorpay order list.');
                $matches = collect($collection['items'])->where('receipt', $order->gateway_receipt)->values();
                if ($matches->isEmpty()) { $this->recordRemoteAbsence($order->id); return; }
                if ($matches->count() !== 1) {
                    $this->raiseIssue($order, 'multiple_gateway_orders_for_receipt', null, null, ['count' => $matches->count()]);
                    $this->defer($order->id); return;
                }
                $remote = $matches->first();
                if (! $this->validRemoteOrder($order, $remote)) {
                    $this->raiseIssue($order, 'gateway_order_receipt_mismatch', null, $remote['id'] ?? null);
                    $this->defer($order->id); return;
                }
                $attached = DB::transaction(function () use ($order, $remote): bool {
                    $locked = Order::whereKey($order->id)->lockForUpdate()->firstOrFail();
                    if (! $this->isEligible($locked)) return false;
                    $locked->update(['gateway_order_id' => $remote['id'], 'gateway_order_state' => 'created', 'gateway_reconcile_after' => null]);
                    PaymentReconciliation::where('order_id', $locked->id)->where('kind', 'gateway_order_creation_ambiguous')
                        ->where('status', 'open')->update(['status' => 'resolved', 'resolution_note' => 'Gateway order recovered by receipt.', 'resolved_at' => now()]);
                    return true;
                }, 3);
                if (! $attached) return;
                $order = $order->fresh();
            }
            $remoteOrder = $this->client()->get(self::API.'/orders/'.$order->gateway_order_id)->throw()->json();
            if (! $this->validRemoteOrder($order, $remoteOrder)) {
                $this->raiseIssue($order, 'gateway_order_verification_mismatch', null, $order->gateway_order_id);
                $this->defer($order->id); return;
            }
            $payments = $this->client()->get(self::API.'/orders/'.$order->gateway_order_id.'/payments')->throw()->json();
            if (! is_array($payments['items'] ?? null)) throw new \UnexpectedValueException('Invalid Razorpay payments response.');
            $items = collect($payments['items']);
            foreach ($items->where('status', 'captured') as $item) {
                if (! is_string($item['id'] ?? null)) continue;
                $payment = $this->client()->get(self::API.'/payments/'.$item['id'])->throw()->json();
                $this->settleCaptured($order, $payment); return;
            }
            if (($remoteOrder['status'] ?? null) === 'paid' || (int) ($remoteOrder['amount_paid'] ?? 0) > 0) {
                $this->raiseIssue($order, 'gateway_paid_without_captured_payment_record', null, $order->gateway_order_id);
                $this->defer($order->id); return;
            }
            if ($items->contains(fn ($item) => ($item['status'] ?? null) === 'authorized')) {
                $this->raiseIssue($order, 'authorized_payment_requires_capture_review', null, $order->gateway_order_id);
                $this->defer($order->id); return;
            }
            $recentCreatedAttempt = $items->contains(function ($item) use ($order): bool {
                if (($item['status'] ?? null) !== 'created') return false;
                if (! is_numeric($item['created_at'] ?? null)) return true;
                return \Illuminate\Support\Carbon::createFromTimestamp((int) $item['created_at'])->gt($order->payment_expires_at);
            });
            if ($recentCreatedAttempt) {
                $this->raiseIssue($order, 'payment_attempt_started_after_expiry', null, $order->gateway_order_id);
                $this->defer($order->id); return;
            }
            if ($items->isNotEmpty() && ! $items->every(fn ($item) => in_array($item['status'] ?? null, ['failed', 'created'], true))) {
                $this->raiseIssue($order, 'unknown_gateway_payment_state', null, $order->gateway_order_id);
                $this->defer($order->id); return;
            }
            $this->releaseReservation($order->id);
        } catch (Throwable $e) {
            report($e);
            $this->raiseIssue($order, 'gateway_status_lookup_failed', null, $order->gateway_order_id, ['exception' => $e::class]);
            $this->defer($order->id);
        }
    }

    public function raiseIssue(?Order $order, string $kind, ?string $paymentId, ?string $gatewayOrderId, array $details = []): PaymentReconciliation
    {
        $key = hash('sha256', $kind.'|'.($order?->id ?? 'orphan').'|'.($paymentId ?? 'none').'|'.($gatewayOrderId ?? 'none'));
        $issue = PaymentReconciliation::firstOrCreate(['dedupe_key' => $key], [
            'order_id' => $order?->id, 'gateway_order_id' => $gatewayOrderId, 'payment_id' => $paymentId,
            'kind' => $kind, 'details' => $details, 'status' => 'open',
        ]);
        if (! $issue->alerted_at && $issue->status === 'open') {
            $admins = User::where('is_admin', true)->get();
            try {
                if ($admins->isNotEmpty()) {
                    Notification::send($admins, new PaymentReconciliationAlert($issue));
                    $issue->update(['alerted_at' => now()]);
                } else {
                    Log::critical('Payment reconciliation requires admin attention; no admin recipients are configured.', ['issue_id' => $issue->id]);
                }
            } catch (Throwable $e) { report($e); }
        }
        return $issue;
    }

    private function client(): \Illuminate\Http\Client\PendingRequest
    {
        return Http::withBasicAuth(config('services.razorpay.key'), config('services.razorpay.secret'))->timeout(10);
    }

    private function isDue(?Order $order): bool
    {
        return $order && $this->isEligible($order) && $order->payment_expires_at && $order->payment_expires_at->lte(now()->subMinutes(5)) &&
            (! $order->gateway_reconcile_after || $order->gateway_reconcile_after->lte(now()));
    }

    private function isEligible(Order $order): bool
    {
        return $order->payment_method === 'razorpay' && $order->status === 'pending' && $order->payment_status === 'pending' && ! $order->stock_released_at;
    }

    private function validRemoteOrder(Order $order, array $remote): bool
    {
        $idMatches = $order->gateway_order_id
            ? ($remote['id'] ?? null) === $order->gateway_order_id
            : is_string($remote['id'] ?? null) && str_starts_with($remote['id'], 'order_');
        return $idMatches && (int) ($remote['amount'] ?? -1) === (int) $order->total_paise &&
            ($remote['currency'] ?? null) === 'INR' && ($remote['receipt'] ?? null) === $order->gateway_receipt;
    }

    private function recordRemoteAbsence(int $orderId): void
    {
        DB::transaction(function () use ($orderId): void {
            $order = Order::whereKey($orderId)->lockForUpdate()->firstOrFail();
            if (! $this->isEligible($order) || ! $this->isDue($order) || $order->gateway_order_id) return;
            if ($order->gateway_absence_checks < 1) {
                $order->update(['gateway_absence_checks' => 1, 'gateway_reconcile_after' => now()->addMinutes(5)]);
                return;
            }
            $this->releaseLocked($order);
        }, 3);
    }

    private function releaseReservation(int $orderId): void
    {
        DB::transaction(function () use ($orderId): void {
            $order = Order::whereKey($orderId)->lockForUpdate()->firstOrFail();
            if ($this->isEligible($order) && $this->isDue($order)) $this->releaseLocked($order);
        }, 3);
    }

    private function releaseLocked(Order $order): void
    {
        if (! $this->isEligible($order)) return;
        $items = OrderItem::where('order_id', $order->id)->orderBy('variant_id')->lockForUpdate()->get();
        $variants = Variant::whereIn('id', $items->pluck('variant_id')->filter())->orderBy('id')->lockForUpdate()->get()->keyBy('id');
        foreach ($items as $item) {
            if (! $item->variant_id || ! $variants->has($item->variant_id)) continue;
            $variant = $variants->get($item->variant_id);
            $variant->increment('stock', $item->quantity);
            $variant->refresh();
            DB::table('stock_movements')->insert([
                'variant_id' => $variant->id,
                'user_id' => null,
                'change' => $item->quantity,
                'stock_after' => $variant->stock,
                'reason' => 'Expired Razorpay reservation for order #'.$order->id,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }
        if ($order->coupon_id) {
            $coupon = Coupon::whereKey($order->coupon_id)->lockForUpdate()->first();
            if ($coupon && $coupon->used_count > 0) $coupon->decrement('used_count');
        }
        $order->update(['status' => 'cancelled', 'payment_status' => 'failed', 'gateway_order_state' => 'expired',
            'stock_released_at' => now(), 'payment_expires_at' => null, 'gateway_reconcile_after' => null]);
    }

    private function defer(int $orderId): void
    {
        DB::transaction(function () use ($orderId): void {
            $order = Order::whereKey($orderId)->lockForUpdate()->first();
            if ($order && $this->isEligible($order)) $order->update(['gateway_reconcile_after' => now()->addMinutes(5)]);
        }, 3);
    }
}
