<?php
namespace App\Services;
use Illuminate\Support\Facades\{Cache,Crypt,Http};
use RuntimeException;
/** Fixed origin, TLS verification, no redirects and no automatic mutation retries. */
class Shiprocket {
 private const BASE='https://apiv2.shiprocket.in/v1/external/';
 public function configured():bool {return filled(config('services.shiprocket.email'))&&filled(config('services.shiprocket.password'));}
 private function tokenKey():string {return 'logistics.token.'.hash('sha256',(string)config('services.shiprocket.email').'|'.(string)config('services.shiprocket.password'));}
 private function token():string {
  if(!$this->configured())throw new RuntimeException('Shipping connection is not configured.');
  $key=$this->tokenKey();$cached=Cache::get($key);if(is_string($cached)){try{return Crypt::decryptString($cached);}catch(\Throwable){Cache::forget($key);}}
  return Cache::lock($key.'.lock',30)->block(5,function()use($key){$cached=Cache::get($key);if(is_string($cached))return Crypt::decryptString($cached);
   try{$r=Http::acceptJson()->asJson()->withoutRedirecting()->connectTimeout(5)->timeout(15)->post(self::BASE.'auth/login',['email'=>config('services.shiprocket.email'),'password'=>config('services.shiprocket.password')]);}
   catch(\Throwable){throw new RuntimeException('Shipping authentication is temporarily unavailable.');}
   $token=$r->json('token');if(!$r->successful()||!is_string($token)||strlen($token)<10)throw new RuntimeException('Shipping credentials could not be verified.');
   Cache::put($key,Crypt::encryptString($token),now()->addDays(8));return $token;
  });
 }
 public function request(string $method,string $path,array $data=[]):array {
  if(!preg_match('~^(?:orders/(?:create/adhoc|show/[0-9]+)|courier/(?:serviceability/|assign/awb|generate/(?:pickup|label)|track/shipment/[0-9]+)|settings/company/pickup)$~',$path))throw new RuntimeException('Unsupported shipping operation.');
  $token=$this->token();
  try{$r=Http::withToken($token)->acceptJson()->asJson()->withoutRedirecting()->connectTimeout(5)->timeout(20)->send($method,self::BASE.$path,[$method==='GET'?'query':'json'=>$data]);}
  catch(\Throwable){throw new RuntimeException('Shipping service could not be reached. Verify any pending booking before retrying.');}
  if($r->status()===401)Cache::forget($this->tokenKey());
  if(!$r->successful()||!is_array($r->json()))throw new RuntimeException('Shipping request failed. Check the connection or verify the operation in Shiprocket.');
  return $r->json();
 }
 public function pickups():array {return $this->request('GET','settings/company/pickup')['data']['shipping_address']??[];}
 public function rates(string $from,string $to,array $parcel,bool $cod,int $value):array {
  $r=$this->request('GET','courier/serviceability/',['pickup_postcode'=>$from,'delivery_postcode'=>$to,'weight'=>$parcel['weight'],'length'=>$parcel['length'],'breadth'=>$parcel['breadth'],'height'=>$parcel['height'],'cod'=>$cod?1:0,'declared_value'=>$value/100]);
  $rows=$r['data']['available_courier_companies']??null;if(!is_array($rows))throw new RuntimeException('Delivery availability could not be verified.');
  return collect($rows)->filter(fn($x)=>is_array($x)&&is_numeric($x['courier_company_id']??null)&&is_numeric($x['rate']??null)&&(int)$x['courier_company_id']>0&&(float)$x['rate']>=0&&(float)$x['rate']<=1000000&&empty($x['blocked'])&&(!$cod||!empty($x['cod'])))->map(fn($x)=>['id'=>(int)$x['courier_company_id'],'name'=>mb_substr((string)($x['courier_name']??'Courier'),0,80),'cost_paise'=>(int)round((float)$x['rate']*100),'estimate'=>mb_substr((string)($x['etd']??'Estimate unavailable'),0,80)])->sortBy('cost_paise')->values()->all();
 }
 public static function safeDocument(?string $url):bool {
  if(!$url||strlen($url)>3000||!filter_var($url,FILTER_VALIDATE_URL))return false;$p=parse_url($url);$host=strtolower($p['host']??'');
  if(($p['scheme']??'')!=='https'||isset($p['user'])||isset($p['pass'])||isset($p['port']))return false;
  // Exact hosts only; add a verified provider document host in server configuration.
  return in_array($host,array_filter(array_map('trim',explode(',',(string)config('services.shiprocket.document_hosts','')))),true);
 }
}
