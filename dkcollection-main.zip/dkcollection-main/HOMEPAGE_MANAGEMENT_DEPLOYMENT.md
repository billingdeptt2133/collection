# Homepage Management

Separate admin page: `/admin/homepage`, protected by existing authentication, admin authorization and throttling. Forms retain web CSRF protection. The GET response is private and no-store. Uploaded raster images use generated filenames and validated MIME types, size and dimensions. Banner destinations come from active categories. Escaped Blade output protects stored text.

Three additive nullable columns require a database backup and `php artisan migrate --force` using PHP 8.3 before reopening the site. Do not run tests against the live database. Preserve `.env`, the private application directory, public entry point and storage symlink.

Deploy the tested commit in maintenance mode. Copy `public/css/admin-homepage.css` and `public/js/hero-premium.js`, and `public/js/storefront.js` to the sibling `public_html/css/` and `public_html/js/`. Clear/rebuild config and view caches, then reopen.

Default settings preserve the existing catalog/category selection and 5-second carousel. Uploaded banner photos now render. Mobile photo falls back to desktop. New arrivals uses selected real products unless a customer searches/filters; an empty selection uses the catalog. Featured only displays selected active stocked real products. Inactive and sold-out selections never display. Category selection controls only the homepage showcase, not collection filter navigation. Existing banner/category management remains compatible.

Replacing photos retains prior files to avoid breaking shared references; later storage cleanup must verify references. This change does not introduce 2FA, staff roles, gateway settings, order management or guarantee immunity from attacks.
