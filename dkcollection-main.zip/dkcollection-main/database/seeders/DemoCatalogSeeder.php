<?php

namespace Database\Seeders;

use App\Models\Category;
use App\Models\Product;
use Illuminate\Database\Seeder;

class DemoCatalogSeeder extends Seeder
{
    public function run(): void
    {
        $fits = ['ankle-fit' => 'Ankle Fit', 'straight-fit' => 'Straight Fit',
            'baggy-fit' => 'Baggy Fit', 'regular-fit' => 'Regular Fit'];
        $colors = ['indigo' => 'Indigo', 'washed-blue' => 'Washed Blue',
            'charcoal' => 'Charcoal', 'light-blue' => 'Light Blue'];
        $position = 100;
        foreach ($fits as $slug => $name) {
            $category = Category::firstOrCreate(['slug' => $slug],
                ['name' => $name, 'is_active' => true, 'sort_order' => array_search($slug, array_keys($fits))]);
            foreach ($colors as $colorSlug => $color) {
                $product = Product::firstOrCreate(['slug' => "demo-$slug-$colorSlug"], [
                    'category_id' => $category->id, 'title' => "$color $name Jeans",
                    'description' => 'Demo listing for layout preview. Replace the images, copy and price with verified product details before launch.',
                    'price_paise' => 179900 + (array_search($slug, array_keys($fits)) * 10000),
                    'mrp_paise' => 249900, 'is_active' => true, 'is_demo' => true,
                    'sort_order' => $position++,
                ]);
                foreach (['28', '30', '32', '34', '36', '38'] as $size)
                    $product->variants()->firstOrCreate(['size' => $size, 'color' => $color], ['stock' => 10]);
            }
        }
    }
}
