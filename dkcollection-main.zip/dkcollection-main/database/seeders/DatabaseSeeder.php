<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // Preview data is opt-in: php artisan db:seed --class=DemoCatalogSeeder
    }
}
