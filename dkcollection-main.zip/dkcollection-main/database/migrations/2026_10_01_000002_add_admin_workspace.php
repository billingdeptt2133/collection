<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
    public function up(): void {
        Schema::table('users', function(Blueprint $t) {
            $t->string('admin_role',20)->nullable();
            $t->boolean('admin_mfa_enabled')->default(false);
            $t->unsignedInteger('admin_session_version')->default(0);
        });
        Schema::table('orders', function(Blueprint $t) {
            $t->string('courier',80)->nullable();
            $t->string('tracking_number',100)->nullable();
            $t->string('tracking_url',500)->nullable();
            $t->timestamp('packed_at')->nullable();
            $t->timestamp('shipped_at')->nullable();
            $t->timestamp('delivered_at')->nullable();
            $t->timestamp('cod_collected_at')->nullable();
            $t->text('admin_note')->nullable();
        });
        Schema::table('coupons', function(Blueprint $t) {
            $t->string('discount_type',10)->default('fixed');
            $t->unsignedTinyInteger('percentage')->nullable();
            $t->unsignedBigInteger('maximum_paise')->nullable();
            $t->timestamp('starts_at')->nullable();
        });
        Schema::table('store_settings', function(Blueprint $t) {
            $t->string('support_phone',20)->nullable();
            $t->string('whatsapp',15)->nullable();
            $t->text('store_address')->nullable();
            foreach(['shipping_policy','return_policy','privacy_policy','terms_policy'] as $field)$t->text($field)->nullable();
        });
        Schema::table('reviews', function(Blueprint $t) {
            $t->timestamp('rejected_at')->nullable();
        });
        Schema::create('admin_audits', function(Blueprint $t) {
            $t->id();
            $t->foreignId('user_id')->nullable()->constrained()->nullOnDelete();
            $t->string('action',120);
            $t->json('context')->nullable();
            $t->timestamps();
        });
        Schema::create('stock_movements', function(Blueprint $t) {
            $t->id();
            $t->foreignId('variant_id')->constrained()->restrictOnDelete();
            $t->foreignId('user_id')->nullable()->constrained()->nullOnDelete();
            $t->integer('change');
            $t->unsignedInteger('stock_after');
            $t->string('reason',250);
            $t->timestamps();
        });
        Schema::create('order_returns', function(Blueprint $t) {
            $t->id();
            $t->foreignId('order_id')->unique()->constrained()->restrictOnDelete();
            $t->string('status',20)->default('requested');
            $t->string('kind',20)->default('return');
            $t->string('manual_refund_reference',100)->nullable();
            $t->string('reason',500);
            $t->boolean('restocked')->default(false);
            $t->string('refund_id',100)->nullable()->unique();
            $t->unsignedBigInteger('refund_paise')->default(0);
            $t->string('refund_status',20)->nullable();
            $t->timestamps();
        });
    }
    public function down(): void {
        Schema::table('store_settings',fn(Blueprint $t)=>$t->dropColumn(['support_phone','whatsapp','store_address','shipping_policy','return_policy','privacy_policy','terms_policy']));
        Schema::table('reviews',fn(Blueprint $t)=>$t->dropColumn('rejected_at'));
        foreach(['order_returns','stock_movements','admin_audits'] as $t)Schema::dropIfExists($t);
        Schema::table('coupons',fn(Blueprint $t)=>$t->dropColumn(['discount_type','percentage','maximum_paise','starts_at']));
        Schema::table('orders',fn(Blueprint $t)=>$t->dropColumn(['courier','tracking_number','tracking_url','packed_at','shipped_at','delivered_at','cod_collected_at','admin_note']));
        Schema::table('users',fn(Blueprint $t)=>$t->dropColumn(['admin_role','admin_mfa_enabled','admin_session_version']));
    }
};
