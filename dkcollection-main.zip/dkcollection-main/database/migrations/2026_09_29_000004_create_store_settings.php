<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('store_settings', function (Blueprint $table) {
            $table->id();
            $table->string('name')->default('DK Fashion Hub');
            $table->string('announcement')->nullable();
            $table->string('support_email')->nullable();
            $table->string('logo_path')->nullable();
            $table->string('delivery_mode', 20)->default('allowlist');
            $table->boolean('checkout_enabled')->default(false);
            $table->boolean('cod_enabled')->default(true);
            $table->boolean('online_enabled')->default(false);
            $table->unsignedBigInteger('flat_shipping_paise')->default(0);
            $table->unsignedBigInteger('free_shipping_above_paise')->nullable();
            $table->unsignedBigInteger('cod_fee_paise')->default(0);
            $table->timestamps();
        });
        Schema::create('shipping_pincodes', function (Blueprint $table) {
            $table->id();
            $table->string('pincode', 6)->unique();
            $table->boolean('is_active')->default(true);
            $table->boolean('cod_available')->default(true);
            $table->timestamps();
        });
        Schema::table('orders', function (Blueprint $table) {
            $table->unsignedBigInteger('shipping_paise')->default(0);
            $table->unsignedBigInteger('cod_fee_paise')->default(0);
        });
    }

    public function down(): void
    {
        Schema::table('orders', fn (Blueprint $table) => $table->dropColumn(['shipping_paise', 'cod_fee_paise']));
        Schema::dropIfExists('shipping_pincodes');
        Schema::dropIfExists('store_settings');
    }
};
