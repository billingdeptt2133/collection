<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('products', function (Blueprint $table) {
            $table->string('product_code', 64)->nullable()->index();
            $table->string('article_code', 64)->nullable();
            $table->string('pattern', 64)->nullable();
        });
        Schema::table('variants', function (Blueprint $table) {
            $table->string('shade_code', 30)->nullable();
            $table->string('barcode', 64)->nullable()->unique();
        });
    }

    public function down(): void
    {
        Schema::table('variants', fn (Blueprint $table) => $table->dropColumn(['shade_code', 'barcode']));
        Schema::table('products', fn (Blueprint $table) => $table->dropColumn(['product_code', 'article_code', 'pattern']));
    }
};
