<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
    public function up(): void {
        Schema::table('banners', fn (Blueprint $table) => $table->string('mobile_image_path')->nullable());
        Schema::table('categories', fn (Blueprint $table) => $table->string('image_path')->nullable());
        Schema::table('store_settings', fn (Blueprint $table) => $table->json('homepage')->nullable());
    }
    public function down(): void {
        Schema::table('store_settings', fn (Blueprint $table) => $table->dropColumn('homepage'));
        Schema::table('categories', fn (Blueprint $table) => $table->dropColumn('image_path'));
        Schema::table('banners', fn (Blueprint $table) => $table->dropColumn('mobile_image_path'));
    }
};
