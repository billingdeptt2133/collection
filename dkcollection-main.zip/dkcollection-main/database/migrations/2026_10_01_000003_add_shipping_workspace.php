<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
 public function up(): void {
  Schema::table('store_settings',function(Blueprint $t){$t->string('shipping_provider',20)->default('manual');$t->boolean('shipping_manual_fallback')->default(false);$t->string('shipping_pickup_name',100)->nullable();$t->string('shipping_pickup_pincode',6)->nullable();$t->unsignedInteger('shipping_unit_grams')->default(700);$t->unsignedSmallInteger('shipping_length_cm')->default(30);$t->unsignedSmallInteger('shipping_breadth_cm')->default(25);$t->unsignedSmallInteger('shipping_height_cm')->default(5);});
  Schema::table('orders',function(Blueprint $t){$t->string('shipping_provider',20)->default('manual');$t->json('shipping_snapshot')->nullable();});
  Schema::create('shipments',function(Blueprint $t){$t->id();$t->foreignId('order_id')->unique()->constrained()->restrictOnDelete();$t->string('reference',50)->unique();$t->unsignedBigInteger('provider_order_id')->nullable()->unique();$t->unsignedBigInteger('provider_shipment_id')->nullable()->unique();$t->unsignedBigInteger('courier_id')->nullable();$t->string('courier',80)->nullable();$t->string('awb',100)->nullable()->unique();$t->json('parcel');$t->string('state',40)->default('draft')->index();$t->string('operation',20)->nullable();$t->string('operation_state',20)->nullable();$t->string('tracking_status',100)->nullable();$t->json('tracking_events')->nullable();$t->timestamp('synced_at')->nullable();$t->timestamp('sync_requested_at')->nullable();$t->text('label_url')->nullable();$t->timestamp('pickup_requested_at')->nullable();$t->unsignedInteger('quoted_cost_paise')->nullable();$t->string('settlement_reference',100)->nullable();$t->unsignedInteger('settlement_paise')->nullable();$t->timestamp('settled_at')->nullable();$t->timestamps();});
 }
 public function down(): void {Schema::dropIfExists('shipments');Schema::table('orders',fn(Blueprint $t)=>$t->dropColumn(['shipping_provider','shipping_snapshot']));Schema::table('store_settings',fn(Blueprint $t)=>$t->dropColumn(['shipping_provider','shipping_manual_fallback','shipping_pickup_name','shipping_pickup_pincode','shipping_unit_grams','shipping_length_cm','shipping_breadth_cm','shipping_height_cm']));}
};
