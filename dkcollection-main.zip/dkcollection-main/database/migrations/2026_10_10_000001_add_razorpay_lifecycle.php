<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('orders', function (Blueprint $table) {
            $table->string('gateway_receipt', 40)->nullable()->unique();
            $table->string('gateway_order_state', 24)->default('not_applicable');
            $table->timestamp('payment_expires_at')->nullable()->index();
            $table->timestamp('stock_released_at')->nullable();
            $table->timestamp('gateway_reconcile_after')->nullable()->index();
            $table->unsignedTinyInteger('gateway_absence_checks')->default(0);
        });
        DB::table('orders')->where('payment_method', 'razorpay')->orderBy('id')->chunk(100, function ($orders): void {
            foreach ($orders as $order) {
                DB::table('orders')->where('id', $order->id)->update([
                    'gateway_receipt' => 'dk-'.$order->id,
                    'gateway_order_state' => $order->payment_status === 'paid' ? 'paid' :
                        ($order->status === 'cancelled' ? 'expired' : ($order->gateway_order_id ? 'created' : 'unknown')),
                    'payment_expires_at' => $order->status === 'pending' && $order->payment_status === 'pending'
                        ? \Illuminate\Support\Carbon::parse($order->created_at)->addMinutes(30) : null,
                ]);
            }
        });
        Schema::create('payment_reconciliations', function (Blueprint $table) {
            $table->id();
            $table->foreignId('order_id')->nullable()->constrained()->nullOnDelete();
            $table->string('gateway_order_id', 64)->nullable()->index();
            $table->string('payment_id', 64)->nullable()->index();
            $table->string('kind', 64);
            $table->char('dedupe_key', 64)->unique();
            $table->json('details')->nullable();
            $table->string('status', 16)->default('open')->index();
            $table->timestamp('alerted_at')->nullable();
            $table->text('resolution_note')->nullable();
            $table->foreignId('resolved_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('resolved_at')->nullable();
            $table->timestamps();
            $table->index(['status', 'created_at']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('payment_reconciliations');
        Schema::table('orders', function (Blueprint $table) {
            $table->dropUnique(['gateway_receipt']);
            $table->dropIndex(['payment_expires_at']);
            $table->dropIndex(['gateway_reconcile_after']);
            $table->dropColumn(['gateway_receipt', 'gateway_order_state', 'payment_expires_at', 'stock_released_at', 'gateway_reconcile_after', 'gateway_absence_checks']);
        });
    }
};
