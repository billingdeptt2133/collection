# Homepage partners and footer

This patch replaces only the homepage confidence section and footer. Product cards, checkout, payment lifecycle, stock and shipping are unchanged. It adds two assets and uses the existing `store_settings.homepage` JSON column; no migration, Composer install or secret change is required.

## Content setup

In Admin → Homepage Management → Partner logos & footer, upload actual authorized partner logos (PNG/WebP/JPEG, up to 2 MB and 2400×2400). Twelve numbered slots control order. Each has name (image alt text), category caption, visibility and remove controls. No demo partner logos ship. An empty or entirely hidden collection hides the partner section. Save a few uploads at a time to respect the host's `post_max_size`.

Add plain-text About Us/FAQs, HTTPS Instagram/Facebook profile links and an accurate support caption. The approved 24×7 wording is available in the form; save it only if supported by your operating hours. Existing Store settings own policies, phone, email, WhatsApp and address. Unconfigured policies, About Us, FAQs and socials are omitted instead of generating empty destinations. Track Your Order uses the existing authenticated Orders page; Returns & Exchanges and Returns & Refund Policy both use the existing returns policy. Contact Us shows configured contact details, not a new ticketing system.

Uploads use generated paths and raster-image validation. Requests use existing admin role checks, CSRF and audit middleware. Independent homepage saves merge their own fields under a row lock. Replaced/removed images are retained for rollback; purge unreferenced uploads only after the rollback period.

## Deployment after approval and green CI

Back up the current commit and any local changes. Fast-forward the approved commit; preserve local deleted demo images. Copy only these new public assets from the private application to the sibling public webroot:

```bash
cp public/css/home-partners-footer.css ../public_html/css/home-partners-footer.css
cp public/js/home-partners-footer.js ../public_html/js/home-partners-footer.js
/opt/alt/php83/usr/bin/php artisan route:cache
/opt/alt/php83/usr/bin/php artisan view:clear
```

The existing storage symlink serves uploads; do not copy application PHP files into public_html. If rolling back, restore the earlier commit/assets and rebuild route/view caches. Uploaded settings can remain in JSON without affecting the previous storefront.

## Staging checks

- Upload one actual partner, then several; confirm image containment, labels and slot order. Hide/remove one and confirm the rest stay intact.
- Desktop: all footer groups expanded; logos move only with drag, trackpad, scrollbar or keyboard arrows/Home/End. Idle logos never move.
- Mobile at 360px/400px: native swipe scrolls logos; footer groups start collapsed, tap/Enter/Space toggles +/−. Rotate/resize to desktop and back. Without JavaScript links remain available through native details elements.
- Test every configured footer destination; logged-out tracking must request login. Confirm policy content, account ownership, cart and payment flow remain unchanged.
- Run PHPUnit in CI. Browser checks are required on the deployed page with actual logo assets before final visual sign-off.
