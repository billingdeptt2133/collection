# Approved PNG/HTML homepage UI

Reference: user-supplied `jansen_jeans_code_mobile_mockup.png` and `jansen_jeans_code_preview.html`, October 19, 2026. The uploaded files are design references, not production application code. Their fake cart/wishlist counts, toast-only filters, placeholder contacts/reviews and newsletter success message are not copied into the storefront.

## Visual and data mapping

- White header, centered wordmark on mobile, search/heart/bag icons; desktop navigation expands with the same visual language.
- Hero: existing active banners, ordered and capped at five; existing mobile/desktop photos, titles, captions, collection destinations and slideshow interval. New admin toggle supports image-only banners to prevent double text. Mobile ratio 9:11; desktop 16:7.
- Four benefits: editable admin captions; default delivery threshold comes from Store settings. Use claims consistent with the actual store policy.
- Fit buttons: active categories selected in Homepage Management, existing category URLs. Six reference colors cycle by category order; no hardcoded category records.
- Products: two columns on mobile, four on desktop; tall image area 3:4.45 with image containment. Existing real prices/MRP/discounts, article codes, per-color photos/URLs and sold-out status. Featured IDs control BEST SELLER badges, new-arrival IDs control NEW badges. No sales ranking logic is added.
- Heart: existing CSRF-protected wishlist toggle for authenticated customers; guests go through the existing login flow. Bag count comes from valid existing cart lines. `+ ADD` opens the correct color product page so size selection remains in the existing purchase flow; it does not pick a size automatically.
- Collection banner: new admin-managed desktop/mobile uploads, text, category destination and visibility stored in the existing JSON settings. Mobile 9:10 and desktop 16:7.
- Reviews: approved customer reviews or configured YouTube Shorts; no sample testimonials are inserted.
- Existing manually scrolled partner logos remain available when configured, styled to match the new white UI.
- White three-column mobile footer matches the new reference and replaces the earlier accordion presentation. Existing policies, contacts, About Us/FAQs, tracking and socials remain linked. Optional Sustainability/Size Guide content and YouTube/Pinterest profile URLs are editable in the same admin form. Unconfigured destinations remain omitted.
- Newsletter is hidden by explicit user choice; no new newsletter database or endpoint is introduced.

All UI content updates use existing admin/CSRF/audit protection. The new design-content action merges its JSON fields under a row lock and validates raster uploads, category IDs, text lengths and permitted field names. Other homepage forms preserve its fields. No migration, dependency change, payment/shipping/checkout controller change or credential update is needed.

## Assets and content

Only the hero and folded-denim images from the supplied HTML are extracted as small local WebP fallbacks (about 40 KB combined). Existing uploaded hero banners take priority; no banner/product/database records are overwritten. The reference images are mobile resolution: upload high-resolution desktop equivalents through Admin for sharp wide-screen imagery. Do not re-upload baked-in text artwork with copy enabled.

`tests/Browser/denim-fixture.webp` is test-only reference product imagery. The isolated browser fixture creates sample catalog/reviews exclusively in `testing` with a specifically named SQLite database. It refuses other environments/databases. These fixtures are never deployed into the live catalog.

## Verification

PHP feature tests cover UI data connections, authorization/CSRF, safe uploads, independent settings preservation, wishlist and stock behavior, filters, safe banner links and footer destinations. Existing catalog/payment regression suites run on PHP 8.3/8.4/8.5.

The scoped Homepage UI workflow tests widths 360, 395, 768 and 1440: horizontal overflow, 2/4 columns, ratios, image loading/containment, drawer/Escape, real search/category navigation, wishlist login redirect, bag navigation, manual hero controls and 20+12 product pagination. Screenshot artifacts use six fixture cards for compact visual review and do not represent the production catalog.

## Hostinger deployment after approved merge

Use the established backup + exact-commit fast-forward procedure. Preserve local demo-image deletions. Copy only:

```bash
cp public/css/home-editorial.css ../public_html/css/home-editorial.css
cp public/js/home-editorial.js ../public_html/js/home-editorial.js
mkdir -p ../public_html/images/home-reference
cp public/images/home-reference/hero.webp ../public_html/images/home-reference/hero.webp
cp public/images/home-reference/collection.webp ../public_html/images/home-reference/collection.webp
/opt/alt/php83/usr/bin/php artisan route:cache
/opt/alt/php83/usr/bin/php artisan view:clear
```

Old public CSS/JS can remain for rollback and other pages, but the new homepage loads only its new scoped assets, preventing duplicate menu/pagination handlers. Do not sync application files, test fixtures, `.env`, or `.git` into public_html. No migrations, Composer install, key generation or demo seeding.

After deployment, check `/`, `/up`, the four new public assets, mobile header/menu/search, product details/cart, policy links, Admin → Homepage UI content, hero/campaign imagery and current payment/expiry scheduler operation. Replace design fixture content through existing admin screens. Confirm browser console and actual mobile/desktop layout before final visual sign-off.
