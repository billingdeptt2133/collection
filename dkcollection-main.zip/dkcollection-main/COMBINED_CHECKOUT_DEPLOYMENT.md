# Combined checkout deployment

The combined checkout replaces the checkout login redirect with public details entry, mandatory account creation for new buyers, and an authenticated payment review step. The standalone account page remains available.

- No migration, Composer install, environment replacement or payment-setting change is required.
- After updating the repository, copy the contents of `public/css/` and `public/js/` into Hostinger's sibling `public_html/css/` and `public_html/js/` directories. Keep the existing public index, access rules and storage link.
- Refresh application/config/view caches with the existing PHP 8.3 CLI.
- Account password is hashed by the User model and is never included in checkout session drafts, shipping/order fields, or gateway payloads. Standard validation does not flash passwords.
- Shipping drafts last 30 minutes for payment review, belong to the current session/user and are invalidated by bag edits or checkout context changes.
- Continue to Payment creates no order and reserves no stock. The existing locked order transaction validates prices, coupons, delivery, payment settings and stock at final submission.
- Payment review displays delivery, coupon discount, COD fee and final amount. A changed total rejects submission until reviewed. Online order creation redirects to the existing Razorpay payment page; captured payment verification remains required.
- Buyer enters shipping details each time; no persistent saved-address feature is introduced.
- Cart/Buy Now changes from PR #2 are included when deploying latest main. Buy Now preserves the separate shopping bag.

Verify a guest account/address submission, an existing-account login with preserved shipping draft, and the logged-in view without a password field. Verify COD and Razorpay only in the configured test workflow before accepting live purchases. Checkout remains controlled by the existing admin enable/disable setting.
