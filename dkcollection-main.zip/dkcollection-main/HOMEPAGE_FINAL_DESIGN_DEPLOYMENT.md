# Homepage final design deployment notes

This update implements the approved desktop and mobile homepage in Blade/CSS/JS and keeps content under the existing admin controls.

## Admin content sources

- Store Settings: announcement, store identity, policies, support contacts, and WhatsApp.
- Homepage Management: desktop/mobile hero banners and order, fit category buttons, featured/new arrival products, and up to six customer/creator YouTube Shorts.
- Products and stock: active product photos, color-specific gallery card, live price, article code, and sold-out state.

Shorts URLs are validated against YouTube Shorts/youtu.be patterns and only an 11-character video ID is saved. Storefront embeds use the fixed `youtube-nocookie.com` host, lazy loading, a restricted iframe sandbox, and escaped labels.

## Homepage behavior

- Desktop product grid: four columns with 2:3 portrait images using `object-fit: contain`.
- Mobile product grid: two columns with matching 2:3 portrait images.
- First view requests 20 catalog products; each subsequent same-origin Show More request appends 12 without reloading.
- Show More cards are server-rendered Blade partials; the browser only appends cards from the same origin.
- Existing `store_settings.homepage` JSON stores video IDs, so this change adds no migration.

## Deployment verification

Run the feature suite in the Laravel environment and verify homepage CSS/JS cache versions after release. No migration is required. Do not publish the video section before valid approved video URLs have been entered in Homepage Management.
