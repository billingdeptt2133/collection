# Homepage: two image banners

Homepage Management now has exactly two forms: Main Banner and Promotional Banner. Each accepts a desktop image, optional mobile image, and store destination URL. The entire image is clickable; banners have no text, buttons, overlays, or slideshow. Mobile falls back to the desktop image.

Use JPEG, PNG, or WebP up to 4 MB and 4096 pixels per dimension. Use a local path or a full URL on APP_URL's host; full URLs are saved as paths for domain portability. Existing legacy banner images are retained until each slot is saved. Unconfigured slots are hidden. Other homepage data, products, footer content, orders, and payment settings are preserved. Removed Homepage Management operations are no longer routable.

No migration, dependency installation, or seeding is required for this change. Back up the current source and deployed assets, verify a clean diff for changed paths, then fast-forward the approved commit. Copy only public/css/home-editorial.css and public/js/home-editorial.js to the sibling public_html paths. Run with the production PHP binary:

```bash
/opt/alt/php83/usr/bin/php artisan route:cache
/opt/alt/php83/usr/bin/php artisan view:clear
```

Verify both forms as an authorized admin, upload separate mobile/desktop images, save a product URL, and check both image links on mobile and desktop. Confirm cart, filtering, account links, and payments remain unchanged. Preserve .env, APP_KEY, uploaded files, and existing local changes. Roll back source and the two assets together if required.
