# Hostinger deployment layout

This layout works for another domain on a compatible PHP 8.3+/MySQL host. A ZIP is source code, not a database or an automatic transfer of orders/uploads. Keep the existing database and `storage/app/public` backed up when moving a live store.

For Hostinger Web/Cloud plans with SSH and Composer 2. The application must stay outside the web root:

```
domains/YOUR_DOMAIN/
  dkcollection/          # private Laravel repository and .env
  public_html/           # only public assets, .htaccess and front controller
    index.php            # copy deploy/hostinger/public-index.php
    storage -> ../dkcollection/storage/app/public
```

## Preflight

1. Confirm the exact domain, plan, SSH access, PHP 8.3+ for both website and CLI, required PHP extensions, SSL, and MySQL details in hPanel.
2. Review existing `public_html` files before copying anything; do not overwrite an existing site blindly. Back it up first.
3. Hostinger's Git UI on this plan deploys only inside `public_html`. Clone the private repository over SSH into `domains/YOUR_DOMAIN/dkcollection` using a repository-scoped, read-only deploy key. Never deploy this Laravel repository through that Git UI.
4. Create `.env` in `dkcollection` from `.env.production.example` and set a unique `APP_KEY`, `APP_URL=https://YOUR_DOMAIN`, and private MySQL credentials. `APP_URL` must match the public host because the app rejects other Host headers. Keep `.env` outside Git. Leave Razorpay keys blank for preview.

## First release commands (SSH, inside dkcollection)

```bash
/opt/alt/php83/usr/bin/php /usr/local/bin/composer2 install --no-dev --prefer-dist --optimize-autoloader --no-interaction
cp .env.production.example .env && chmod 600 .env  # set APP_URL and MySQL details privately
/opt/alt/php83/usr/bin/php artisan key:generate      # first release only; never rotate casually
/opt/alt/php83/usr/bin/php artisan migrate --force
/opt/alt/php83/usr/bin/php artisan db:seed --class=DemoCatalogSeeder --force
/opt/alt/php83/usr/bin/php artisan optimize
```

Only after confirming `public_html` is safe to replace, copy the public files without the original front controller and set the sibling-root controller:

```bash
rsync -a --exclude=index.php --exclude=storage public/ ../public_html/
cp deploy/hostinger/public-index.php ../public_html/index.php
ln -s ../dkcollection/storage/app/public ../public_html/storage
```

For a fresh domain using a ZIP, download the repository's release ZIP, extract it under `domains/YOUR_DOMAIN/` so it creates the sibling `dkcollection/` directory, create MySQL and the private `.env`, then generate `APP_KEY` once. From `dkcollection`, run:

```bash
bash deploy/hostinger/install.sh "$(pwd)/../public_html"
```

The installer checks the layout and existing front controller, installs locked production dependencies, checks PHP requirements, migrates, optimizes and copies public files. It does not seed products or enable checkout. On Hostinger it uses `/opt/alt/php83/usr/bin/php` and `/usr/local/bin/composer2` by default; pass the PHP binary and Composer PHAR as its second and third arguments on another host. For subsequent releases, keep `.env`, database and uploaded files, extract updated source into the same private directory, then rerun the installer. Do not run `key:generate` again.

To make a ZIP from a clean committed checkout, run `bash deploy/hostinger/package.sh /path/to/dkfashionhub-release.zip`. It archives tracked files at `HEAD`, excluding `.env`, `vendor`, logs, uploads and Git metadata. Install Composer dependencies on the target host; a ZIP alone cannot supply the target PHP extensions or MySQL database. Keep release archives outside `public_html`.

## Moving the live store later

1. Stop accepting new orders on the old store and make a verified backup of the MySQL database and `storage/app/public` uploads. Export the database in phpMyAdmin; transfer it privately and import it into a new database on the target host.
2. Extract the source ZIP into `domains/NEW_DOMAIN/dkcollection`, next to an empty `public_html`. Copy the existing private `.env` securely, set the new HTTPS `APP_URL` and `DB_*` values, and **keep the same `APP_KEY`** so encrypted data remains readable. Do not put `.env` or the SQL export in the web root or release ZIP.
3. Restore `storage/app/public` to the private app, ensure PHP can write `storage` and `bootstrap/cache`, and run `bash deploy/hostinger/install.sh "$(pwd)/../public_html"` from the new `dkcollection` directory. The installer does not delete imported orders, customers, products or uploads.
4. Verify products, uploaded images, login, admin, orders, delivery, sitemap and payment webhook URL on the new HTTPS domain. Update the gateway webhook and DNS only after those checks; keep checkout disabled until the payment and delivery checks pass. Preserve the old database backup for rollback.

The storage symlink is created only once; inspect an existing `public_html/storage` before changing it. The PHP runtime must be able to write to `storage` and `bootstrap/cache`. Hostinger's default CLI `php` may be 8.2 even when the website uses 8.3, so use the explicit PHP 8.3 binary for all Composer and Artisan commands. For later releases, update the private repository and repeat Composer install, migrations, public asset sync, and optimize without regenerating `APP_KEY` or reseeding demos.

## Verification before taking orders

Check `/up`, `/`, a demo product, its SVG image, `/sitemap.xml`, `/account`, and admin access. Confirm `/.env`, `/composer.json`, `/vendor/` and `/storage/logs/` cannot be downloaded. Configure real outgoing mail and test password recovery; the production app disables reset delivery with log/array mailers. Leave checkout disabled in the admin panel during preview. Test MySQL, sessions, image upload and a COD order before enabling it. Configure Razorpay test keys, webhook, and captured-payment reconciliation before enabling online payment.
