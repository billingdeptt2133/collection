#!/usr/bin/env bash
set -euo pipefail

root=$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)
output=${1:-"$root/dkfashionhub-release.zip"}
test -f "$root/composer.lock" && test -f "$root/deploy/hostinger/public-index.php" || { echo 'Run from the complete repository.' >&2; exit 1; }
git -C "$root" diff --quiet HEAD && git -C "$root" diff --cached --quiet HEAD || { echo 'Commit changes before packaging.' >&2; exit 1; }
mkdir -p "$(dirname "$output")"
output=$(cd "$(dirname "$output")" && pwd)/$(basename "$output")
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT
git -C "$root" archive --format=tar --prefix=dkcollection/ HEAD | tar -xf - -C "$tmp"
test -f "$tmp/dkcollection/.env.production.example" || { echo 'Production env template is missing.' >&2; exit 1; }
(cd "$tmp" && zip -q -r "$output" dkcollection)
echo "Created $output from $(git -C "$root" rev-parse --short HEAD)"
