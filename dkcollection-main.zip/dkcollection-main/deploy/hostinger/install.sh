#!/usr/bin/env bash
set -euo pipefail

app=$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)
public=${1:?Usage: install.sh /absolute/path/to/public_html [php83-binary] [composer-phar]}
php_bin=${2:-/opt/alt/php83/usr/bin/php}
composer_bin=${3:-/usr/local/bin/composer2}
test -d "$public" && public=$(cd "$public" && pwd) || { echo 'Public directory does not exist.' >&2; exit 1; }
test "$(basename "$app")" = dkcollection && test "$(dirname "$app")" = "$(dirname "$public")" && test "$app" != "$public" || { echo 'Use sibling dkcollection and public_html directories.' >&2; exit 1; }
test -f "$app/.env" && test -f "$app/composer.lock" || { echo 'Create a private .env from .env.production.example first.' >&2; exit 1; }
grep -Eq '^APP_KEY=base64:.+' "$app/.env" || { echo 'Generate APP_KEY before installation; never replace an existing key.' >&2; exit 1; }
"$php_bin" -r 'exit(PHP_VERSION_ID >= 80300 ? 0 : 1);' || { echo 'PHP 8.3+ is required.' >&2; exit 1; }
if test -e "$public/index.php" && ! cmp -s "$app/deploy/hostinger/public-index.php" "$public/index.php"; then
    echo 'Existing public_html/index.php differs; inspect it before replacing.' >&2
    exit 1
fi
if test -e "$public/storage" || test -L "$public/storage"; then
    test -L "$public/storage" && test "$(readlink -f "$public/storage")" = "$app/storage/app/public" || { echo 'Existing public_html/storage differs; inspect it first.' >&2; exit 1; }
fi
cd "$app"
"$php_bin" "$composer_bin" install --no-dev --prefer-dist --optimize-autoloader --no-interaction
"$php_bin" "$composer_bin" check-platform-reqs --no-dev
"$php_bin" artisan migrate --force
"$php_bin" artisan optimize
rsync -a --exclude=index.php --exclude=storage public/ "$public/"
cp deploy/hostinger/public-index.php "$public/index.php"
test -L "$public/storage" || ln -s ../dkcollection/storage/app/public "$public/storage"
echo 'Installed. Verify /up, /, and restricted paths before enabling checkout.'
