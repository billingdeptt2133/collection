# DK Fashion Hub

Laravel 13 + MySQL fashion storefront for DK Collection. Responsive homepage, up to 20 products initially and up to 12 more per Show More click, search/category/sort, product size/color stock, cart, customer accounts, wishlist, COD checkout, orders, coupons, moderated reviews, gallery images and protected admin management. Razorpay is available only when its credentials are configured.

## Requirements

PHP 8.3+, Composer, MySQL and Laravel's required PHP extensions. The web server document root **must** be `public/`—never the repository root.

## Setup

```bash
composer install --no-dev --optimize-autoloader
cp .env.example .env
# Configure APP_URL and DB_* in .env; do not commit .env
php artisan key:generate
php artisan migrate --force
php artisan storage:link
php artisan optimize
```

Create a customer account through `/account`. To grant the first trusted account admin access, run this once on the server with the exact email, after confirming the account belongs to you:

```bash
php artisan tinker --execute="App\\Models\\User::where('email', 'YOUR_EMAIL')->firstOrFail()->forceFill(['is_admin' => true])->save();"
```

Admin interface: `/admin`. Enter product selling price and MRP in rupees; values are stored as integer paise (₹1 = 100 paise). Coupon and delivery fields still use paise. No demo administrator or default password is included.

## Online payments

Set `RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET` and `RAZORPAY_WEBHOOK_SECRET` in `.env`. Configure Razorpay's `payment.captured` webhook at `https://YOUR_DOMAIN/webhooks/razorpay`, enable automatic capture in Razorpay, and test with test keys before live keys. Checkout verifies the gateway order ID, HMAC signature, payment status, amount and currency on the server. Without keys, only COD is offered. Pending online orders reserve stock; the scheduled reconciliation worker verifies Razorpay before idempotently releasing stock and coupon usage after the configured timeout. Captured, duplicate, late, or ambiguous payments are recorded for admin reconciliation. Configure the per-minute Laravel scheduler and test these paths with Razorpay test keys before launch.

## Production

For Hostinger or a domain-portable source ZIP, follow [the secure sibling-directory setup](deploy/hostinger/README.md). Build a ZIP from a clean commit with `bash deploy/hostinger/package.sh /path/to/dkfashionhub-release.zip`. Never extract the application into `public_html`.

Use HTTPS and set `APP_ENV=production`, `APP_DEBUG=false`, `APP_URL` to the exact public host, a unique `APP_KEY`, strong DB credentials, `SESSION_SECURE_COOKIE=true`, and production mail settings. Password recovery is available after configuring SMTP or another real mail transport; the production app refuses to send reset links through the log or array mailers. Run migrations and `php artisan optimize` during deployment. Back up MySQL and uploaded media, monitor errors, and keep dependencies updated. Do not publish `.env` or `vendor`. Configure CDN/image optimization and a real shipping/pincode policy according to your business rules before accepting live orders. The print view is an HTML invoice; tax and legal invoice details require your business information.

## Development checks

```bash
composer install
php artisan test
composer audit
```

Tests use in-memory SQLite; production uses MySQL. Test a full purchase with your MySQL version and Razorpay test mode before launch.

## Admin and search visibility

The admin panel manages store branding, announcements, categories, banners, products and galleries, size/colour stock, coupons, reviews, customer lists, order details/status, delivery pincodes and fees. Checkout is disabled until the admin explicitly configures a delivery mode and payment method. In allowlist mode, only enabled pincodes can order. All-pincode mode is an explicit admin choice; confirm your courier serves those locations first.

Admin sections open as panels without scrolling through the whole dashboard. Products can optionally record the offline label's product code, article and pattern; each size/colour stock line can also hold a shade code and unique barcode. Use `Size,Colour,Quantity,Shade,Barcode` or the simpler `Size,Colour,Quantity` format. These fields remain blank for demos and do not copy another brand's tag into the storefront.

Each product has optional SEO title and description. Public product pages emit canonical URLs and Product structured data; `/sitemap.xml` lists published products and `/robots.txt` points crawlers to it. Set `APP_URL` to the final HTTPS domain before submitting the sitemap to a search engine. Search indexing and traffic depend on the search engine and content quality; metadata alone does not guarantee placement.

## Preview catalog

Run `php artisan db:seed --class=DemoCatalogSeeder` to add four jeans categories (Ankle Fit, Straight Fit, Baggy Fit, Regular Fit) with four placeholder listings each. It is safe to rerun: existing product details and stock are not overwritten. The homepage shows up to 20 products initially and appends up to 12 more per Show More click; the 16-item preview catalog fits in the first batch. Placeholder SVGs are clearly marked as demo; those products are omitted from the sitemap and use `noindex` on detail pages. The standard `DatabaseSeeder` does not create sample users or products.

Before accepting real customers, use **Admin → Products → Archive all demo products** and add your actual products and photos through the admin panel. Checkout remains disabled by default until delivery and payment settings are configured.
